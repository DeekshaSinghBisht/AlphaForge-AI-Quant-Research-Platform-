"""
pipeline.py
===========
PipelineOrchestrator – co-ordinates all agents end-to-end
run_complete_pipeline – top-level entry point (called from __main__)
display_visualizations / create_simple_visualizations – post-run plots
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List
from datetime import datetime
from pathlib import Path
import time
import traceback


class PipelineOrchestrator(BaseAgent):
    """
    Central orchestrator for the entire quantitative research pipeline.

    Coordinates:
    - Data fetching and processing
    - Feature engineering
    - Model training
    - Signal generation
    - Backtesting
    - Risk analysis
    - Report generation

    Attributes:
        agents: Dictionary of initialized agents
        results: Dictionary of pipeline results
        execution_log: Log of execution steps
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        """
        Initialize Pipeline Orchestrator.

        Args:
            config: System configuration
            logger: Logger instance
        """
        super().__init__("PipelineOrchestrator", config, logger)

        self.agents: Dict[str, BaseAgent] = {}
        self.results: Dict[str, Any] = {}
        self.execution_log: List[Dict[str, Any]] = []
        self.start_time: Optional[float] = None

    def initialize_agents(self) -> None:
        """Initialize all required agents."""
        self.logger.info("Initializing all agents...")

        try:
            # Data agents
            self.agents['data'] = MarketDataAgent(self.config, self.logger)
            self.agents['news'] = NewsAgent(self.config, self.logger)

            # Feature agents
            self.agents['features'] = FeatureEngineeringAgent(self.config, self.logger)
            self.agents['sentiment'] = SentimentAgent(self.config, self.logger, use_finbert=False)
            self.agents['regime'] = RegimeDetectionAgent(self.config, self.logger)
            self.agents['selection'] = FeatureSelectionAgent(self.config, self.logger)

            # ML agents
            self.agents['lr'] = LogisticRegressionAgent(self.config, self.logger)
            self.agents['rf'] = RandomForestAgent(self.config, self.logger)
            if XGBOOST_AVAILABLE:
                self.agents['xgb'] = XGBoostAgent(self.config, self.logger)
            self.agents['prediction'] = PredictionAgent(self.config, self.logger)

            # Trading agents
            self.agents['signal'] = SignalGenerationAgent(self.config, self.logger)
            self.agents['backtest'] = BacktestingAgent(self.config, self.logger)

            # Analysis agents
            self.agents['risk'] = RiskManagementAgent(self.config, self.logger)
            self.agents['montecarlo'] = MonteCarloAgent(self.config, self.logger)
            self.agents['portfolio'] = PortfolioOptimizationAgent(self.config, self.logger)
            self.agents['evaluation'] = StrategyEvaluationAgent(self.config, self.logger)

            # Report agent
            self.agents['report'] = ReportGenerationAgent(self.config, self.logger)

            self.logger.info(f"Initialized {len(self.agents)} agents")

        except Exception as e:
            self.logger.error(f"Error initializing agents: {e}")
            raise

    def _log_step(
        self,
        step_name: str,
        status: str,
        duration: float,
        details: str = ""
    ) -> None:
        """Log execution step."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'step': step_name,
            'status': status,
            'duration': duration,
            'details': details
        }
        self.execution_log.append(log_entry)

        status_icon = "✅" if status == "success" else "❌"
        self.logger.info(f"{status_icon} {step_name} ({duration:.2f}s)")

    def run_step(
        self,
        step_name: str,
        func: callable,
        *args,
        **kwargs
    ) -> Any:
        """
        Run a pipeline step with logging and error handling.

        Args:
            step_name: Name of the step
            func: Function to execute
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            Result of the function
        """
        start = time.time()

        try:
            result = func(*args, **kwargs)
            duration = time.time() - start
            self._log_step(step_name, "success", duration)
            return result
        except Exception as e:
            duration = time.time() - start
            self._log_step(step_name, "failed", duration, str(e))
            self.logger.exception(f"Step '{step_name}' failed: {e}")
            raise

    def run_data_pipeline(
        self,
        tickers: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Run data acquisition pipeline.

        Args:
            tickers: List of tickers to fetch

        Returns:
            Data pipeline results
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info("STAGE 1: DATA ACQUISITION")
        self.logger.info("=" * 50)

        # Fetch market data
        data_result = self.run_step(
            "Fetch Market Data",
            self.agents['data'].run,
            tickers=tickers
        )

        if not data_result.success:
            raise RuntimeError(f"Data fetch failed: {data_result.errors}")

        self.results['market_data'] = data_result.data

        # Fetch news data (optional)
        try:
            news_result = self.run_step(
                "Fetch News Data",
                self.agents['news'].run,
                tickers=tickers,
                days_back=30
            )
            self.results['news_data'] = news_result.data if news_result.success else None
        except:
            self.results['news_data'] = None

        return self.results

    def run_feature_pipeline(
        self,
        ticker: str
    ) -> Dict[str, Any]:
        """
        Run feature engineering pipeline for a single ticker.

        Args:
            ticker: Ticker symbol

        Returns:
            Feature pipeline results
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info(f"STAGE 2: FEATURE ENGINEERING ({ticker})")
        self.logger.info("=" * 50)

        # Get price data for ticker
        price_data = self.results['market_data']['data'][ticker]

        # Generate technical features
        feature_result = self.run_step(
            "Generate Technical Features",
            self.agents['features'].run,
            price_data
        )

        if not feature_result.success:
            raise RuntimeError(f"Feature generation failed: {feature_result.errors}")

        # Regime detection
        try:
            regime_result = self.run_step(
                "Detect Market Regimes",
                self.agents['regime'].run,
                price_data
            )
            self.results[f'regime_{ticker}'] = regime_result.data if regime_result.success else None
        except:
            self.results[f'regime_{ticker}'] = None

        # Prepare ML data
        X = feature_result.data['X']
        y = feature_result.data['y']

        # Feature selection
        if len(X.columns) > 30:
            selection_result = self.run_step(
                "Select Features",
                self.agents['selection'].run,
                X, y,
                method='ensemble',
                n_features=30
            )

            if selection_result.success:
                X = selection_result.data['X_selected']

        self.results[f'features_{ticker}'] = {
            'X': X,
            'y': y,
            'feature_names': list(X.columns),
            'price_data': price_data
        }

        return self.results[f'features_{ticker}']

    def run_ml_pipeline(
        self,
        ticker: str
    ) -> Dict[str, Any]:
        """
        Run ML training pipeline.

        Args:
            ticker: Ticker symbol

        Returns:
            ML pipeline results
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info(f"STAGE 3: ML TRAINING ({ticker})")
        self.logger.info("=" * 50)

        feature_data = self.results[f'features_{ticker}']
        X = feature_data['X']
        y = feature_data['y']

        # Walk-forward training
        model_configs = {
            'logistic_regression': {},
            'random_forest': {'n_estimators': 100}
        }

        if XGBOOST_AVAILABLE:
            model_configs['xgboost'] = {'n_estimators': 100}

        prediction_result = self.run_step(
            "Walk-Forward ML Training",
            self.agents['prediction'].run,
            X, y,
            model_configs=model_configs
        )

        if not prediction_result.success:
            raise RuntimeError(f"ML training failed: {prediction_result.errors}")

        self.results[f'ml_{ticker}'] = prediction_result.data

        return prediction_result.data

    def run_signal_pipeline(
        self,
        ticker: str
    ) -> Dict[str, Any]:
        """
        Run signal generation pipeline.

        Args:
            ticker: Ticker symbol

        Returns:
            Signal pipeline results
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info(f"STAGE 4: SIGNAL GENERATION ({ticker})")
        self.logger.info("=" * 50)

        ml_data = self.results[f'ml_{ticker}']
        feature_data = self.results[f'features_{ticker}']

        # Get combined probabilities
        probabilities = ml_data['combined_probabilities']

        # Get returns for optimization
        price_data = feature_data['price_data']
        returns = price_data['Returns'].dropna()

        # Generate signals
        signal_result = self.run_step(
            "Generate Trading Signals",
            self.agents['signal'].run,
            probabilities,
            returns=returns,
            optimize=True
        )

        if not signal_result.success:
            raise RuntimeError(f"Signal generation failed: {signal_result.errors}")

        self.results[f'signals_{ticker}'] = signal_result.data

        return signal_result.data

    def run_backtest_pipeline(
        self,
        ticker: str
    ) -> Dict[str, Any]:
        """
        Run backtesting pipeline.

        Args:
            ticker: Ticker symbol

        Returns:
            Backtest results
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info(f"STAGE 5: BACKTESTING ({ticker})")
        self.logger.info("=" * 50)

        feature_data = self.results[f'features_{ticker}']
        signal_data = self.results[f'signals_{ticker}']

        price_data = feature_data['price_data']
        signals = signal_data['signals']

        # Run backtest
        backtest_result = self.run_step(
            "Run Backtest",
            self.agents['backtest'].run,
            price_data,
            signals,
            probabilities=signal_data['probabilities']
        )

        if not backtest_result.success:
            raise RuntimeError(f"Backtest failed: {backtest_result.errors}")

        self.results[f'backtest_{ticker}'] = backtest_result.data

        return backtest_result.data

    def run_analysis_pipeline(
        self,
        ticker: str
    ) -> Dict[str, Any]:
        """
        Run risk analysis pipeline.

        Args:
            ticker: Ticker symbol

        Returns:
            Analysis results
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info(f"STAGE 6: RISK ANALYSIS ({ticker})")
        self.logger.info("=" * 50)

        backtest_data = self.results[f'backtest_{ticker}']
        returns = backtest_data['returns']

        # Risk analysis
        risk_result = self.run_step(
            "Calculate Risk Metrics",
            self.agents['risk'].run,
            returns
        )

        self.results[f'risk_{ticker}'] = risk_result.data if risk_result.success else {}

        # Monte Carlo simulation
        try:
            mc_result = self.run_step(
                "Monte Carlo Simulation",
                self.agents['montecarlo'].run,
                returns,
                n_simulations=5000,
                horizon=252
            )
            self.results[f'montecarlo_{ticker}'] = mc_result.data if mc_result.success else {}
        except:
            self.results[f'montecarlo_{ticker}'] = {}

        # Statistical evaluation
        try:
            eval_result = self.run_step(
                "Statistical Evaluation",
                self.agents['evaluation'].run,
                returns,
                n_trials=1
            )
            self.results[f'evaluation_{ticker}'] = eval_result.data if eval_result.success else {}
        except:
            self.results[f'evaluation_{ticker}'] = {}

        return self.results

    def run_report_pipeline(
        self,
        ticker: str
    ) -> Path:
        """
        Run report generation pipeline.

        Args:
            ticker: Ticker symbol

        Returns:
            Path to generated report
        """
        self.logger.info("\n" + "=" * 50)
        self.logger.info(f"STAGE 7: REPORT GENERATION ({ticker})")
        self.logger.info("=" * 50)

        backtest_data = self.results[f'backtest_{ticker}']
        risk_data = self.results.get(f'risk_{ticker}', {})
        mc_data = self.results.get(f'montecarlo_{ticker}', {})
        eval_data = self.results.get(f'evaluation_{ticker}', {})

        # Prepare data for report
        report_result = self.run_step(
            "Generate Report",
            self.agents['report'].run,
            backtest_results={
                'total_return': backtest_data.get('total_return', 0),
                'sharpe_ratio': backtest_data.get('sharpe_ratio', 0),
                'max_drawdown': backtest_data.get('max_drawdown', 0),
                'total_trades': backtest_data.get('total_trades', 0),
                'win_rate': backtest_data.get('win_rate', 0)
            },
            equity_curve=backtest_data.get('equity_curve', pd.Series()),
            returns=backtest_data.get('returns', pd.Series()),
            risk_metrics={
                'var_95': risk_data.get('var_95', 0),
                'cvar_95': risk_data.get('cvar_95', 0),
                'volatility': risk_data.get('volatility', 0),
                'sortino_ratio': risk_data.get('risk_metrics', {}).sortino_ratio if hasattr(risk_data.get('risk_metrics', {}), 'sortino_ratio') else 0,
                'calmar_ratio': risk_data.get('risk_metrics', {}).calmar_ratio if hasattr(risk_data.get('risk_metrics', {}), 'calmar_ratio') else 0
            },
            monte_carlo_results=mc_data,
            monte_carlo_simulations=mc_data.get('simulations'),
            statistical_tests=eval_data.get('test_results', [])
        )

        if report_result.success:
            return Path(report_result.data['report_path'])

        return None

    def run_full_pipeline(
        self,
        tickers: Optional[List[str]] = None,
        generate_report: bool = True
    ) -> Dict[str, Any]:
        """
        Run complete pipeline for all tickers.

        Args:
            tickers: List of tickers (uses config if None)
            generate_report: Whether to generate reports

        Returns:
            Complete pipeline results
        """
        self.start_time = time.time()
        tickers = tickers or self.config.data.tickers[:2]  # Limit for demo

        self.logger.info("\n" + "=" * 70)
        self.logger.info("🚀 STARTING FULL PIPELINE EXECUTION")
        self.logger.info(f"   Tickers: {tickers}")
        self.logger.info("=" * 70)

        # Initialize agents
        self.initialize_agents()

        # Run data pipeline
        self.run_data_pipeline(tickers)

        # Process each ticker
        report_paths = []
        for ticker in tickers:
            try:
                self.logger.info(f"\n{'='*70}")
                self.logger.info(f"📊 PROCESSING: {ticker}")
                self.logger.info(f"{'='*70}")

                # Feature engineering
                self.run_feature_pipeline(ticker)

                # ML training
                self.run_ml_pipeline(ticker)

                # Signal generation
                self.run_signal_pipeline(ticker)

                # Backtesting
                self.run_backtest_pipeline(ticker)

                # Analysis
                self.run_analysis_pipeline(ticker)

                # Report
                if generate_report:
                    report_path = self.run_report_pipeline(ticker)
                    if report_path:
                        report_paths.append(str(report_path))

            except Exception as e:
                self.logger.error(f"Pipeline failed for {ticker}: {e}")
                traceback.print_exc()
                continue

        # Summary
        total_time = time.time() - self.start_time

        self.logger.info("\n" + "=" * 70)
        self.logger.info("✅ PIPELINE EXECUTION COMPLETE")
        self.logger.info(f"   Total time: {total_time:.2f}s")
        self.logger.info(f"   Tickers processed: {len(tickers)}")
        self.logger.info(f"   Reports generated: {len(report_paths)}")
        self.logger.info("=" * 70)

        return {
            'results': self.results,
            'execution_log': self.execution_log,
            'total_time': total_time,
            'report_paths': report_paths
        }

    def run(
        self,
        tickers: Optional[List[str]] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            tickers: List of tickers

        Returns:
            AgentResult with pipeline results
        """
        def execute():
            return self.run_full_pipeline(tickers, **kwargs)

        return self._execute_with_timing(execute)


# Test Pipeline Orchestrator (Mini run)
print("=" * 70)
print("🧪 TESTING PIPELINE ORCHESTRATOR")
print("=" * 70)

print("\n⚠️ Full pipeline test skipped for cell execution.")
print("   Run Cell 40 for complete pipeline execution.")

print("\n✅ Pipeline Orchestrator ready!")


import sys
import importlib
from datetime import datetime
import os

# ============================================================================
# CHECK IF PREVIOUS CELLS WERE EXECUTED
# ============================================================================

def check_previous_cells_executed():
    """Check if critical previous cells were executed."""
    critical_components = {
        'Cell 2 (Paths)': 'path_manager' in dir() or 'BASE_PATH' in dir(),
        'Cell 4-5 (Config)': 'SystemConfig' in dir() or 'config' in dir(),
        'Cell 6 (Logging)': 'QuantLogger' in dir(),
        'Cell 8 (BaseAgent)': 'BaseAgent' in dir(),
        'Cell 10 (DataAgent)': 'MarketDataAgent' in dir(),
    }

    missing = [name for name, exists in critical_components.items() if not exists]
    return missing


# Check if we need to show warning
missing_cells = check_previous_cells_executed()

if missing_cells:
    print("⚠️" + "=" * 68 + "⚠️")
    print("║" + " " * 20 + "CELLS NOT EXECUTED" + " " * 28 + "║")
    print("⚠️" + "=" * 68 + "⚠️")
    print()
    print("  The following cells need to be run first:")
    for cell in missing_cells:
        print(f"    ❌ {cell}")
    print()
    print("  📋 INSTRUCTIONS:")
    print("     1. Go to Runtime → Run all (Ctrl+F9)")
    print("     OR")
    print("     2. Run cells 1-38 in order before this cell")
    print()
    print("=" * 70)

    # Offer to run initialization
    print("\n🔧 Attempting minimal initialization for testing...")

    # Minimal initialization if cells weren't run
    try:
        # Try to get what we can from globals
        if 'BASE_PATH' not in dir():
            from pathlib import Path
            BASE_PATH = Path('/content/drive/MyDrive/quant_research_system')
            DATA_PATH = BASE_PATH / 'data'
            MODELS_PATH = BASE_PATH / 'models'
            RESULTS_PATH = BASE_PATH / 'results'
            REPORTS_PATH = RESULTS_PATH / 'reports'
            LOGS_PATH = BASE_PATH / 'logs'
            CACHE_PATH = BASE_PATH / 'cache'

            # Create directories
            for p in [BASE_PATH, DATA_PATH, MODELS_PATH, RESULTS_PATH, REPORTS_PATH, LOGS_PATH, CACHE_PATH]:
                p.mkdir(parents=True, exist_ok=True)
            print("   ✅ Paths initialized")
    except Exception as e:
        print(f"   ❌ Path initialization failed: {e}")


def check_environment():
    """Check all required packages and components."""
    print("=" * 70)
    print("🔍 SYSTEM ENVIRONMENT CHECK")
    print("=" * 70)
    print(f"  Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Python: {sys.version.split()[0]}")
    print()

    # Core packages
    core_packages = [
        ('numpy', 'np'),
        ('pandas', 'pd'),
        ('scipy', None),
        ('sklearn', None),
    ]

    # ML packages
    ml_packages = [
        ('xgboost', 'xgb'),
        ('lightgbm', 'lgb'),
        ('tensorflow', 'tf'),
        ('torch', None),
    ]

    # Data packages
    data_packages = [
        ('yfinance', 'yf'),
        ('finnhub', None),
        ('fredapi', None),
    ]

    # Other packages
    other_packages = [
        ('backtrader', 'bt'),
        ('optuna', None),
        ('transformers', None),
        ('shap', None),
        ('cvxpy', 'cp'),
        ('fastapi', None),
    ]

    all_packages = [
        ("CORE PACKAGES", core_packages),
        ("ML PACKAGES", ml_packages),
        ("DATA PACKAGES", data_packages),
        ("OTHER PACKAGES", other_packages),
    ]

    total_available = 0
    total_packages = 0

    for category, packages in all_packages:
        print(f"  {category}")
        print(f"  {'-' * 40}")

        for package, alias in packages:
            total_packages += 1
            try:
                mod = importlib.import_module(package)
                version = getattr(mod, '__version__', 'unknown')
                print(f"    ✅ {package:.<25} {version}")
                total_available += 1
            except ImportError:
                print(f"    ❌ {package:.<25} Not installed")
        print()

    print(f"  {'=' * 40}")
    print(f"  SUMMARY: {total_available}/{total_packages} packages available")
    print(f"  {'=' * 40}")

    return total_available / total_packages


def check_components():
    """Check all system components are ready."""
    print("\n" + "=" * 70)
    print("🔧 COMPONENT STATUS CHECK")
    print("=" * 70)

    # Get global namespace
    global_vars = globals()

    components = [
        ("Configuration System", 'config' in global_vars or 'SystemConfig' in global_vars),
        ("Path Manager", 'path_manager' in global_vars or 'BASE_PATH' in global_vars),
        ("Logging System", 'system_logger' in global_vars or 'QuantLogger' in global_vars),
        ("Technical Indicators", 'TechnicalIndicators' in global_vars),
        ("Market Data Agent", 'MarketDataAgent' in global_vars),
        ("News Agent", 'NewsAgent' in global_vars),
        ("Feature Engineering Agent", 'FeatureEngineeringAgent' in global_vars),
        ("Sentiment Agent", 'SentimentAgent' in global_vars),
        ("Regime Detection Agent", 'RegimeDetectionAgent' in global_vars),
        ("Feature Selection Agent", 'FeatureSelectionAgent' in global_vars),
        ("Logistic Regression Agent", 'LogisticRegressionAgent' in global_vars),
        ("Random Forest Agent", 'RandomForestAgent' in global_vars),
        ("XGBoost Agent", 'XGBoostAgent' in global_vars),
        ("LSTM Agent", 'LSTMAgent' in global_vars),
        ("Ensemble Agent", 'EnsembleAgent' in global_vars),
        ("Hyperparameter Agent", 'HyperparameterAgent' in global_vars),
        ("Prediction Agent", 'PredictionAgent' in global_vars),
        ("Signal Generation Agent", 'SignalGenerationAgent' in global_vars),
        ("Backtesting Agent", 'BacktestingAgent' in global_vars),
        ("Risk Management Agent", 'RiskManagementAgent' in global_vars),
        ("Monte Carlo Agent", 'MonteCarloAgent' in global_vars),
        ("Portfolio Optimization Agent", 'PortfolioOptimizationAgent' in global_vars),
        ("Strategy Evaluation Agent", 'StrategyEvaluationAgent' in global_vars),
        ("Report Generation Agent", 'ReportGenerationAgent' in global_vars),
        ("Pipeline Orchestrator", 'PipelineOrchestrator' in global_vars),
        ("Visualization Dashboard", 'VisualizationDashboard' in global_vars or 'QuantVisualizer' in global_vars),
    ]

    available = sum(1 for _, ready in components if ready)

    for name, ready in components:
        status = "✅" if ready else "❌"
        print(f"  {status} {name}")

    print(f"\n  {'=' * 40}")
    print(f"  SUMMARY: {available}/{len(components)} components ready")
    print(f"  {'=' * 40}")

    # Show which cells to run if components missing
    if available < len(components):
        print("\n  📋 TO FIX: Run all cells in order (Cells 1-38)")
        print("     Or use: Runtime → Run all (Ctrl+F9)")

    return available / len(components)


def check_paths():
    """Check all paths are configured."""
    print("\n" + "=" * 70)
    print("📁 PATH CONFIGURATION")
    print("=" * 70)

    # Try to get paths from globals or define defaults
    try:
        paths = [
            ("Base Path", globals().get('BASE_PATH', '/content/drive/MyDrive/quant_research_system')),
            ("Data Path", globals().get('DATA_PATH', '/content/drive/MyDrive/quant_research_system/data')),
            ("Models Path", globals().get('MODELS_PATH', '/content/drive/MyDrive/quant_research_system/models')),
            ("Results Path", globals().get('RESULTS_PATH', '/content/drive/MyDrive/quant_research_system/results')),
            ("Reports Path", globals().get('REPORTS_PATH', '/content/drive/MyDrive/quant_research_system/results/reports')),
            ("Logs Path", globals().get('LOGS_PATH', '/content/drive/MyDrive/quant_research_system/logs')),
            ("Cache Path", globals().get('CACHE_PATH', '/content/drive/MyDrive/quant_research_system/cache')),
        ]

        from pathlib import Path
        all_exist = True
        for name, path in paths:
            p = Path(path) if not isinstance(path, Path) else path
            exists = p.exists()
            if not exists:
                all_exist = False
            status = "✅" if exists else "❌"
            print(f"  {status} {name:.<25} {p}")

        return all_exist

    except Exception as e:
        print(f"  ❌ Error checking paths: {e}")
        return False


def check_api_keys():
    """Check API key configuration."""
    print("\n" + "=" * 70)
    print("🔑 API KEY STATUS")
    print("=" * 70)

    keys = [
        ("Finnhub API", os.environ.get('FINNHUB_API_KEY', '')),
        ("FRED API", os.environ.get('FRED_API_KEY', '')),
        ("Alpha Vantage", os.environ.get('ALPHA_VANTAGE_API_KEY', '')),
    ]

    configured = 0
    for name, key in keys:
        if key:
            masked_key = key[:4] + '*' * min(20, len(key) - 8) + key[-4:] if len(key) > 8 else '****'
            print(f"  ✅ {name:.<25} {masked_key}")
            configured += 1
        else:
            print(f"  ⚠️  {name:.<25} Not configured")

    return configured / len(keys)


def system_summary():
    """Print complete system summary."""
    env_score = check_environment()
    comp_score = check_components()
    paths_ok = check_paths()
    api_score = check_api_keys()

    print("\n" + "=" * 70)
    print("📊 SYSTEM READINESS SUMMARY")
    print("=" * 70)

    # Calculate overall score
    overall_score = (env_score + comp_score + (1.0 if paths_ok else 0.0) + api_score) / 4

    print(f"  Environment Score:   {env_score*100:>5.0f}%")
    print(f"  Component Score:     {comp_score*100:>5.0f}%")
    print(f"  Paths Configured:    {'100%' if paths_ok else '0%':>5}")
    print(f"  API Keys Score:      {api_score*100:>5.0f}%")
    print(f"  {'=' * 40}")
    print(f"  OVERALL READINESS:   {overall_score*100:>5.0f}%")
    print(f"  {'=' * 40}")

    # Rating
    if overall_score >= 0.9:
        rating = "🌟 EXCELLENT - System fully operational"
    elif overall_score >= 0.75:
        rating = "✅ GOOD - System operational with minor limitations"
    elif overall_score >= 0.5:
        rating = "⚠️  FAIR - System partially operational"
    else:
        rating = "❌ POOR - Run all cells first (Runtime → Run all)"

    print(f"\n  Rating: {rating}")

    # Instructions if not ready
    if comp_score < 0.5:
        print("\n" + "=" * 70)
        print("📋 NEXT STEPS TO GET 100% READY:")
        print("=" * 70)
        print("  1. Go to: Runtime → Run all")
        print("     OR press: Ctrl+F9")
        print()
        print("  2. Wait for all 40+ cells to execute")
        print()
        print("  3. Run this cell again to verify")
        print("=" * 70)

    print()

    return overall_score


def display_system_info():
    """Display complete system information."""
    print("\n")
    print("╔" + "═" * 68 + "╗")
    print("║" + " " * 15 + "AI QUANTITATIVE RESEARCH SYSTEM v2.0" + " " * 16 + "║")
    print("║" + " " * 20 + "Institutional-Grade Platform" + " " * 20 + "║")
    print("╠" + "═" * 68 + "╣")
    print("║                                                                    ║")
    print("║  Features:                                                         ║")
    print("║  ├── Multi-agent architecture                                      ║")
    print("║  ├── Walk-forward ML pipeline                                      ║")
    print("║  ├── Learned ensemble weights (stacking)                           ║")
    print("║  ├── Feature selection (MI, RFE, SHAP)                             ║")
    print("║  ├── Event-driven backtesting                                      ║")
    print("║  ├── Realistic transaction cost modeling                           ║")
    print("║  ├── Comprehensive risk analysis                                   ║")
    print("║  ├── Monte Carlo simulation                                        ║")
    print("║  ├── Portfolio optimization (MVO, HRP)                             ║")
    print("║  ├── Statistical validation                                        ║")
    print("║  └── HTML report generation                                        ║")
    print("║                                                                    ║")
    print("║  Models:                                                           ║")
    print("║  ├── Logistic Regression                                           ║")
    print("║  ├── Random Forest                                                 ║")
    print("║  ├── XGBoost                                                       ║")
    print("║  └── LSTM with Attention                                           ║")
    print("║                                                                    ║")
    print("╚" + "═" * 68 + "╝")
    print()


# ============================================================================
# RUN SYSTEM CHECK
# ============================================================================

display_system_info()
overall_readiness = system_summary()

print("✅ System validation complete!")

if overall_readiness >= 0.9:
    print(f"   🚀 Ready to run full pipeline!")
    print(f"   → Go to Cell 40 and set RUN_FULL_PIPELINE = True")
elif overall_readiness >= 0.5:
    print(f"   ⚠️  Partially ready - some features may not work")
    print(f"   → Run all cells first for full functionality")
else:
    print(f"   ❌ Not ready - please run all cells first")
    print(f"   → Use: Runtime → Run all (Ctrl+F9)")


import time
import traceback
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

RUN_FULL_PIPELINE = True  #@param {type:"boolean"}
TICKERS_TO_PROCESS = "AAPL,MSFT"  #@param {type:"string"}
GENERATE_REPORTS = True  #@param {type:"boolean"}
SAVE_MODELS = True  #@param {type:"boolean"}
VERBOSE = True  #@param {type:"boolean"}

# Global storage for data (accessible for visualization)
PIPELINE_DATA = {
    'market_data': {},
    'benchmark_data': None,
    'results': {}
}


def run_complete_pipeline(
    tickers: List[str] = None,
    generate_reports: bool = True,
    save_models: bool = True,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    Run the complete quantitative research pipeline.

    Args:
        tickers: List of tickers to process
        generate_reports: Whether to generate HTML reports
        save_models: Whether to save trained models
        verbose: Whether to print detailed progress

    Returns:
        Dictionary with all pipeline results
    """
    global PIPELINE_DATA

    start_time = time.time()

    # Parse tickers
    if tickers is None:
        tickers = ['AAPL', 'MSFT']

    print("\n" + "=" * 70)
    print("🚀 STARTING COMPLETE RESEARCH PIPELINE")
    print("=" * 70)
    print(f"   Tickers: {', '.join(tickers)}")
    print(f"   Generate Reports: {generate_reports}")
    print(f"   Save Models: {save_models}")
    print(f"   Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)

    all_results = {
        'tickers': tickers,
        'start_time': datetime.now().isoformat(),
        'ticker_results': {},
        'reports': [],
        'errors': [],
        'equity_curves': {},
        'returns': {}
    }

    # ========================================================================
    # STAGE 1: DATA ACQUISITION
    # ========================================================================
    print("\n" + "=" * 70)
    print("📊 STAGE 1: DATA ACQUISITION")
    print("=" * 70)

    try:
        data_agent = MarketDataAgent(config=config)
        data_result = data_agent.run(tickers=tickers)

        if not data_result.success:
            raise RuntimeError(f"Data fetch failed: {data_result.errors}")

        market_data = data_result.data['data']
        benchmark_data = data_result.data.get('benchmark')

        # Store globally for visualization
        PIPELINE_DATA['market_data'] = market_data
        PIPELINE_DATA['benchmark_data'] = benchmark_data

        print(f"✅ Fetched data for {len(market_data)} tickers")
        for ticker in market_data:
            print(f"   {ticker}: {len(market_data[ticker])} rows")

        all_results['market_data_summary'] = {
            ticker: len(df) for ticker, df in market_data.items()
        }

    except Exception as e:
        print(f"❌ Data acquisition failed: {e}")
        all_results['errors'].append(f"Data acquisition: {e}")
        return all_results

    # ========================================================================
    # PROCESS EACH TICKER
    # ========================================================================

    for ticker in tickers:
        print("\n" + "=" * 70)
        print(f"📈 PROCESSING: {ticker}")
        print("=" * 70)

        ticker_results = {'ticker': ticker}

        try:
            price_data = market_data[ticker]

            # ==================================================================
            # STAGE 2: FEATURE ENGINEERING
            # ==================================================================
            print(f"\n  📊 Stage 2: Feature Engineering")

            feature_agent = FeatureEngineeringAgent(config=config)
            feature_result = feature_agent.run(price_data)

            if not feature_result.success:
                raise RuntimeError(f"Feature engineering failed: {feature_result.errors}")

            X = feature_result.data['X']
            y = feature_result.data['y']
            feature_names = feature_result.data['feature_names']

            print(f"     ✅ Generated {len(feature_names)} features")
            print(f"     ✅ Samples: {len(X)}")

            ticker_results['n_features'] = len(feature_names)
            ticker_results['n_samples'] = len(X)

            # ==================================================================
            # STAGE 3: FEATURE SELECTION
            # ==================================================================
            print(f"\n  🎯 Stage 3: Feature Selection")

            if len(X.columns) > 30:
                selection_agent = FeatureSelectionAgent(config=config, max_features=30)
                selection_result = selection_agent.run(X, y, method='ensemble')

                if selection_result.success:
                    X = selection_result.data['X_selected']
                    print(f"     ✅ Selected {len(X.columns)} features")
            else:
                print(f"     ✅ Using all {len(X.columns)} features")

            ticker_results['selected_features'] = list(X.columns)

            # ==================================================================
            # STAGE 4: MODEL TRAINING (Walk-Forward)
            # ==================================================================
            print(f"\n  🤖 Stage 4: ML Training (Walk-Forward)")

            # Define model configurations
            model_configs = {
                'logistic_regression': {'C': 1.0},
                'random_forest': {'n_estimators': 100, 'max_depth': 10}
            }

            if XGBOOST_AVAILABLE:
                model_configs['xgboost'] = {'n_estimators': 100, 'max_depth': 6}

            prediction_agent = PredictionAgent(config=config)
            ml_result = prediction_agent.run(X, y, model_configs=model_configs)

            if not ml_result.success:
                raise RuntimeError(f"ML training failed: {ml_result.errors}")

            print(f"     ✅ Walk-forward training complete")
            print(f"     ✅ Overall Accuracy: {ml_result.data['overall_accuracy']:.4f}")
            print(f"     ✅ Overall AUC: {ml_result.data['overall_auc']:.4f}")

            ticker_results['ml_accuracy'] = ml_result.data['overall_accuracy']
            ticker_results['ml_auc'] = ml_result.data['overall_auc']

            # ==================================================================
            # STAGE 5: SIGNAL GENERATION
            # ==================================================================
            print(f"\n  📊 Stage 5: Signal Generation")

            combined_probs = ml_result.data['combined_probabilities']
            returns = price_data['Returns'].loc[combined_probs.index].dropna()

            signal_agent = SignalGenerationAgent(config=config)
            signal_result = signal_agent.run(
                combined_probs,
                returns=returns,
                optimize=True
            )

            if not signal_result.success:
                raise RuntimeError(f"Signal generation failed: {signal_result.errors}")

            signals = signal_result.data['signals']

            stats = signal_result.data['statistics']
            print(f"     ✅ Buy threshold: {signal_result.data['thresholds']['buy']:.3f}")
            print(f"     ✅ Sell threshold: {signal_result.data['thresholds']['sell']:.3f}")
            print(f"     ✅ Signals: BUY={stats['buy_signals']}, SELL={stats['sell_signals']}, HOLD={stats['hold_signals']}")

            ticker_results['signal_stats'] = stats

            # ==================================================================
            # STAGE 6: BACKTESTING
            # ==================================================================
            print(f"\n  📈 Stage 6: Backtesting")

            # Align price data with signals
            bt_price_data = price_data.loc[signals.index].dropna()
            bt_signals = signals.loc[bt_price_data.index]

            backtest_agent = BacktestingAgent(config=config, use_backtrader=False)
            backtest_result = backtest_agent.run(bt_price_data, bt_signals)

            if not backtest_result.success:
                raise RuntimeError(f"Backtesting failed: {backtest_result.errors}")

            bt_data = backtest_result.data
            print(f"     ✅ Total Return: {bt_data['total_return']*100:.2f}%")
            print(f"     ✅ Sharpe Ratio: {bt_data['sharpe_ratio']:.4f}")
            print(f"     ✅ Max Drawdown: {bt_data['max_drawdown']*100:.2f}%")
            print(f"     ✅ Total Trades: {bt_data['total_trades']}")
            print(f"     ✅ Win Rate: {bt_data['win_rate']*100:.1f}%")

            ticker_results['backtest'] = {
                'total_return': bt_data['total_return'],
                'sharpe_ratio': bt_data['sharpe_ratio'],
                'max_drawdown': bt_data['max_drawdown'],
                'total_trades': bt_data['total_trades'],
                'win_rate': bt_data['win_rate']
            }

            # Store equity curve and returns for visualization
            all_results['equity_curves'][ticker] = bt_data.get('equity_curve')
            all_results['returns'][ticker] = bt_data.get('returns')
            ticker_results['equity_curve'] = bt_data.get('equity_curve')
            ticker_results['strategy_returns'] = bt_data.get('returns')

            # ==================================================================
            # STAGE 7: RISK ANALYSIS
            # ==================================================================
            print(f"\n  ⚠️ Stage 7: Risk Analysis")

            strategy_returns = bt_data['returns']

            risk_agent = RiskManagementAgent(config=config)
            risk_result = risk_agent.run(strategy_returns, run_stress_test=True)

            if risk_result.success:
                risk_data = risk_result.data
                print(f"     ✅ VaR (95%): {risk_data['var_95']*100:.2f}%")
                print(f"     ✅ CVaR (95%): {risk_data['cvar_95']*100:.2f}%")
                print(f"     ✅ Volatility: {risk_data['volatility']*100:.2f}%")

                ticker_results['risk'] = {
                    'var_95': risk_data['var_95'],
                    'cvar_95': risk_data['cvar_95'],
                    'volatility': risk_data['volatility'],
                    'max_drawdown': risk_data['max_drawdown']
                }

            # ==================================================================
            # STAGE 8: MONTE CARLO SIMULATION
            # ==================================================================
            print(f"\n  🎲 Stage 8: Monte Carlo Simulation")

            mc_agent = MonteCarloAgent(config=config, n_simulations=5000, horizon=252)
            mc_result = mc_agent.run(strategy_returns, initial_value=100000)

            if mc_result.success:
                mc_data = mc_result.data
                print(f"     ✅ Probability of Profit: {mc_data['probability_profit']*100:.1f}%")
                print(f"     ✅ Probability of Ruin: {mc_data['probability_ruin']*100:.1f}%")
                print(f"     ✅ Expected Return: {mc_data['expected_return']*100:.2f}%")

                ticker_results['monte_carlo'] = {
                    'probability_profit': mc_data['probability_profit'],
                    'probability_ruin': mc_data['probability_ruin'],
                    'expected_return': mc_data['expected_return'],
                    'simulations': mc_data.get('simulations')
                }

            # ==================================================================
            # STAGE 9: STATISTICAL EVALUATION
            # ==================================================================
            print(f"\n  🔬 Stage 9: Statistical Evaluation")

            eval_agent = StrategyEvaluationAgent(config=config)
            eval_result = eval_agent.run(strategy_returns, n_trials=1)

            if eval_result.success:
                eval_data = eval_result.data
                print(f"     ✅ Sharpe CI (95%): [{eval_data['sharpe_ci_95'][0]:.3f}, {eval_data['sharpe_ci_95'][1]:.3f}]")
                print(f"     ✅ Deflated Sharpe: {eval_data['deflated_sharpe']:.4f}")

                # Print test results
                for test in eval_data['test_results']:
                    sig = "✅" if test.significant else "❌"
                    print(f"     {sig} {test.test_name}: p={test.p_value:.4f}")

                ticker_results['statistical_tests'] = [
                    {'name': t.test_name, 'p_value': t.p_value, 'significant': t.significant}
                    for t in eval_data['test_results']
                ]
                ticker_results['eval_data'] = eval_data

            # ==================================================================
            # STAGE 10: REPORT GENERATION
            # ==================================================================
            if generate_reports:
                print(f"\n  📄 Stage 10: Report Generation")

                try:
                    report_agent = ReportGenerationAgent(config=config)

                    # Prepare benchmark data if available
                    benchmark_equity = None
                    if benchmark_data is not None:
                        try:
                            bench_returns = benchmark_data['Returns'].loc[bt_data['returns'].index].dropna()
                            benchmark_equity = config.backtest.initial_capital * (1 + bench_returns).cumprod()
                        except:
                            pass

                    report_result = report_agent.run(
                        backtest_results=ticker_results['backtest'],
                        equity_curve=bt_data.get('equity_curve', pd.Series()),
                        returns=strategy_returns,
                        risk_metrics=ticker_results.get('risk', {
                            'var_95': 0, 'cvar_95': 0, 'volatility': 0,
                            'sortino_ratio': 0, 'calmar_ratio': 0
                        }),
                        benchmark_equity=benchmark_equity,
                        monte_carlo_results=ticker_results.get('monte_carlo', {}),
                        monte_carlo_simulations=ticker_results.get('monte_carlo', {}).get('simulations'),
                        statistical_tests=eval_result.data.get('test_results', []) if eval_result.success else [],
                        save_report=True
                    )

                    if report_result.success:
                        print(f"     ✅ Report saved: {report_result.data['report_path']}")
                        all_results['reports'].append(report_result.data['report_path'])
                        ticker_results['report_path'] = report_result.data['report_path']
                except Exception as e:
                    print(f"     ⚠️ Report generation failed: {e}")

            # ==================================================================
            # SAVE MODELS
            # ==================================================================
            if save_models:
                print(f"\n  💾 Saving Models")

                try:
                    model_path = save_model_artifact(
                        prediction_agent,
                        f"prediction_agent_{ticker}",
                        metadata={
                            'ticker': ticker,
                            'accuracy': ticker_results['ml_accuracy'],
                            'auc': ticker_results['ml_auc'],
                            'features': ticker_results['selected_features'],
                            'timestamp': datetime.now().isoformat()
                        }
                    )
                    print(f"     ✅ Model saved: {model_path}")
                    ticker_results['model_path'] = str(model_path)
                except Exception as e:
                    print(f"     ⚠️ Model save failed: {e}")

            # Store ticker results
            ticker_results['status'] = 'success'
            all_results['ticker_results'][ticker] = ticker_results

            print(f"\n  ✅ {ticker} processing complete!")

        except Exception as e:
            print(f"\n  ❌ Error processing {ticker}: {e}")
            traceback.print_exc()
            ticker_results['status'] = 'failed'
            ticker_results['error'] = str(e)
            all_results['ticker_results'][ticker] = ticker_results
            all_results['errors'].append(f"{ticker}: {e}")

    # ========================================================================
    # PORTFOLIO OPTIMIZATION (Multi-Asset)
    # ========================================================================
    successful_tickers = [t for t, r in all_results['ticker_results'].items()
                          if r.get('status') == 'success']

    if len(successful_tickers) >= 2:
        print("\n" + "=" * 70)
        print("💼 PORTFOLIO OPTIMIZATION")
        print("=" * 70)

        try:
            # Collect returns for successful tickers
            ticker_returns = {}
            for ticker in successful_tickers:
                if ticker in market_data:
                    ticker_returns[ticker] = market_data[ticker]['Returns'].dropna()

            # Create returns DataFrame
            returns_df = pd.DataFrame(ticker_returns).dropna()

            if len(returns_df) > 60:
                port_agent = PortfolioOptimizationAgent(config=config)
                port_result = port_agent.run(returns_df, method='max_sharpe')

                if port_result.success:
                    print(f"  ✅ Optimal Weights (Max Sharpe):")
                    for ticker, weight in port_result.data['weights'].items():
                        print(f"     {ticker}: {weight*100:.1f}%")
                    print(f"  ✅ Portfolio Sharpe: {port_result.data['sharpe_ratio']:.4f}")

                    all_results['portfolio_optimization'] = {
                        'weights': port_result.data['weights'].to_dict(),
                        'sharpe_ratio': port_result.data['sharpe_ratio'],
                        'annual_return': port_result.data['annual_return'],
                        'annual_volatility': port_result.data['annual_volatility']
                    }
        except Exception as e:
            print(f"  ⚠️ Portfolio optimization skipped: {e}")

    # ========================================================================
    # FINAL SUMMARY
    # ========================================================================
    total_time = time.time() - start_time
    all_results['total_time'] = total_time
    all_results['end_time'] = datetime.now().isoformat()

    # Store in global for visualization access
    PIPELINE_DATA['results'] = all_results

    print("\n" + "=" * 70)
    print("🏁 PIPELINE EXECUTION COMPLETE")
    print("=" * 70)
    print(f"  Total Time: {total_time:.2f} seconds ({total_time/60:.1f} minutes)")
    print(f"  Tickers Processed: {len(tickers)}")
    print(f"  Successful: {len(successful_tickers)}")
    print(f"  Failed: {len(tickers) - len(successful_tickers)}")
    print(f"  Reports Generated: {len(all_results['reports'])}")

    if all_results['errors']:
        print(f"\n  ⚠️ Errors ({len(all_results['errors'])}):")
        for error in all_results['errors'][:5]:
            print(f"     - {error}")

    print("\n  📊 Results Summary:")
    for ticker, results in all_results['ticker_results'].items():
        if results.get('status') == 'success':
            bt = results.get('backtest', {})
            print(f"     {ticker}: Return={bt.get('total_return', 0)*100:.2f}%, "
                  f"Sharpe={bt.get('sharpe_ratio', 0):.3f}, "
                  f"MaxDD={bt.get('max_drawdown', 0)*100:.1f}%")

    print("=" * 70)

    return all_results


def display_visualizations(pipeline_results: Dict[str, Any]):
    """
    Display visualizations for pipeline results.

    Args:
        pipeline_results: Results from run_complete_pipeline
    """
    print("\n" + "=" * 70)
    print("📊 GENERATING VISUALIZATIONS")
    print("=" * 70)

    # Get successful tickers
    successful_tickers = [
        t for t, r in pipeline_results['ticker_results'].items()
        if r.get('status') == 'success'
    ]

    if not successful_tickers:
        print("⚠️ No successful tickers to visualize")
        return

    # Create visualizer
    try:
        viz = QuantVisualizer()
    except:
        # Fallback if QuantVisualizer not defined
        viz = None

    for ticker in successful_tickers:
        print(f"\n📈 Visualizations for {ticker}:")

        ticker_data = pipeline_results['ticker_results'][ticker]

        # Get equity curve and returns
        equity_curve = ticker_data.get('equity_curve')
        strategy_returns = ticker_data.get('strategy_returns')

        # If equity curve not available, recreate from returns
        if equity_curve is None and strategy_returns is not None:
            equity_curve = config.backtest.initial_capital * (1 + strategy_returns).cumprod()

        if equity_curve is None:
            # Try to get from PIPELINE_DATA
            equity_curve = pipeline_results.get('equity_curves', {}).get(ticker)
            strategy_returns = pipeline_results.get('returns', {}).get(ticker)

            if equity_curve is None and strategy_returns is not None:
                equity_curve = config.backtest.initial_capital * (1 + strategy_returns).cumprod()

        if equity_curve is None:
            print(f"   ⚠️ No equity curve data available for {ticker}")
            continue

        if strategy_returns is None:
            strategy_returns = equity_curve.pct_change().dropna()

        # Get benchmark
        benchmark_equity = None
        if PIPELINE_DATA.get('benchmark_data') is not None:
            try:
                bench = PIPELINE_DATA['benchmark_data']
                bench_returns = bench['Returns'].loc[strategy_returns.index].dropna()
                benchmark_equity = config.backtest.initial_capital * (1 + bench_returns).cumprod()
            except:
                pass

        # Create dashboard
        if viz is not None:
            try:
                print(f"   → Creating full dashboard...")
                fig = viz.create_full_dashboard(
                    equity_curve,
                    strategy_returns,
                    benchmark_equity
                )
                plt.show()
            except Exception as e:
                print(f"   ⚠️ Dashboard creation failed: {e}")
                # Fallback to simple plots
                create_simple_visualizations(equity_curve, strategy_returns, benchmark_equity, ticker)
        else:
            create_simple_visualizations(equity_curve, strategy_returns, benchmark_equity, ticker)

        # Monte Carlo visualization if available
        mc_data = ticker_data.get('monte_carlo', {})
        if mc_data.get('simulations') is not None:
            try:
                print(f"   → Creating Monte Carlo chart...")
                if viz is not None:
                    fig = viz.plot_monte_carlo(mc_data['simulations'])
                else:
                    plot_monte_carlo_simple(mc_data['simulations'])
                plt.show()
            except Exception as e:
                print(f"   ⚠️ Monte Carlo chart failed: {e}")


def create_simple_visualizations(equity, returns, benchmark=None, ticker=""):
    """Create simple visualizations as fallback."""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(f'Strategy Performance - {ticker}', fontsize=14, fontweight='bold')

    # Equity curve
    ax1 = axes[0, 0]
    ax1.plot(equity.index, equity.values, label='Strategy', linewidth=2)
    if benchmark is not None:
        bench_norm = benchmark / benchmark.iloc[0] * equity.iloc[0]
        ax1.plot(bench_norm.index, bench_norm.values, label='Benchmark', alpha=0.7)
    ax1.set_title('Equity Curve')
    ax1.set_ylabel('Portfolio Value ($)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Drawdown
    ax2 = axes[0, 1]
    running_max = equity.expanding().max()
    drawdown = (equity - running_max) / running_max * 100
    ax2.fill_between(drawdown.index, drawdown.values, 0, color='red', alpha=0.5)
    ax2.set_title('Drawdown')
    ax2.set_ylabel('Drawdown (%)')
    ax2.grid(True, alpha=0.3)

    # Returns distribution
    ax3 = axes[1, 0]
    ax3.hist(returns.dropna() * 100, bins=50, alpha=0.7, edgecolor='white')
    ax3.axvline(x=0, color='black', linestyle='--')
    ax3.set_title('Daily Returns Distribution')
    ax3.set_xlabel('Return (%)')
    ax3.grid(True, alpha=0.3)

    # Rolling Sharpe
    ax4 = axes[1, 1]
    rf = 0.05 / 252
    rolling_sharpe = ((returns.rolling(63).mean() - rf) / returns.rolling(63).std()) * np.sqrt(252)
    ax4.plot(rolling_sharpe.index, rolling_sharpe.values)
    ax4.axhline(y=0, color='red', linestyle='--')
    ax4.axhline(y=1, color='green', linestyle='--', alpha=0.5)
    ax4.set_title('Rolling Sharpe Ratio (63-day)')
    ax4.grid(True, alpha=0.3)

    plt.tight_layout()


def plot_monte_carlo_simple(simulations, initial_value=100000):
    """Simple Monte Carlo plot."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    horizon = simulations.shape[1]
    x = np.arange(horizon)

    # Fan chart
    ax1 = axes[0]
    p5 = np.percentile(simulations, 5, axis=0)
    p25 = np.percentile(simulations, 25, axis=0)
    p50 = np.percentile(simulations, 50, axis=0)
    p75 = np.percentile(simulations, 75, axis=0)
    p95 = np.percentile(simulations, 95, axis=0)

    ax1.fill_between(x, p5, p95, alpha=0.2, color='blue', label='5-95%')
    ax1.fill_between(x, p25, p75, alpha=0.4, color='blue', label='25-75%')
    ax1.plot(x, p50, 'b-', linewidth=2, label='Median')
    ax1.axhline(y=initial_value, color='red', linestyle='--', label='Initial')
    ax1.set_title('Monte Carlo Simulation')
    ax1.set_xlabel('Days')
    ax1.set_ylabel('Portfolio Value ($)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # Terminal distribution
    ax2 = axes[1]
    terminal = simulations[:, -1]
    ax2.hist(terminal, bins=50, alpha=0.7, edgecolor='white')
    ax2.axvline(x=initial_value, color='red', linestyle='--', linewidth=2)
    ax2.axvline(x=np.median(terminal), color='green', linestyle='--', linewidth=2)
    ax2.set_title('Terminal Value Distribution')
    ax2.set_xlabel('Portfolio Value ($)')
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()


# ============================================================================
# EXECUTE PIPELINE
# ============================================================================

if RUN_FULL_PIPELINE:
    # Parse tickers
    tickers = [t.strip().upper() for t in TICKERS_TO_PROCESS.split(',')]

    # Run pipeline
    pipeline_results = run_complete_pipeline(
        tickers=tickers,
        generate_reports=GENERATE_REPORTS,
        save_models=SAVE_MODELS,
        verbose=VERBOSE
    )

    # Display visualizations
    display_visualizations(pipeline_results)

    print("\n✅ Pipeline execution complete!")
    print(f"📁 Reports saved to: {REPORTS_PATH}")
    print(f"📁 Models saved to: {MODELS_PATH}")

    # Provide download links in Colab
    if IN_COLAB and pipeline_results.get('reports'):
        print("\n📥 Report Download Links:")
        for report_path in pipeline_results['reports']:
            print(f"   {report_path}")

else:
    print("⏸️ Pipeline execution skipped.")
    print("   Set RUN_FULL_PIPELINE = True to execute.")