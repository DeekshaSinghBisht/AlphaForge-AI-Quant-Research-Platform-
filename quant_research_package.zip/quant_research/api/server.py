"""
api/server.py
=============
FastAPI app, Pydantic models, QuantAPIService
Run: uvicorn quant_research.api.server:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations


from typing import Dict, List, Optional, Any
from datetime import datetime
from pydantic import BaseModel, Field
import json
import pickle

# FastAPI imports
try:
    from fastapi import FastAPI, HTTPException, BackgroundTasks
    from fastapi.responses import JSONResponse
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
    FASTAPI_AVAILABLE = True
    print("✅ FastAPI available")
except ImportError:
    FASTAPI_AVAILABLE = False
    print("⚠️ FastAPI not available")


# ============================================================================
# Pydantic Models for API
# ============================================================================

class PredictionRequest(BaseModel):
    """Request model for predictions."""
    ticker: str = Field(..., description="Stock ticker symbol")
    features: Optional[Dict[str, float]] = Field(None, description="Feature values")

    class Config:
        schema_extra = {
            "example": {
                "ticker": "AAPL",
                "features": {"rsi": 45.5, "macd": 0.5}
            }
        }


class PredictionResponse(BaseModel):
    """Response model for predictions."""
    ticker: str
    prediction: int
    probability: float
    signal: str
    confidence: float
    timestamp: str

    class Config:
        schema_extra = {
            "example": {
                "ticker": "AAPL",
                "prediction": 1,
                "probability": 0.72,
                "signal": "BUY",
                "confidence": 0.72,
                "timestamp": "2024-01-15T10:30:00"
            }
        }


class HealthResponse(BaseModel):
    """Response model for health check."""
    status: str
    version: str
    timestamp: str
    models_loaded: List[str]


class BacktestRequest(BaseModel):
    """Request model for backtesting."""
    ticker: str
    start_date: str
    end_date: Optional[str] = None
    initial_capital: float = 100000

    class Config:
        schema_extra = {
            "example": {
                "ticker": "AAPL",
                "start_date": "2023-01-01",
                "end_date": "2023-12-31",
                "initial_capital": 100000
            }
        }


class BacktestResponse(BaseModel):
    """Response model for backtesting."""
    ticker: str
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    total_trades: int
    win_rate: float
    timestamp: str


# ============================================================================
# API Application
# ============================================================================

class QuantAPIService:
    """
    FastAPI service for quantitative research system.

    Provides REST endpoints for:
    - Predictions
    - Backtesting
    - Health checks
    """

    def __init__(self, config: SystemConfig = None):
        """
        Initialize API service.

        Args:
            config: System configuration
        """
        self.config = config or SystemConfig()
        self.app = FastAPI(
            title="AI Quantitative Research API",
            description="REST API for ML-driven quantitative trading research",
            version="2.0.0"
        )

        # Add CORS middleware
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Model storage
        self.models: Dict[str, Any] = {}
        self.data_cache: Dict[str, pd.DataFrame] = {}

        # Register routes
        self._register_routes()

    def _register_routes(self):
        """Register API routes."""

        @self.app.get("/", response_model=Dict[str, str])
        async def root():
            """Root endpoint."""
            return {
                "message": "AI Quantitative Research API",
                "version": "2.0.0",
                "docs": "/docs"
            }

        @self.app.get("/health", response_model=HealthResponse)
        async def health_check():
            """Health check endpoint."""
            return HealthResponse(
                status="healthy",
                version="2.0.0",
                timestamp=datetime.now().isoformat(),
                models_loaded=list(self.models.keys())
            )

        @self.app.post("/predict", response_model=PredictionResponse)
        async def predict(request: PredictionRequest):
            """
            Generate prediction for a ticker.

            Args:
                request: Prediction request

            Returns:
                Prediction response
            """
            try:
                # Get or fetch data
                ticker = request.ticker.upper()

                # Mock prediction for demo
                # In production, this would use actual models
                probability = 0.5 + np.random.randn() * 0.2
                probability = np.clip(probability, 0, 1)

                prediction = 1 if probability > 0.6 else (-1 if probability < 0.4 else 0)
                signal_map = {1: "BUY", 0: "HOLD", -1: "SELL"}

                return PredictionResponse(
                    ticker=ticker,
                    prediction=prediction,
                    probability=probability,
                    signal=signal_map[prediction],
                    confidence=abs(probability - 0.5) * 2,
                    timestamp=datetime.now().isoformat()
                )

            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.post("/backtest", response_model=BacktestResponse)
        async def backtest(request: BacktestRequest):
            """
            Run backtest for a ticker.

            Args:
                request: Backtest request

            Returns:
                Backtest response
            """
            try:
                # Mock backtest results for demo
                return BacktestResponse(
                    ticker=request.ticker.upper(),
                    total_return=np.random.uniform(-0.1, 0.3),
                    sharpe_ratio=np.random.uniform(0.5, 2.0),
                    max_drawdown=np.random.uniform(0.05, 0.2),
                    total_trades=np.random.randint(50, 200),
                    win_rate=np.random.uniform(0.45, 0.6),
                    timestamp=datetime.now().isoformat()
                )

            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/tickers", response_model=List[str])
        async def get_tickers():
            """Get available tickers."""
            return self.config.data.tickers

        @self.app.get("/config", response_model=Dict[str, Any])
        async def get_config():
            """Get system configuration."""
            return {
                "tickers": self.config.data.tickers,
                "start_date": self.config.data.start_date,
                "initial_capital": self.config.backtest.initial_capital,
                "commission": self.config.backtest.commission_pct
            }

    def load_model(self, name: str, model: Any) -> None:
        """Load a model into the service."""
        self.models[name] = model

    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """Run the API server."""
        uvicorn.run(self.app, host=host, port=port)


# ============================================================================
# Dockerfile Generation
# ============================================================================

DOCKERFILE_CONTENT = '''
# Dockerfile for AI Quantitative Research API
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \\
    build-essential \\
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 8000

# Run application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
'''

REQUIREMENTS_CONTENT = '''
fastapi>=0.85.0
uvicorn>=0.18.0
pydantic>=1.10.0
numpy>=1.21.0
pandas>=1.3.0
yfinance>=0.2.0
scikit-learn>=1.0.0
xgboost>=1.5.0
tensorflow>=2.10.0
'''


def generate_deployment_files(output_dir: Path = None):
    """Generate deployment files."""
    output_dir = output_dir or REPORTS_PATH

    # Save Dockerfile
    dockerfile_path = output_dir / "Dockerfile"
    with open(dockerfile_path, 'w') as f:
        f.write(DOCKERFILE_CONTENT)

    # Save requirements
    requirements_path = output_dir / "requirements_api.txt"
    with open(requirements_path, 'w') as f:
        f.write(REQUIREMENTS_CONTENT)

    print(f"✅ Deployment files generated:")
    print(f"   - {dockerfile_path}")
    print(f"   - {requirements_path}")

    return dockerfile_path, requirements_path


# Test API
print("=" * 70)
print("🧪 TESTING FASTAPI DEPLOYMENT")
print("=" * 70)

if FASTAPI_AVAILABLE:
    # Create API service
    api_service = QuantAPIService(config=config)

    print("\n✅ API Service created successfully!")
    print("\n📡 Available Endpoints:")
    for route in api_service.app.routes:
        if hasattr(route, 'path') and hasattr(route, 'methods'):
            methods = ', '.join(route.methods - {'HEAD', 'OPTIONS'})
            if methods:
                print(f"   {methods:6} {route.path}")

    # Generate deployment files
    print("\n📦 Generating deployment files...")
    generate_deployment_files()

    print("\n💡 To run the API server:")
    print("   api_service.run(host='0.0.0.0', port=8000)")
    print("\n💡 Or use uvicorn directly:")
    print("   uvicorn main:app --reload")
else:
    print("⚠️ FastAPI not available. Install with: pip install fastapi uvicorn")

print("\n" + "=" * 70)
print("✅ FastAPI Deployment Layer ready!")