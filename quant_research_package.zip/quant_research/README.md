# AI Quantitative Research System

**Multi-Agent ML Framework for Stock Price Direction Prediction**

> Spring Internship Project · IDEAS – ISI Kolkata · 2026  
> Refactored from a monolithic Jupyter notebook (`IDEAS_FINAL_15_03.ipynb`) into a fully modular Python package.

---

## Package Structure

```
quant_research/
│
├── __init__.py            Package metadata and layout docs
├── __main__.py            CLI entry point  (python -m quant_research)
├── config.py              PathManager · APIConfig · SystemConfig + all dataclasses
├── utils.py               Shared helpers: caching · metrics · formatting · artefacts
├── base.py                BaseAgent · MLAgent · DataAgent · AnalysisAgent · constants
├── pipeline.py            PipelineOrchestrator · run_complete_pipeline
├── setup.py               pip-installable package definition
├── requirements.txt       All dependencies with version pins
│
├── agents/
│   ├── data.py            MarketDataAgent · NewsAgent
│   ├── features.py        TechnicalIndicators · FeatureEngineeringAgent · FeatureSelectionAgent
│   ├── sentiment.py       SentimentAgent  (VADER primary, FinBERT advanced)
│   ├── regime.py          RegimeDetectionAgent  (HMM / GaussianMixture)
│   ├── prediction.py      WalkForwardValidator · PredictionAgent
│   └── evaluation.py      StrategyEvaluationAgent  (DSR, T-test, Mann-Whitney)
│
├── models/
│   ├── classical.py       LogisticRegressionAgent · RandomForestAgent · XGBoostAgent
│   ├── deep.py            AttentionLayer · build_lstm_model · LSTMAgent
│   ├── ensemble.py        EnsembleAgent  (Stacking meta-learner)
│   └── tuning.py          HyperparameterAgent  (Optuna TPE)
│
├── trading/
│   ├── signals.py         SignalGenerationAgent  (threshold optimisation)
│   ├── backtest.py        BacktraderEngine · BacktestingAgent
│   ├── risk.py            RiskManagementAgent  (VaR · CVaR · Beta · stress test)
│   ├── montecarlo.py      MonteCarloAgent  (5,000 bootstrap paths)
│   └── portfolio.py       PortfolioOptimizationAgent  (Max Sharpe · Min Var · Risk Parity)
│
├── reporting/
│   ├── charts.py          ReportGenerator  (chart helpers, base64 PNG embedding)
│   ├── report.py          ReportGenerationAgent  (full HTML research report)
│   └── dashboard.py       VisualizationDashboard · QuantVisualizer
│
├── api/
│   └── server.py          FastAPI app · QuantAPIService · Pydantic request/response models
│
└── tests/
    ├── unit_tests.py       29 unit tests  (pytest or unittest)
    └── integration_tests.py 6 end-to-end pipeline integration tests
```

---

## Quickstart

### 1 — Install

```bash
# Clone / unzip the package
cd quant_research/

# Install in editable mode (all core deps)
pip install -e .

# Install all optional extras (deep learning, NLP, explainability)
pip install -e ".[full]"

# TA-Lib requires the C library first:
#   Ubuntu/Colab:  apt-get install -y libta-lib-dev && pip install TA-Lib
#   macOS:         brew install ta-lib && pip install TA-Lib
```

### 2 — Set API keys

Copy `.env.example` to `.env` and fill in your keys:

```bash
FINNHUB_API_KEY=your_key_here
FRED_API_KEY=your_key_here
ALPHA_VANTAGE_API_KEY=your_key_here
```

Or set them as environment variables directly.

### 3 — Run the full pipeline

```bash
# Default: AAPL + MSFT, Jan 2010 – today, with reports and model saving
python -m quant_research

# Custom tickers, no report
python -m quant_research --tickers GOOGL NVDA TSLA --no-report

# Run pipeline then immediately start the inference API
python -m quant_research --serve --port 8000
```

### 4 — Use individual modules in your own code

```python
from quant_research.config import PathManager, SystemConfig
from quant_research.agents.data import MarketDataAgent
from quant_research.agents.features import FeatureEngineeringAgent
from quant_research.agents.features import FeatureSelectionAgent
from quant_research.models.classical import RandomForestAgent
from quant_research.agents.prediction import PredictionAgent
from quant_research.trading.signals import SignalGenerationAgent
from quant_research.trading.backtest import BacktestingAgent
from quant_research.trading.risk import RiskManagementAgent
from quant_research.trading.portfolio import PortfolioOptimizationAgent

# Build config
config = SystemConfig()
config.data_config.tickers = ["AAPL"]

# Fetch data
data_agent = MarketDataAgent(config)
result = data_agent.run(tickers=["AAPL"], start_date="2020-01-01")
df = result.data["AAPL"]

# Engineer features
feat_agent = FeatureEngineeringAgent(config)
feat_result = feat_agent.run(df)
features = feat_result.data["features"]

# Feature selection
sel_agent = FeatureSelectionAgent(config)
sel_result = sel_agent.run(features)
X_selected = sel_result.data["X_selected"]
y          = sel_result.data["y"]

# Walk-forward training
pred_agent = PredictionAgent(config)
ml_result  = pred_agent.run(X_selected, y)
print(ml_result.data["overall_accuracy"])   # e.g. 0.495

# Signals → backtest → risk
sig_result  = SignalGenerationAgent(config).run(ml_result.data["predictions"])
bt_result   = BacktestingAgent(config).run(df, sig_result.data["signals"])
risk_result = RiskManagementAgent(config).run(bt_result.data["equity_curve"])
print(risk_result.data["var_95"])
```

### 5 — Run tests

```bash
# Unit tests
python -m pytest quant_research/tests/unit_tests.py -v

# Integration tests
python -m pytest quant_research/tests/integration_tests.py -v

# All tests
python -m pytest quant_research/tests/ -v
```

### 6 — Start the inference API

```bash
uvicorn quant_research.api.server:app --host 0.0.0.0 --port 8000 --reload
```

Then open **http://localhost:8000/docs** for the interactive Swagger UI.

#### Example API call

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"ticker":"AAPL","features":{"rsi_14":58.3,"macd_histogram":0.42}}'
```

---

## Module Responsibilities

| Module | What it does | Cells it replaces |
|---|---|---|
| `config.py` | All configuration dataclasses, path management, API keys | 2, 3, 4, 5 |
| `utils.py` | Shared helpers, caching, metric calculations, model I/O | 7, 38 |
| `base.py` | Abstract base classes and type definitions | 8, 9 |
| `agents/data.py` | Market data and news article fetching | 10, 11 |
| `agents/features.py` | 113-feature engineering and 30-feature selection | 12, 13, 16 |
| `agents/sentiment.py` | VADER/FinBERT sentiment scoring | 14 |
| `agents/regime.py` | HMM/GMM regime detection | 15 |
| `models/classical.py` | LR, Random Forest, XGBoost | 17, 18 |
| `models/deep.py` | LSTM + Attention architecture and agent | 19, 20 |
| `models/ensemble.py` | Stacking meta-learner | 21 |
| `models/tuning.py` | Optuna hyperparameter optimisation | 22 |
| `agents/prediction.py` | Walk-forward validation orchestration | 23 |
| `trading/signals.py` | Threshold-based signal generation | 24 |
| `trading/backtest.py` | Backtrader + vectorized backtesting | 25, 26 |
| `trading/risk.py` | VaR, CVaR, beta, stress testing | 27 |
| `trading/montecarlo.py` | Bootstrap Monte Carlo simulation | 28 |
| `trading/portfolio.py` | Max Sharpe / Min Var / Risk Parity | 29 |
| `agents/evaluation.py` | Statistical significance testing | 30 |
| `reporting/charts.py` | Chart generation helpers | 31 |
| `reporting/report.py` | Full HTML research report | 32 |
| `reporting/dashboard.py` | Interactive visualisation dashboard | 36, 41 |
| `pipeline.py` | PipelineOrchestrator, env checks | 33, 39, 40 |
| `api/server.py` | FastAPI inference endpoints | 35 |
| `tests/unit_tests.py` | 29 unit tests | 34 |
| `tests/integration_tests.py` | 6 integration tests | 37 |

---

## Data Saved to Google Drive / Local Storage

All files land under `quant_research_system/` (or the directory you pass to `PathManager`):

| Folder | File(s) | Description |
|---|---|---|
| `config/` | `system_config.json`, `api_config.json` | Configuration snapshots |
| `logs/` | `QUANT_SYSTEM_YYYYMMDD.log` | Date-stamped run logs |
| `cache/` | `{cache_key}.pkl` | Cached market data |
| `models/` | `prediction_agent_{TICKER}_{timestamp}.pkl` | Trained prediction agents |
| `models/` | `{model}_scaler.pkl`, `lstm_model.h5` | Scalers and Keras weights |
| `results/reports/` | `research_report_{timestamp}.html` | Full HTML research reports |

---

## Key Results (from original notebook run, 15 Mar 2026)

| Ticker | WF Accuracy | WF AUC | Backtest Return | Sharpe | Max DD |
|---|---|---|---|---|---|
| AAPL | 49.5% | 0.573 | +94.92% | 1.86 | 2.18% |
| MSFT | 55.2% | 0.592 | +237.08% | 2.38 | 1.92% |

---

## License

Academic and educational use only.  
Not financial advice. Do not use for live trading without independent validation.
