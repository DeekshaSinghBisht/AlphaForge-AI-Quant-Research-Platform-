"""
setup.py
========
Install the quant_research package:
    pip install -e .
"""
from setuptools import setup, find_packages
from pathlib import Path

long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="quant_research",
    version="2.0.0",
    author="IDEAS Internship 2026",
    description="Multi-Agent ML Framework for Stock Price Direction Prediction",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(exclude=["*.tests", "*.tests.*"]),
    python_requires=">=3.9",
    install_requires=[
        "numpy>=1.21.0",
        "pandas>=1.3.0",
        "scipy>=1.7.0",
        "yfinance>=0.2.0",
        "requests>=2.28.0",
        "scikit-learn>=1.0.0",
        "xgboost>=1.5.0",
        "optuna>=3.0.0",
        "joblib>=1.1.0",
        "ta>=0.10.0",
        "vaderSentiment>=3.3.2",
        "backtrader>=1.9.76",
        "cvxpy>=1.2.0",
        "hmmlearn>=0.2.7",
        "matplotlib>=3.5.0",
        "seaborn>=0.11.0",
        "jinja2>=3.1.0",
        "fastapi>=0.85.0",
        "uvicorn>=0.18.0",
        "pydantic>=1.10.0",
        "tqdm>=4.64.0",
        "python-dateutil>=2.8.0",
    ],
    extras_require={
        "deep_learning": ["tensorflow>=2.10.0", "torch>=1.12.0"],
        "nlp":           ["transformers>=4.20.0"],
        "explainability":["shap>=0.41.0"],
        "full": [
            "tensorflow>=2.10.0", "torch>=1.12.0",
            "transformers>=4.20.0", "shap>=0.41.0",
            "finnhub-python>=2.4.0", "fredapi>=0.5.0",
            "statsmodels>=0.13.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "quant-run=quant_research.__main__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Office/Business :: Financial",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
