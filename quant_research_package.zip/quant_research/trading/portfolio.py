"""
portfolio.py
============
PortfolioOptimizationAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Tuple, Union
from scipy.optimize import minimize
from scipy.cluster.hierarchy import linkage, dendrogram, leaves_list
from scipy.spatial.distance import squareform
import warnings
warnings.filterwarnings('ignore')

try:
    import cvxpy as cp
    CVXPY_AVAILABLE = True
    print("✅ CVXPY available for convex optimization")
except ImportError:
    CVXPY_AVAILABLE = False
    print("⚠️ CVXPY not available, using scipy optimization")


class PortfolioOptimizationAgent(BaseAgent):
    """
    Portfolio optimization agent.

    Features:
    - Mean-Variance Optimization (Markowitz)
    - Maximum Sharpe Ratio
    - Minimum Variance
    - Risk Parity
    - Hierarchical Risk Parity (HRP)

    Attributes:
        weights: Optimized portfolio weights
        returns: Expected returns
        cov_matrix: Covariance matrix
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        risk_free_rate: float = 0.05
    ):
        """
        Initialize Portfolio Optimization Agent.

        Args:
            config: System configuration
            logger: Logger instance
            risk_free_rate: Annual risk-free rate
        """
        super().__init__("PortfolioOptimizationAgent", config, logger)

        self.risk_free_rate = risk_free_rate or self.config.risk.risk_free_rate
        self.weights: Optional[pd.Series] = None
        self.expected_returns: Optional[pd.Series] = None
        self.cov_matrix: Optional[pd.DataFrame] = None
        self.optimization_results: Dict[str, Any] = {}

    def calculate_expected_returns(
        self,
        returns: pd.DataFrame,
        method: str = 'mean'
    ) -> pd.Series:
        """
        Calculate expected returns for each asset.

        Args:
            returns: Returns DataFrame
            method: 'mean', 'ewm', or 'capm'

        Returns:
            Expected returns series
        """
        if method == 'mean':
            exp_returns = returns.mean() * 252  # Annualize
        elif method == 'ewm':
            exp_returns = returns.ewm(span=60).mean().iloc[-1] * 252
        elif method == 'capm':
            # Simplified CAPM (would need market returns)
            exp_returns = returns.mean() * 252
        else:
            exp_returns = returns.mean() * 252

        self.expected_returns = exp_returns
        return exp_returns

    def calculate_covariance_matrix(
        self,
        returns: pd.DataFrame,
        method: str = 'sample'
    ) -> pd.DataFrame:
        """
        Calculate covariance matrix.

        Args:
            returns: Returns DataFrame
            method: 'sample', 'ewm', or 'shrinkage'

        Returns:
            Covariance matrix
        """
        if method == 'sample':
            cov = returns.cov() * 252  # Annualize
        elif method == 'ewm':
            cov = returns.ewm(span=60).cov().iloc[-len(returns.columns):] * 252
        elif method == 'shrinkage':
            # Ledoit-Wolf shrinkage
            sample_cov = returns.cov() * 252
            n = len(returns)
            p = len(returns.columns)

            # Shrinkage target (identity scaled by average variance)
            mu = np.trace(sample_cov) / p
            delta = sample_cov.copy()

            # Shrinkage intensity (simplified)
            shrinkage = min(1, max(0, (1 - 2/p) / n))

            cov = (1 - shrinkage) * sample_cov + shrinkage * mu * np.eye(p)
            cov = pd.DataFrame(cov, index=returns.columns, columns=returns.columns)
        else:
            cov = returns.cov() * 252

        self.cov_matrix = cov
        return cov

    def optimize_mean_variance(
        self,
        returns: pd.DataFrame,
        target_return: Optional[float] = None,
        risk_aversion: float = 1.0
    ) -> pd.Series:
        """
        Mean-Variance Optimization (Markowitz).

        Args:
            returns: Returns DataFrame
            target_return: Target annual return
            risk_aversion: Risk aversion parameter

        Returns:
            Optimal weights
        """
        self.logger.info("Running Mean-Variance Optimization...")

        n_assets = len(returns.columns)
        exp_returns = self.calculate_expected_returns(returns)
        cov_matrix = self.calculate_covariance_matrix(returns)

        # Initial weights
        init_weights = np.ones(n_assets) / n_assets

        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1}  # Weights sum to 1
        ]

        if target_return is not None:
            constraints.append({
                'type': 'eq',
                'fun': lambda w: np.dot(w, exp_returns) - target_return
            })

        # Bounds (0 to max_weight per asset)
        max_weight = self.config.portfolio.max_weight
        bounds = tuple((0, max_weight) for _ in range(n_assets))

        # Objective: minimize variance (or maximize utility)
        def objective(weights):
            portfolio_return = np.dot(weights, exp_returns)
            portfolio_var = np.dot(weights.T, np.dot(cov_matrix, weights))
            # Utility = return - (risk_aversion/2) * variance
            return -portfolio_return + (risk_aversion / 2) * portfolio_var

        result = minimize(
            objective,
            init_weights,
            method='SLSQP',
            bounds=bounds,
            constraints=constraints
        )

        weights = pd.Series(result.x, index=returns.columns)
        weights = weights.clip(lower=0)  # Ensure non-negative
        weights = weights / weights.sum()  # Normalize

        self.weights = weights
        return weights

    def optimize_max_sharpe(
        self,
        returns: pd.DataFrame
    ) -> pd.Series:
        """
        Maximum Sharpe Ratio Optimization.

        Args:
            returns: Returns DataFrame

        Returns:
            Optimal weights
        """
        self.logger.info("Running Maximum Sharpe Ratio Optimization...")

        n_assets = len(returns.columns)
        exp_returns = self.calculate_expected_returns(returns)
        cov_matrix = self.calculate_covariance_matrix(returns)

        init_weights = np.ones(n_assets) / n_assets

        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1}
        ]

        # Bounds
        max_weight = self.config.portfolio.max_weight
        bounds = tuple((0, max_weight) for _ in range(n_assets))

        # Objective: maximize Sharpe ratio (minimize negative Sharpe)
        def neg_sharpe(weights):
            portfolio_return = np.dot(weights, exp_returns)
            portfolio_std = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))

            if portfolio_std == 0:
                return np.inf

            sharpe = (portfolio_return - self.risk_free_rate) / portfolio_std
            return -sharpe

        result = minimize(
            neg_sharpe,
            init_weights,
            method='SLSQP',
            bounds=bounds,
            constraints=constraints
        )

        weights = pd.Series(result.x, index=returns.columns)
        weights = weights.clip(lower=0)
        weights = weights / weights.sum()

        self.weights = weights
        return weights

    def optimize_min_variance(
        self,
        returns: pd.DataFrame
    ) -> pd.Series:
        """
        Minimum Variance Portfolio.

        Args:
            returns: Returns DataFrame

        Returns:
            Optimal weights
        """
        self.logger.info("Running Minimum Variance Optimization...")

        n_assets = len(returns.columns)
        cov_matrix = self.calculate_covariance_matrix(returns)

        init_weights = np.ones(n_assets) / n_assets

        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1}
        ]

        max_weight = self.config.portfolio.max_weight
        bounds = tuple((0, max_weight) for _ in range(n_assets))

        def portfolio_variance(weights):
            return np.dot(weights.T, np.dot(cov_matrix, weights))

        result = minimize(
            portfolio_variance,
            init_weights,
            method='SLSQP',
            bounds=bounds,
            constraints=constraints
        )

        weights = pd.Series(result.x, index=returns.columns)
        weights = weights.clip(lower=0)
        weights = weights / weights.sum()

        self.weights = weights
        return weights

    def optimize_risk_parity(
        self,
        returns: pd.DataFrame
    ) -> pd.Series:
        """
        Risk Parity Portfolio.

        Each asset contributes equally to portfolio risk.

        Args:
            returns: Returns DataFrame

        Returns:
            Optimal weights
        """
        self.logger.info("Running Risk Parity Optimization...")

        n_assets = len(returns.columns)
        cov_matrix = self.calculate_covariance_matrix(returns).values

        init_weights = np.ones(n_assets) / n_assets

        def risk_parity_objective(weights):
            """Minimize sum of squared differences from equal risk contribution."""
            weights = np.abs(weights)
            weights = weights / weights.sum()

            portfolio_var = np.dot(weights.T, np.dot(cov_matrix, weights))
            portfolio_std = np.sqrt(portfolio_var)

            # Marginal risk contribution
            marginal_contrib = np.dot(cov_matrix, weights)

            # Risk contribution
            risk_contrib = weights * marginal_contrib / portfolio_std

            # Target: equal risk contribution
            target_contrib = portfolio_std / n_assets

            # Minimize sum of squared differences
            return np.sum((risk_contrib - target_contrib) ** 2)

        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(np.abs(w)) - 1}
        ]

        result = minimize(
            risk_parity_objective,
            init_weights,
            method='SLSQP',
            constraints=constraints
        )

        weights = np.abs(result.x)
        weights = weights / weights.sum()
        weights = pd.Series(weights, index=returns.columns)

        self.weights = weights
        return weights

    def optimize_hrp(
        self,
        returns: pd.DataFrame
    ) -> pd.Series:
        """
        Hierarchical Risk Parity (HRP).

        Uses hierarchical clustering to build a diversified portfolio.

        Args:
            returns: Returns DataFrame

        Returns:
            Optimal weights
        """
        self.logger.info("Running Hierarchical Risk Parity Optimization...")

        # Calculate correlation and covariance
        corr = returns.corr()
        cov = returns.cov() * 252

        # Distance matrix
        dist = np.sqrt(0.5 * (1 - corr))

        # Hierarchical clustering
        link = linkage(squareform(dist.values), method='ward')

        # Get sorted indices
        sorted_indices = leaves_list(link)
        sorted_tickers = [returns.columns[i] for i in sorted_indices]

        # Recursive bisection
        def get_cluster_var(cov, cluster_items):
            """Calculate cluster variance."""
            cov_slice = cov.loc[cluster_items, cluster_items]
            w = np.ones(len(cluster_items)) / len(cluster_items)
            return np.dot(w, np.dot(cov_slice, w))

        def recursive_bisection(cov, sorted_items):
            """Recursively bisect and allocate weights."""
            weights = pd.Series(1.0, index=sorted_items)

            clusters = [sorted_items]

            while len(clusters) > 0:
                # Split clusters
                new_clusters = []
                for cluster in clusters:
                    if len(cluster) > 1:
                        # Split in half
                        mid = len(cluster) // 2
                        left = cluster[:mid]
                        right = cluster[mid:]

                        # Calculate variance of each half
                        var_left = get_cluster_var(cov, left)
                        var_right = get_cluster_var(cov, right)

                        # Allocate inversely proportional to variance
                        alpha = 1 - var_left / (var_left + var_right)

                        weights[left] *= alpha
                        weights[right] *= (1 - alpha)

                        if len(left) > 1:
                            new_clusters.append(left)
                        if len(right) > 1:
                            new_clusters.append(right)

                clusters = new_clusters

            return weights

        weights = recursive_bisection(cov, sorted_tickers)
        weights = weights.reindex(returns.columns)
        weights = weights / weights.sum()

        self.weights = weights
        return weights

    def optimize(
        self,
        returns: pd.DataFrame,
        method: str = 'max_sharpe',
        **kwargs
    ) -> pd.Series:
        """
        Run portfolio optimization.

        Args:
            returns: Returns DataFrame
            method: Optimization method
            **kwargs: Additional parameters

        Returns:
            Optimal weights
        """
        if method == 'mean_variance' or method == 'markowitz':
            return self.optimize_mean_variance(returns, **kwargs)
        elif method == 'max_sharpe':
            return self.optimize_max_sharpe(returns)
        elif method == 'min_variance':
            return self.optimize_min_variance(returns)
        elif method == 'risk_parity':
            return self.optimize_risk_parity(returns)
        elif method == 'hrp':
            return self.optimize_hrp(returns)
        elif method == 'equal_weight':
            weights = pd.Series(1.0 / len(returns.columns), index=returns.columns)
            self.weights = weights
            return weights
        else:
            return self.optimize_max_sharpe(returns)

    def calculate_portfolio_metrics(
        self,
        returns: pd.DataFrame,
        weights: Optional[pd.Series] = None
    ) -> Dict[str, float]:
        """
        Calculate portfolio performance metrics.

        Args:
            returns: Returns DataFrame
            weights: Portfolio weights (uses self.weights if None)

        Returns:
            Dictionary of metrics
        """
        weights = weights if weights is not None else self.weights

        if weights is None:
            raise ValueError("No weights available")

        # Align weights with returns columns
        weights = weights.reindex(returns.columns).fillna(0)

        # Portfolio returns
        portfolio_returns = (returns * weights).sum(axis=1)

        # Annualized metrics
        annual_return = portfolio_returns.mean() * 252
        annual_vol = portfolio_returns.std() * np.sqrt(252)
        sharpe = (annual_return - self.risk_free_rate) / annual_vol if annual_vol > 0 else 0

        # Drawdown
        equity = (1 + portfolio_returns).cumprod()
        running_max = equity.expanding().max()
        drawdown = (equity - running_max) / running_max
        max_dd = abs(drawdown.min())

        # Sortino
        downside_returns = portfolio_returns[portfolio_returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0.001
        sortino = (annual_return - self.risk_free_rate) / downside_std

        # Calmar
        calmar = annual_return / max_dd if max_dd > 0 else 0

        return {
            'annual_return': annual_return,
            'annual_volatility': annual_vol,
            'sharpe_ratio': sharpe,
            'sortino_ratio': sortino,
            'calmar_ratio': calmar,
            'max_drawdown': max_dd
        }

    def get_efficient_frontier(
        self,
        returns: pd.DataFrame,
        n_points: int = 50
    ) -> pd.DataFrame:
        """
        Calculate efficient frontier.

        Args:
            returns: Returns DataFrame
            n_points: Number of points on the frontier

        Returns:
            DataFrame with frontier points
        """
        self.logger.info("Calculating efficient frontier...")

        exp_returns = self.calculate_expected_returns(returns)

        # Range of target returns
        min_ret = exp_returns.min()
        max_ret = exp_returns.max()
        target_returns = np.linspace(min_ret, max_ret, n_points)

        frontier = []

        for target in target_returns:
            try:
                weights = self.optimize_mean_variance(returns, target_return=target)
                metrics = self.calculate_portfolio_metrics(returns, weights)

                frontier.append({
                    'target_return': target,
                    'return': metrics['annual_return'],
                    'volatility': metrics['annual_volatility'],
                    'sharpe': metrics['sharpe_ratio']
                })
            except:
                continue

        return pd.DataFrame(frontier)

    def run(
        self,
        returns: pd.DataFrame,
        method: str = 'max_sharpe',
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            returns: Returns DataFrame
            method: Optimization method

        Returns:
            AgentResult with optimization results
        """
        def execute():
            # Run optimization
            weights = self.optimize(returns, method, **kwargs)

            # Calculate metrics
            metrics = self.calculate_portfolio_metrics(returns, weights)

            # Calculate all method weights for comparison
            all_weights = {}
            for m in ['equal_weight', 'max_sharpe', 'min_variance', 'risk_parity']:
                try:
                    all_weights[m] = self.optimize(returns, m)
                except:
                    pass

            return {
                'weights': weights,
                'method': method,
                'metrics': metrics,
                'expected_returns': self.expected_returns,
                'covariance_matrix': self.cov_matrix,
                'annual_return': metrics['annual_return'],
                'annual_volatility': metrics['annual_volatility'],
                'sharpe_ratio': metrics['sharpe_ratio'],
                'max_drawdown': metrics['max_drawdown'],
                'all_method_weights': all_weights
            }

        return self._execute_with_timing(execute)


# Test Portfolio Optimization Agent
print("=" * 70)
print("🧪 TESTING PORTFOLIO OPTIMIZATION")
print("=" * 70)

# Generate sample multi-asset returns
np.random.seed(42)
n_days = 500
n_assets = 6
tickers = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'TSLA']

# Create correlated returns
mean_returns = np.array([0.0003, 0.0002, 0.00025, 0.00035, 0.0004, 0.0005])
cov_factor = np.random.randn(n_assets, 3) * 0.01
cov_matrix = np.dot(cov_factor, cov_factor.T) + np.diag(np.random.rand(n_assets) * 0.0001)

sample_asset_returns = pd.DataFrame(
    np.random.multivariate_normal(mean_returns, cov_matrix, n_days),
    columns=tickers,
    index=pd.date_range(start='2021-01-01', periods=n_days, freq='D')
)

print(f"\nAsset returns shape: {sample_asset_returns.shape}")
print(f"Assets: {list(sample_asset_returns.columns)}")

# Test Portfolio Optimization
port_agent = PortfolioOptimizationAgent(config=config)
port_result = port_agent.run(sample_asset_returns, method='max_sharpe')

if port_result.success:
    print(f"\n✅ Portfolio optimization completed!")
    print(f"\n📊 Optimal Weights (Max Sharpe):")
    for ticker, weight in port_result.data['weights'].items():
        print(f"   {ticker}: {weight*100:.1f}%")

    print(f"\n📈 Portfolio Metrics:")
    print(f"   Annual Return: {port_result.data['annual_return']*100:.2f}%")
    print(f"   Annual Volatility: {port_result.data['annual_volatility']*100:.2f}%")
    print(f"   Sharpe Ratio: {port_result.data['sharpe_ratio']:.3f}")
    print(f"   Max Drawdown: {port_result.data['max_drawdown']*100:.2f}%")

    print(f"\n📋 Comparison of Methods:")
    for method, weights in port_result.data['all_method_weights'].items():
        metrics = port_agent.calculate_portfolio_metrics(sample_asset_returns, weights)
        print(f"   {method}: Sharpe={metrics['sharpe_ratio']:.3f}, Vol={metrics['annual_volatility']*100:.1f}%")
else:
    print(f"❌ Error: {port_result.errors}")

print("\n" + "=" * 70)
print("✅ Portfolio Optimization Agent ready!")