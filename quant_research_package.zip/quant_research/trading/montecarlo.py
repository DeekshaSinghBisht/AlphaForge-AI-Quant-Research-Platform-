"""
montecarlo.py
=============
MonteCarloAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Tuple
from dataclasses import dataclass
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


@dataclass
class MonteCarloResults:
    """Data class for Monte Carlo simulation results."""
    simulations: np.ndarray
    terminal_values: np.ndarray
    mean_terminal: float
    median_terminal: float
    std_terminal: float
    percentile_5: float
    percentile_25: float
    percentile_75: float
    percentile_95: float
    probability_profit: float
    probability_double: float
    probability_ruin: float
    expected_return: float
    var_95: float
    cvar_95: float


class MonteCarloAgent(AnalysisAgent):
    """
    Monte Carlo simulation agent for portfolio analysis.

    Features:
    - Bootstrap historical returns
    - Parametric simulation
    - Path-dependent analysis
    - Probability distributions

    Attributes:
        simulations: Simulation paths
        results: Simulation results
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        n_simulations: int = 10000,
        horizon: int = 252
    ):
        """
        Initialize Monte Carlo Agent.

        Args:
            config: System configuration
            logger: Logger instance
            n_simulations: Number of simulations
            horizon: Simulation horizon in days
        """
        super().__init__("MonteCarloAgent", config, logger)

        self.n_simulations = n_simulations or self.config.risk.monte_carlo_simulations
        self.horizon = horizon or self.config.risk.monte_carlo_horizon

        self.simulations: Optional[np.ndarray] = None
        self.results: Optional[MonteCarloResults] = None

    def simulate_bootstrap(
        self,
        returns: pd.Series,
        initial_value: float = 100000,
        n_simulations: Optional[int] = None,
        horizon: Optional[int] = None
    ) -> np.ndarray:
        """
        Run Monte Carlo simulation using bootstrap resampling.

        Args:
            returns: Historical returns series
            initial_value: Initial portfolio value
            n_simulations: Number of simulations
            horizon: Simulation horizon

        Returns:
            Array of simulation paths (n_simulations x horizon)
        """
        n_sims = n_simulations or self.n_simulations
        h = horizon or self.horizon

        self.logger.info(f"Running {n_sims:,} bootstrap simulations...")

        returns_array = returns.dropna().values

        # Bootstrap sample returns
        sampled_returns = np.random.choice(
            returns_array,
            size=(n_sims, h),
            replace=True
        )

        # Calculate cumulative returns
        cumulative_returns = np.cumprod(1 + sampled_returns, axis=1)

        # Calculate portfolio values
        simulations = initial_value * cumulative_returns

        self.simulations = simulations

        return simulations

    def simulate_parametric(
        self,
        returns: pd.Series,
        initial_value: float = 100000,
        n_simulations: Optional[int] = None,
        horizon: Optional[int] = None,
        distribution: str = 'normal'
    ) -> np.ndarray:
        """
        Run Monte Carlo simulation using parametric distribution.

        Args:
            returns: Historical returns series
            initial_value: Initial portfolio value
            n_simulations: Number of simulations
            horizon: Simulation horizon
            distribution: 'normal' or 't'

        Returns:
            Array of simulation paths
        """
        n_sims = n_simulations or self.n_simulations
        h = horizon or self.horizon

        self.logger.info(f"Running {n_sims:,} parametric simulations ({distribution})...")

        returns_array = returns.dropna().values
        mu = returns_array.mean()
        sigma = returns_array.std()

        if distribution == 'normal':
            sampled_returns = np.random.normal(mu, sigma, size=(n_sims, h))
        elif distribution == 't':
            # Fit t-distribution
            df, loc, scale = stats.t.fit(returns_array)
            sampled_returns = stats.t.rvs(df, loc=loc, scale=scale, size=(n_sims, h))
        else:
            sampled_returns = np.random.normal(mu, sigma, size=(n_sims, h))

        # Calculate cumulative returns
        cumulative_returns = np.cumprod(1 + sampled_returns, axis=1)

        # Calculate portfolio values
        simulations = initial_value * cumulative_returns

        self.simulations = simulations

        return simulations

    def simulate_gbm(
        self,
        returns: pd.Series,
        initial_value: float = 100000,
        n_simulations: Optional[int] = None,
        horizon: Optional[int] = None
    ) -> np.ndarray:
        """
        Run Monte Carlo simulation using Geometric Brownian Motion.

        Args:
            returns: Historical returns series
            initial_value: Initial portfolio value
            n_simulations: Number of simulations
            horizon: Simulation horizon

        Returns:
            Array of simulation paths
        """
        n_sims = n_simulations or self.n_simulations
        h = horizon or self.horizon

        self.logger.info(f"Running {n_sims:,} GBM simulations...")

        returns_array = returns.dropna().values
        mu = returns_array.mean() * 252  # Annualize
        sigma = returns_array.std() * np.sqrt(252)  # Annualize

        dt = 1 / 252  # Daily steps

        # Generate random walks
        Z = np.random.standard_normal(size=(n_sims, h))

        # GBM formula
        drift = (mu - 0.5 * sigma**2) * dt
        diffusion = sigma * np.sqrt(dt) * Z

        log_returns = drift + diffusion
        cumulative_log_returns = np.cumsum(log_returns, axis=1)

        # Calculate portfolio values
        simulations = initial_value * np.exp(cumulative_log_returns)

        self.simulations = simulations

        return simulations

    def calculate_results(
        self,
        initial_value: float = 100000,
        ruin_threshold: float = 0.5
    ) -> MonteCarloResults:
        """
        Calculate statistics from simulation results.

        Args:
            initial_value: Initial portfolio value
            ruin_threshold: Threshold for ruin (fraction of initial)

        Returns:
            MonteCarloResults object
        """
        if self.simulations is None:
            raise ValueError("No simulations available. Run a simulation first.")

        terminal_values = self.simulations[:, -1]

        # Basic statistics
        mean_terminal = np.mean(terminal_values)
        median_terminal = np.median(terminal_values)
        std_terminal = np.std(terminal_values)

        # Percentiles
        percentile_5 = np.percentile(terminal_values, 5)
        percentile_25 = np.percentile(terminal_values, 25)
        percentile_75 = np.percentile(terminal_values, 75)
        percentile_95 = np.percentile(terminal_values, 95)

        # Probabilities
        probability_profit = np.mean(terminal_values > initial_value)
        probability_double = np.mean(terminal_values > 2 * initial_value)
        probability_ruin = np.mean(terminal_values < initial_value * ruin_threshold)

        # Expected return
        expected_return = (mean_terminal / initial_value) - 1

        # Risk metrics
        returns = terminal_values / initial_value - 1
        var_95 = np.percentile(returns, 5)
        cvar_95 = np.mean(returns[returns <= var_95])

        results = MonteCarloResults(
            simulations=self.simulations,
            terminal_values=terminal_values,
            mean_terminal=mean_terminal,
            median_terminal=median_terminal,
            std_terminal=std_terminal,
            percentile_5=percentile_5,
            percentile_25=percentile_25,
            percentile_75=percentile_75,
            percentile_95=percentile_95,
            probability_profit=probability_profit,
            probability_double=probability_double,
            probability_ruin=probability_ruin,
            expected_return=expected_return,
            var_95=var_95,
            cvar_95=cvar_95
        )

        self.results = results

        return results

    def get_confidence_intervals(
        self,
        confidence_levels: List[float] = [0.50, 0.75, 0.90, 0.95]
    ) -> Dict[float, Tuple[np.ndarray, np.ndarray]]:
        """
        Get confidence interval paths.

        Args:
            confidence_levels: List of confidence levels

        Returns:
            Dictionary of confidence level to (lower, upper) paths
        """
        if self.simulations is None:
            return {}

        intervals = {}

        for level in confidence_levels:
            alpha = (1 - level) / 2
            lower = np.percentile(self.simulations, alpha * 100, axis=0)
            upper = np.percentile(self.simulations, (1 - alpha) * 100, axis=0)
            intervals[level] = (lower, upper)

        return intervals

    def get_path_statistics(self) -> pd.DataFrame:
        """Get statistics at each time step."""
        if self.simulations is None:
            return pd.DataFrame()

        stats_df = pd.DataFrame({
            'mean': np.mean(self.simulations, axis=0),
            'median': np.median(self.simulations, axis=0),
            'std': np.std(self.simulations, axis=0),
            'min': np.min(self.simulations, axis=0),
            'max': np.max(self.simulations, axis=0),
            'p5': np.percentile(self.simulations, 5, axis=0),
            'p95': np.percentile(self.simulations, 95, axis=0)
        })

        return stats_df

    def analyze(
        self,
        data: pd.DataFrame,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Perform Monte Carlo analysis.

        Args:
            data: DataFrame with returns column

        Returns:
            Analysis results
        """
        if 'returns' in data.columns:
            returns = data['returns']
        else:
            returns = data.iloc[:, 0]

        # Run simulation
        self.simulate_bootstrap(returns, **kwargs)

        # Calculate results
        results = self.calculate_results(kwargs.get('initial_value', 100000))

        self.analysis_results = {
            'expected_return': results.expected_return,
            'probability_profit': results.probability_profit,
            'var_95': results.var_95,
            'cvar_95': results.cvar_95
        }

        return self.analysis_results

    def run(
        self,
        returns: pd.Series,
        initial_value: float = 100000,
        method: str = 'bootstrap',
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            returns: Historical returns
            initial_value: Initial portfolio value
            method: Simulation method ('bootstrap', 'parametric', 'gbm')

        Returns:
            AgentResult with simulation results
        """
        def execute():
            # Run simulation
            if method == 'bootstrap':
                self.simulate_bootstrap(returns, initial_value, **kwargs)
            elif method == 'parametric':
                self.simulate_parametric(returns, initial_value, **kwargs)
            elif method == 'gbm':
                self.simulate_gbm(returns, initial_value, **kwargs)
            else:
                self.simulate_bootstrap(returns, initial_value, **kwargs)

            # Calculate results
            results = self.calculate_results(initial_value)

            # Get confidence intervals
            ci = self.get_confidence_intervals()

            # Get path statistics
            path_stats = self.get_path_statistics()

            return {
                'results': results,
                'simulations': self.simulations,
                'terminal_values': results.terminal_values,
                'mean_terminal': results.mean_terminal,
                'median_terminal': results.median_terminal,
                'probability_profit': results.probability_profit,
                'probability_double': results.probability_double,
                'probability_ruin': results.probability_ruin,
                'expected_return': results.expected_return,
                'var_95': results.var_95,
                'cvar_95': results.cvar_95,
                'confidence_intervals': ci,
                'path_statistics': path_stats,
                'n_simulations': self.n_simulations,
                'horizon': self.horizon
            }

        return self._execute_with_timing(execute)


# Test Monte Carlo Agent
print("=" * 70)
print("🧪 TESTING MONTE CARLO SIMULATION")
print("=" * 70)

# Use sample returns from previous cell
if 'sample_returns' in dir():
    mc_agent = MonteCarloAgent(
        config=config,
        n_simulations=5000,  # Reduced for demo
        horizon=252
    )

    print("\n🎲 Running Monte Carlo simulation...")
    mc_result = mc_agent.run(sample_returns, initial_value=100000, method='bootstrap')

    if mc_result.success:
        print(f"\n✅ Monte Carlo simulation completed!")
        print(f"   Simulations: {mc_result.data['n_simulations']:,}")
        print(f"   Horizon: {mc_result.data['horizon']} days")
        print(f"\n📊 Terminal Value Statistics:")
        print(f"   Mean: ${mc_result.data['mean_terminal']:,.2f}")
        print(f"   Median: ${mc_result.data['median_terminal']:,.2f}")
        print(f"\n📈 Probabilities:")
        print(f"   Probability of Profit: {mc_result.data['probability_profit']*100:.1f}%")
        print(f"   Probability of Doubling: {mc_result.data['probability_double']*100:.1f}%")
        print(f"   Probability of Ruin (50%): {mc_result.data['probability_ruin']*100:.1f}%")
        print(f"\n⚠️ Risk Metrics:")
        print(f"   Expected Return: {mc_result.data['expected_return']*100:.2f}%")
        print(f"   VaR (95%): {mc_result.data['var_95']*100:.2f}%")
        print(f"   CVaR (95%): {mc_result.data['cvar_95']*100:.2f}%")
    else:
        print(f"❌ Error: {mc_result.errors}")
else:
    print("⚠️ Sample returns not available. Run Cell 27 first.")

print("\n" + "=" * 70)
print("✅ Monte Carlo Agent ready!")