"""
signals.py
==========
SignalGenerationAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, Union, Tuple, List
from scipy.optimize import minimize_scalar
import warnings
warnings.filterwarnings('ignore')

try:
    import optuna
    OPTUNA_AVAILABLE = True
except ImportError:
    OPTUNA_AVAILABLE = False


class SignalGenerationAgent(BaseAgent):
    """
    Agent responsible for generating trading signals from ML predictions.

    Features:
    - Adaptive threshold optimization
    - Regime-aware signal filtering
    - Signal smoothing and confirmation
    - Position sizing recommendations

    Attributes:
        buy_threshold: Optimized buy threshold
        sell_threshold: Optimized sell threshold
        signals: Generated signals
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        buy_threshold: float = 0.6,
        sell_threshold: float = 0.4,
        signal_smoothing: int = 1,
        min_holding_period: int = 1
    ):
        """
        Initialize Signal Generation Agent.

        Args:
            config: System configuration
            logger: Logger instance
            buy_threshold: Initial buy threshold
            sell_threshold: Initial sell threshold
            signal_smoothing: Rolling window for signal smoothing
            min_holding_period: Minimum holding period in days
        """
        super().__init__("SignalGenerationAgent", config, logger)

        self.buy_threshold = buy_threshold
        self.sell_threshold = sell_threshold
        self.signal_smoothing = signal_smoothing
        self.min_holding_period = min_holding_period

        self.signals: Optional[pd.Series] = None
        self.signal_strength: Optional[pd.Series] = None
        self.optimized_thresholds: Dict[str, float] = {}

    def generate_signals(
        self,
        probabilities: pd.Series,
        regime: Optional[pd.Series] = None
    ) -> pd.Series:
        """
        Generate trading signals from probabilities.

        Args:
            probabilities: ML model probabilities
            regime: Market regime labels (optional)

        Returns:
            Signal series (1=BUY, 0=HOLD, -1=SELL)
        """
        self.logger.info("Generating trading signals...")

        # Initialize signals
        signals = pd.Series(0, index=probabilities.index)

        # Apply thresholds
        signals[probabilities > self.buy_threshold] = 1
        signals[probabilities < self.sell_threshold] = -1

        # Apply signal smoothing if specified
        if self.signal_smoothing > 1:
            signals = signals.rolling(
                window=self.signal_smoothing,
                min_periods=1
            ).mean().round().astype(int)

        # Apply regime filter if provided
        if regime is not None:
            signals = self._apply_regime_filter(signals, regime)

        # Apply minimum holding period
        signals = self._apply_holding_period(signals)

        self.signals = signals
        self.signal_strength = probabilities

        # Log statistics
        buy_count = (signals == 1).sum()
        sell_count = (signals == -1).sum()
        hold_count = (signals == 0).sum()

        self.logger.info(f"  BUY signals: {buy_count} ({buy_count/len(signals)*100:.1f}%)")
        self.logger.info(f"  SELL signals: {sell_count} ({sell_count/len(signals)*100:.1f}%)")
        self.logger.info(f"  HOLD signals: {hold_count} ({hold_count/len(signals)*100:.1f}%)")

        return signals

    def _apply_regime_filter(
        self,
        signals: pd.Series,
        regime: pd.Series
    ) -> pd.Series:
        """
        Apply regime-based signal filtering.

        Args:
            signals: Original signals
            regime: Market regime labels

        Returns:
            Filtered signals
        """
        filtered_signals = signals.copy()

        # Align regime with signals
        aligned_regime = regime.reindex(signals.index, method='ffill')

        # Reduce position in high volatility regime
        high_vol_mask = aligned_regime.isin(['high_volatility', 3])
        filtered_signals[high_vol_mask] = filtered_signals[high_vol_mask] * 0.5
        filtered_signals = filtered_signals.round().astype(int)

        # No shorts in strong bull regime (optional)
        bull_mask = aligned_regime.isin(['bull', 0])
        # filtered_signals[(bull_mask) & (filtered_signals == -1)] = 0

        return filtered_signals

    def _apply_holding_period(
        self,
        signals: pd.Series
    ) -> pd.Series:
        """
        Apply minimum holding period constraint.

        Args:
            signals: Original signals

        Returns:
            Signals with holding period applied
        """
        if self.min_holding_period <= 1:
            return signals

        filtered_signals = signals.copy()
        last_signal = 0
        last_signal_idx = 0

        for i, (idx, signal) in enumerate(signals.items()):
            if signal != last_signal:
                if i - last_signal_idx >= self.min_holding_period:
                    last_signal = signal
                    last_signal_idx = i
                else:
                    filtered_signals[idx] = last_signal

        return filtered_signals

    def optimize_thresholds(
        self,
        probabilities: pd.Series,
        returns: pd.Series,
        method: str = 'grid',
        metric: str = 'sharpe'
    ) -> Dict[str, float]:
        """
        Optimize signal thresholds on validation data.

        Args:
            probabilities: ML probabilities
            returns: Actual returns
            method: Optimization method ('grid', 'optuna')
            metric: Metric to optimize ('sharpe', 'returns', 'sortino')

        Returns:
            Optimized thresholds
        """
        self.logger.info(f"Optimizing thresholds using {method} method...")

        # Align data
        aligned_probs, aligned_returns = probabilities.align(returns, join='inner')

        def calculate_metric(buy_thresh: float, sell_thresh: float) -> float:
            """Calculate performance metric for given thresholds."""
            signals = pd.Series(0, index=aligned_probs.index)
            signals[aligned_probs > buy_thresh] = 1
            signals[aligned_probs < sell_thresh] = -1

            # Calculate strategy returns (signal at t, return at t+1)
            strategy_returns = signals.shift(1) * aligned_returns
            strategy_returns = strategy_returns.dropna()

            if len(strategy_returns) == 0 or strategy_returns.std() == 0:
                return -np.inf

            if metric == 'sharpe':
                return calculate_sharpe_ratio(strategy_returns)
            elif metric == 'returns':
                return strategy_returns.sum()
            elif metric == 'sortino':
                return calculate_sortino_ratio(strategy_returns)
            else:
                return calculate_sharpe_ratio(strategy_returns)

        if method == 'grid':
            best_score = -np.inf
            best_buy = self.buy_threshold
            best_sell = self.sell_threshold

            buy_range = np.arange(0.55, 0.85, 0.05)
            sell_range = np.arange(0.15, 0.45, 0.05)

            for buy_thresh in buy_range:
                for sell_thresh in sell_range:
                    if buy_thresh <= sell_thresh:
                        continue

                    score = calculate_metric(buy_thresh, sell_thresh)

                    if score > best_score:
                        best_score = score
                        best_buy = buy_thresh
                        best_sell = sell_thresh

            self.buy_threshold = best_buy
            self.sell_threshold = best_sell

        elif method == 'optuna' and OPTUNA_AVAILABLE:
            def objective(trial):
                buy_thresh = trial.suggest_float('buy_threshold', 0.55, 0.85)
                sell_thresh = trial.suggest_float('sell_threshold', 0.15, 0.45)

                if buy_thresh <= sell_thresh:
                    return -np.inf

                return calculate_metric(buy_thresh, sell_thresh)

            study = optuna.create_study(direction='maximize')
            study.optimize(objective, n_trials=50, show_progress_bar=False)

            self.buy_threshold = study.best_params['buy_threshold']
            self.sell_threshold = study.best_params['sell_threshold']
            best_score = study.best_value

        self.optimized_thresholds = {
            'buy_threshold': self.buy_threshold,
            'sell_threshold': self.sell_threshold,
            'optimization_metric': metric,
            'best_score': best_score if 'best_score' in dir() else 0
        }

        self.logger.info(f"  Optimized buy threshold: {self.buy_threshold:.3f}")
        self.logger.info(f"  Optimized sell threshold: {self.sell_threshold:.3f}")

        return self.optimized_thresholds

    def calculate_position_sizes(
        self,
        signals: pd.Series,
        probabilities: pd.Series,
        method: str = 'confidence'
    ) -> pd.Series:
        """
        Calculate position sizes based on signal strength.

        Args:
            signals: Trading signals
            probabilities: ML probabilities
            method: Sizing method ('confidence', 'kelly', 'fixed')

        Returns:
            Position size series (0 to 1)
        """
        if method == 'confidence':
            # Position size proportional to probability distance from 0.5
            position_sizes = np.abs(probabilities - 0.5) * 2
            position_sizes = position_sizes.clip(0, 1)
            position_sizes = position_sizes * signals.abs()

        elif method == 'kelly':
            # Simplified Kelly criterion
            # f = (p * b - q) / b where p = win prob, q = 1-p, b = win/loss ratio
            win_prob = probabilities.clip(0.01, 0.99)
            kelly_fraction = 2 * win_prob - 1  # Simplified
            kelly_fraction = kelly_fraction.clip(0, 0.5)  # Max 50% position
            position_sizes = kelly_fraction * signals.abs()

        elif method == 'fixed':
            # Fixed position size
            position_sizes = signals.abs() * 1.0

        else:
            position_sizes = signals.abs() * 1.0

        return position_sizes

    def get_signal_statistics(self) -> Dict[str, Any]:
        """Get signal statistics."""
        if self.signals is None:
            return {}

        signals = self.signals

        stats = {
            'total_signals': len(signals),
            'buy_signals': (signals == 1).sum(),
            'sell_signals': (signals == -1).sum(),
            'hold_signals': (signals == 0).sum(),
            'buy_pct': (signals == 1).mean() * 100,
            'sell_pct': (signals == -1).mean() * 100,
            'signal_changes': (signals.diff() != 0).sum(),
            'avg_signal_duration': len(signals) / max(1, (signals.diff() != 0).sum()),
            'thresholds': self.optimized_thresholds
        }

        return stats

    def run(
        self,
        probabilities: pd.Series,
        returns: Optional[pd.Series] = None,
        regime: Optional[pd.Series] = None,
        optimize: bool = True,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            probabilities: ML model probabilities
            returns: Actual returns for threshold optimization
            regime: Market regime labels
            optimize: Whether to optimize thresholds

        Returns:
            AgentResult with signals
        """
        def execute():
            # Optimize thresholds if returns provided
            if optimize and returns is not None:
                self.optimize_thresholds(probabilities, returns)

            # Generate signals
            signals = self.generate_signals(probabilities, regime)

            # Calculate position sizes
            position_sizes = self.calculate_position_sizes(
                signals, probabilities, method='confidence'
            )

            # Get statistics
            stats = self.get_signal_statistics()

            return {
                'signals': signals,
                'position_sizes': position_sizes,
                'probabilities': probabilities,
                'thresholds': {
                    'buy': self.buy_threshold,
                    'sell': self.sell_threshold
                },
                'statistics': stats
            }

        return self._execute_with_timing(execute)


# Test Signal Generation
print("=" * 70)
print("🧪 TESTING SIGNAL GENERATION")
print("=" * 70)

# Generate sample probabilities and returns
np.random.seed(42)
n = 200
dates = pd.date_range(start='2023-01-01', periods=n, freq='D')

sample_probs = pd.Series(
    np.random.beta(2, 2, n),  # Beta distribution centered at 0.5
    index=dates
)
sample_returns = pd.Series(
    np.random.randn(n) * 0.02,  # 2% daily vol
    index=dates
)

# Create signal agent
signal_agent = SignalGenerationAgent(
    config=config,
    buy_threshold=0.6,
    sell_threshold=0.4
)

# Test signal generation
print("\n📊 Generating signals...")
signal_result = signal_agent.run(
    sample_probs,
    returns=sample_returns,
    optimize=True
)

if signal_result.success:
    print(f"\n✅ Signal generation completed!")
    print(f"   Buy threshold: {signal_result.data['thresholds']['buy']:.3f}")
    print(f"   Sell threshold: {signal_result.data['thresholds']['sell']:.3f}")

    stats = signal_result.data['statistics']
    print(f"\n   Signal Statistics:")
    print(f"      Total signals: {stats['total_signals']}")
    print(f"      BUY: {stats['buy_signals']} ({stats['buy_pct']:.1f}%)")
    print(f"      SELL: {stats['sell_signals']} ({stats['sell_pct']:.1f}%)")
    print(f"      HOLD: {stats['hold_signals']}")
    print(f"      Avg duration: {stats['avg_signal_duration']:.1f} days")
else:
    print(f"❌ Error: {signal_result.errors}")

print("\n" + "=" * 70)
print("✅ Signal Generation Agent ready!")