"""
risk.py
=======
RiskManagementAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Tuple, Union
from scipy import stats
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class RiskMetrics:
    """Data class for risk metrics."""
    var_95: float
    var_99: float
    cvar_95: float
    cvar_99: float
    max_drawdown: float
    max_drawdown_duration: int
    volatility_daily: float
    volatility_annual: float
    downside_deviation: float
    beta: Optional[float]
    correlation: Optional[float]
    skewness: float
    kurtosis: float
    tail_ratio: float


class RiskManagementAgent(AnalysisAgent):
    """
    Agent for comprehensive risk analysis and management.

    Features:
    - Value at Risk (VaR) calculations
    - Expected Shortfall (CVaR)
    - Rolling risk metrics
    - Drawdown analysis
    - Tail risk metrics

    Attributes:
        risk_metrics: Calculated risk metrics
        rolling_metrics: Time series of rolling risk
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        """Initialize Risk Management Agent."""
        super().__init__("RiskManagementAgent", config, logger)

        self.risk_metrics: Optional[RiskMetrics] = None
        self.rolling_metrics: Optional[pd.DataFrame] = None
        self.var_confidence_levels = self.config.risk.var_confidence_levels

    def calculate_var(
        self,
        returns: pd.Series,
        confidence: float = 0.95,
        method: str = 'historical'
    ) -> float:
        """
        Calculate Value at Risk.

        Args:
            returns: Returns series
            confidence: Confidence level
            method: 'historical', 'parametric', or 'cornish_fisher'

        Returns:
            VaR value (negative number representing potential loss)
        """
        returns = returns.dropna()

        if method == 'historical':
            var = np.percentile(returns, (1 - confidence) * 100)

        elif method == 'parametric':
            # Assume normal distribution
            mean = returns.mean()
            std = returns.std()
            var = stats.norm.ppf(1 - confidence, mean, std)

        elif method == 'cornish_fisher':
            # Adjust for skewness and kurtosis
            mean = returns.mean()
            std = returns.std()
            skew = returns.skew()
            kurt = returns.kurtosis()

            z = stats.norm.ppf(1 - confidence)
            z_adj = (z + (z**2 - 1) * skew / 6 +
                    (z**3 - 3*z) * (kurt - 3) / 24 -
                    (2*z**3 - 5*z) * (skew**2) / 36)

            var = mean + z_adj * std

        else:
            var = np.percentile(returns, (1 - confidence) * 100)

        return var

    def calculate_cvar(
        self,
        returns: pd.Series,
        confidence: float = 0.95
    ) -> float:
        """
        Calculate Conditional VaR (Expected Shortfall).

        Args:
            returns: Returns series
            confidence: Confidence level

        Returns:
            CVaR value
        """
        returns = returns.dropna()
        var = self.calculate_var(returns, confidence)
        cvar = returns[returns <= var].mean()

        return cvar if not np.isnan(cvar) else var

    def calculate_drawdowns(
        self,
        equity_curve: pd.Series
    ) -> Tuple[pd.Series, float, int, pd.Timestamp, pd.Timestamp]:
        """
        Calculate drawdown series and statistics.

        Args:
            equity_curve: Portfolio value series

        Returns:
            Tuple of (drawdown_series, max_dd, max_dd_duration, peak_date, trough_date)
        """
        # Calculate running maximum
        running_max = equity_curve.expanding().max()

        # Calculate drawdown
        drawdown = (equity_curve - running_max) / running_max

        # Maximum drawdown
        max_dd = drawdown.min()
        trough_idx = drawdown.idxmin()
        peak_idx = equity_curve[:trough_idx].idxmax()

        # Maximum drawdown duration
        is_drawdown = drawdown < 0
        drawdown_periods = (~is_drawdown).cumsum()
        dd_grouped = is_drawdown.groupby(drawdown_periods)
        max_duration = dd_grouped.sum().max()

        return drawdown, abs(max_dd), max_duration, peak_idx, trough_idx

    def calculate_all_metrics(
        self,
        returns: pd.Series,
        benchmark_returns: Optional[pd.Series] = None
    ) -> RiskMetrics:
        """
        Calculate comprehensive risk metrics.

        Args:
            returns: Strategy returns
            benchmark_returns: Benchmark returns (optional)

        Returns:
            RiskMetrics object
        """
        returns = returns.dropna()

        # VaR and CVaR
        var_95 = self.calculate_var(returns, 0.95)
        var_99 = self.calculate_var(returns, 0.99)
        cvar_95 = self.calculate_cvar(returns, 0.95)
        cvar_99 = self.calculate_cvar(returns, 0.99)

        # Drawdowns
        equity = (1 + returns).cumprod()
        _, max_dd, max_dd_duration, _, _ = self.calculate_drawdowns(equity)

        # Volatility
        vol_daily = returns.std()
        vol_annual = vol_daily * np.sqrt(252)

        # Downside deviation
        negative_returns = returns[returns < 0]
        downside_dev = negative_returns.std() * np.sqrt(252) if len(negative_returns) > 0 else 0

        # Beta and correlation (if benchmark provided)
        beta = None
        correlation = None
        if benchmark_returns is not None:
            aligned_bench = benchmark_returns.reindex(returns.index).dropna()
            aligned_returns = returns.reindex(aligned_bench.index).dropna()

            if len(aligned_returns) > 10:
                covariance = np.cov(aligned_returns, aligned_bench)[0, 1]
                variance = aligned_bench.var()
                beta = covariance / variance if variance > 0 else 0
                correlation = np.corrcoef(aligned_returns, aligned_bench)[0, 1]

        # Higher moments
        skewness = returns.skew()
        kurtosis = returns.kurtosis()

        # Tail ratio (ratio of 95th percentile to 5th percentile)
        tail_ratio = abs(np.percentile(returns, 95) / np.percentile(returns, 5)) if np.percentile(returns, 5) != 0 else 0

        return RiskMetrics(
            var_95=var_95,
            var_99=var_99,
            cvar_95=cvar_95,
            cvar_99=cvar_99,
            max_drawdown=max_dd,
            max_drawdown_duration=max_dd_duration,
            volatility_daily=vol_daily,
            volatility_annual=vol_annual,
            downside_deviation=downside_dev,
            beta=beta,
            correlation=correlation,
            skewness=skewness,
            kurtosis=kurtosis,
            tail_ratio=tail_ratio
        )

    def calculate_rolling_metrics(
        self,
        returns: pd.Series,
        window: int = 63  # ~3 months
    ) -> pd.DataFrame:
        """
        Calculate rolling risk metrics.

        Args:
            returns: Returns series
            window: Rolling window size

        Returns:
            DataFrame with rolling metrics
        """
        rolling = pd.DataFrame(index=returns.index)

        # Rolling volatility
        rolling['volatility'] = returns.rolling(window).std() * np.sqrt(252)

        # Rolling Sharpe
        rf = self.config.risk.risk_free_rate / 252
        rolling['sharpe'] = (
            (returns.rolling(window).mean() - rf) /
            returns.rolling(window).std()
        ) * np.sqrt(252)

        # Rolling VaR
        rolling['var_95'] = returns.rolling(window).quantile(0.05)

        # Rolling max drawdown
        def rolling_max_dd(x):
            equity = (1 + x).cumprod()
            running_max = equity.expanding().max()
            dd = (equity - running_max) / running_max
            return dd.min()

        rolling['max_drawdown'] = returns.rolling(window).apply(rolling_max_dd, raw=False)

        # Rolling skewness
        rolling['skewness'] = returns.rolling(window).skew()

        return rolling

    def stress_test(
        self,
        returns: pd.Series,
        scenarios: Optional[Dict[str, Tuple[str, str]]] = None
    ) -> pd.DataFrame:
        """
        Perform stress testing on historical crisis periods.

        Args:
            returns: Strategy returns
            scenarios: Dictionary of scenario names to date ranges

        Returns:
            DataFrame with stress test results
        """
        scenarios = scenarios or self.config.risk.stress_periods

        results = []

        for scenario_name, (start_date, end_date) in scenarios.items():
            try:
                scenario_returns = returns.loc[start_date:end_date]

                if len(scenario_returns) == 0:
                    continue

                # Calculate metrics for this period
                equity = (1 + scenario_returns).cumprod()
                _, max_dd, _, _, _ = self.calculate_drawdowns(equity)

                results.append({
                    'scenario': scenario_name,
                    'start_date': start_date,
                    'end_date': end_date,
                    'total_return': (equity.iloc[-1] / equity.iloc[0]) - 1 if len(equity) > 1 else 0,
                    'volatility': scenario_returns.std() * np.sqrt(252),
                    'max_drawdown': max_dd,
                    'var_95': self.calculate_var(scenario_returns, 0.95),
                    'days': len(scenario_returns)
                })
            except Exception as e:
                self.logger.warning(f"Stress test failed for {scenario_name}: {e}")

        return pd.DataFrame(results)

    def analyze(
        self,
        data: pd.DataFrame,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Perform comprehensive risk analysis.

        Args:
            data: DataFrame with returns column

        Returns:
            Analysis results dictionary
        """
        if 'returns' in data.columns:
            returns = data['returns']
        elif 'Returns' in data.columns:
            returns = data['Returns']
        else:
            returns = data.iloc[:, 0]

        # Calculate all metrics
        self.risk_metrics = self.calculate_all_metrics(returns)

        # Rolling metrics
        self.rolling_metrics = self.calculate_rolling_metrics(returns)

        # Store results
        self.analysis_results = {
            'var_95': self.risk_metrics.var_95,
            'cvar_95': self.risk_metrics.cvar_95,
            'max_drawdown': self.risk_metrics.max_drawdown,
            'volatility': self.risk_metrics.volatility_annual,
            'skewness': self.risk_metrics.skewness,
            'kurtosis': self.risk_metrics.kurtosis
        }

        return self.analysis_results

    def run(
        self,
        returns: Union[pd.Series, pd.DataFrame],
        benchmark_returns: Optional[pd.Series] = None,
        run_stress_test: bool = True,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            returns: Strategy returns
            benchmark_returns: Benchmark returns (optional)
            run_stress_test: Whether to run stress tests

        Returns:
            AgentResult with risk analysis
        """
        def execute():
            # Handle DataFrame input
            if isinstance(returns, pd.DataFrame):
                ret_series = returns.iloc[:, 0] if returns.shape[1] == 1 else returns['returns']
            else:
                ret_series = returns

            # Calculate all metrics
            risk_metrics = self.calculate_all_metrics(ret_series, benchmark_returns)

            # Rolling metrics
            rolling_metrics = self.calculate_rolling_metrics(ret_series)

            # Stress test
            stress_results = None
            if run_stress_test:
                stress_results = self.stress_test(ret_series)

            # Drawdown analysis
            equity = (1 + ret_series).cumprod()
            dd_series, max_dd, max_dd_dur, peak, trough = self.calculate_drawdowns(equity)

            return {
                'risk_metrics': risk_metrics,
                'rolling_metrics': rolling_metrics,
                'stress_test_results': stress_results,
                'drawdown_series': dd_series,
                'var_95': risk_metrics.var_95,
                'var_99': risk_metrics.var_99,
                'cvar_95': risk_metrics.cvar_95,
                'max_drawdown': risk_metrics.max_drawdown,
                'volatility': risk_metrics.volatility_annual,
                'beta': risk_metrics.beta,
                'skewness': risk_metrics.skewness,
                'kurtosis': risk_metrics.kurtosis
            }

        return self._execute_with_timing(execute)


# Test Risk Management Agent
print("=" * 70)
print("🧪 TESTING RISK MANAGEMENT AGENT")
print("=" * 70)

# Generate sample returns
np.random.seed(42)
n = 500
dates = pd.date_range(start='2021-01-01', periods=n, freq='D')
sample_returns = pd.Series(
    np.random.randn(n) * 0.02 - 0.0001,  # Slightly negative drift
    index=dates
)

# Create benchmark returns
benchmark_returns = pd.Series(
    np.random.randn(n) * 0.015,  # Lower vol benchmark
    index=dates
)

# Test Risk Agent
risk_agent = RiskManagementAgent(config=config)
risk_result = risk_agent.run(sample_returns, benchmark_returns, run_stress_test=True)

if risk_result.success:
    print(f"\n✅ Risk analysis completed!")
    print(f"\n📊 Risk Metrics:")
    print(f"   VaR (95%): {risk_result.data['var_95']*100:.2f}%")
    print(f"   VaR (99%): {risk_result.data['var_99']*100:.2f}%")
    print(f"   CVaR (95%): {risk_result.data['cvar_95']*100:.2f}%")
    print(f"   Max Drawdown: {risk_result.data['max_drawdown']*100:.2f}%")
    print(f"   Annual Volatility: {risk_result.data['volatility']*100:.2f}%")
    print(f"   Beta: {risk_result.data['beta']:.3f}" if risk_result.data['beta'] else "   Beta: N/A")
    print(f"   Skewness: {risk_result.data['skewness']:.3f}")
    print(f"   Kurtosis: {risk_result.data['kurtosis']:.3f}")

    if risk_result.data['stress_test_results'] is not None and len(risk_result.data['stress_test_results']) > 0:
        print(f"\n   Stress Test Results:")
        for _, row in risk_result.data['stress_test_results'].iterrows():
            print(f"      {row['scenario']}: Return={row['total_return']*100:.1f}%, MaxDD={row['max_drawdown']*100:.1f}%")
else:
    print(f"❌ Error: {risk_result.errors}")

print("\n" + "=" * 70)
print("✅ Risk Management Agent ready!")