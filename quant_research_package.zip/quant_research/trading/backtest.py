"""
backtest.py
===========
BacktraderEngine + BacktestingAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Tuple
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

try:
    import backtrader as bt
    BACKTRADER_AVAILABLE = True
    print("✅ Backtrader available")
except ImportError:
    BACKTRADER_AVAILABLE = False
    print("⚠️ Backtrader not available")


class MLSignalData(bt.feeds.PandasData):
    """
    Custom Backtrader data feed that includes ML signals.

    Extends standard OHLCV data with additional signal column.
    """

    # Add signal line
    lines = ('signal', 'probability',)

    # Define parameters for new columns
    params = (
        ('signal', -1),
        ('probability', -1),
    )


class MLSignalStrategy(bt.Strategy):
    """
    Backtrader strategy that executes based on ML signals.

    Features:
    - Executes at next bar open (realistic execution)
    - Position sizing based on signal strength
    - Stop-loss and take-profit
    - Maximum position limits
    """

    params = (
        ('max_position_pct', 0.20),  # Max 20% per position
        ('stop_loss_pct', 0.05),     # 5% stop loss
        ('take_profit_pct', 0.10),   # 10% take profit
        ('use_stop_loss', True),
        ('use_take_profit', True),
        ('commission_pct', 0.001),   # 0.1% commission
        ('printlog', False),
    )

    def __init__(self):
        """Initialize strategy."""
        self.signal = self.data.signal
        self.probability = self.data.probability if hasattr(self.data, 'probability') else None

        self.order = None
        self.entry_price = None
        self.trades = []
        self.daily_values = []

    def log(self, txt: str, dt: datetime = None):
        """Log messages."""
        if self.params.printlog:
            dt = dt or self.datas[0].datetime.date(0)
            print(f'{dt.isoformat()}, {txt}')

    def notify_order(self, order: bt.Order):
        """Handle order notifications."""
        if order.status in [order.Submitted, order.Accepted]:
            return

        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(f'BUY EXECUTED, Price: {order.executed.price:.2f}, Size: {order.executed.size:.0f}')
                self.entry_price = order.executed.price
            else:
                self.log(f'SELL EXECUTED, Price: {order.executed.price:.2f}, Size: {order.executed.size:.0f}')
                if self.entry_price:
                    pnl = (order.executed.price - self.entry_price) * order.executed.size
                    self.trades.append({
                        'entry_price': self.entry_price,
                        'exit_price': order.executed.price,
                        'pnl': pnl,
                        'date': self.datas[0].datetime.date(0)
                    })
                self.entry_price = None

        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log('Order Canceled/Margin/Rejected')

        self.order = None

    def notify_trade(self, trade: bt.Trade):
        """Handle trade notifications."""
        if not trade.isclosed:
            return

        self.log(f'OPERATION PROFIT, GROSS {trade.pnl:.2f}, NET {trade.pnlcomm:.2f}')

    def next(self):
        """Execute strategy logic on each bar."""
        # Record daily portfolio value
        self.daily_values.append({
            'date': self.datas[0].datetime.date(0),
            'value': self.broker.getvalue()
        })

        # Skip if order pending
        if self.order:
            return

        # Get current signal
        current_signal = self.signal[0]

        # Check stop-loss and take-profit for existing positions
        if self.position:
            if self.params.use_stop_loss or self.params.use_take_profit:
                current_price = self.data.close[0]

                if self.entry_price:
                    pct_change = (current_price - self.entry_price) / self.entry_price

                    # Stop-loss
                    if self.params.use_stop_loss and pct_change < -self.params.stop_loss_pct:
                        self.log(f'STOP-LOSS triggered at {pct_change*100:.1f}%')
                        self.order = self.close()
                        return

                    # Take-profit
                    if self.params.use_take_profit and pct_change > self.params.take_profit_pct:
                        self.log(f'TAKE-PROFIT triggered at {pct_change*100:.1f}%')
                        self.order = self.close()
                        return

        # Execute based on signal
        if not self.position:
            # No position - check for entry
            if current_signal == 1:  # BUY signal
                # Calculate position size
                size = self._calculate_position_size()
                if size > 0:
                    self.log(f'BUY CREATE, Price: {self.data.close[0]:.2f}, Size: {size}')
                    self.order = self.buy(size=size)

            elif current_signal == -1:  # SELL signal (short)
                # For now, we only go long
                pass

        else:
            # Have position - check for exit
            if current_signal == -1:  # SELL signal
                self.log(f'SELL CREATE (Close Position), Price: {self.data.close[0]:.2f}')
                self.order = self.close()

            elif current_signal == 0:  # HOLD - could also exit
                pass

    def _calculate_position_size(self) -> int:
        """Calculate position size based on available cash and limits."""
        available_cash = self.broker.getcash()
        current_price = self.data.close[0]

        # Maximum position value
        max_position_value = self.broker.getvalue() * self.params.max_position_pct

        # Calculate size
        position_value = min(available_cash * 0.95, max_position_value)  # 95% of cash
        size = int(position_value / current_price)

        return max(0, size)

    def stop(self):
        """Called at the end of backtest."""
        self.log(f'Final Portfolio Value: {self.broker.getvalue():.2f}')


class MarketImpactCommission(bt.CommInfoBase):
    """
    Custom commission scheme with market impact.

    Implements: impact = k * sqrt(order_size / ADV)
    """

    params = (
        ('commission', 0.001),  # 0.1% base commission
        ('stocklike', True),
        ('commtype', bt.CommInfoBase.COMM_PERC),
        ('impact_k', 0.1),     # Market impact coefficient
        ('adv', 1000000),      # Average daily volume (default)
    )

    def _getcommission(self, size, price, pseudoexec):
        """Calculate commission including market impact."""
        # Base commission
        base_comm = abs(size) * price * self.params.commission

        # Market impact
        if self.params.adv > 0:
            impact = self.params.impact_k * np.sqrt(abs(size) / self.params.adv)
            impact_cost = abs(size) * price * impact
        else:
            impact_cost = 0

        return base_comm + impact_cost


class BacktraderEngine:
    """
    Wrapper class for Backtrader engine.

    Provides easy-to-use interface for running backtests.
    """

    def __init__(
        self,
        initial_capital: float = 100000,
        commission: float = 0.001,
        slippage: float = 0.0005
    ):
        """
        Initialize Backtrader engine.

        Args:
            initial_capital: Starting capital
            commission: Commission percentage
            slippage: Slippage percentage
        """
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage

        self.cerebro = None
        self.results = None
        self.analyzers = {}

    def prepare_data(
        self,
        prices: pd.DataFrame,
        signals: pd.Series,
        probabilities: Optional[pd.Series] = None
    ) -> pd.DataFrame:
        """
        Prepare data for Backtrader.

        Args:
            prices: OHLCV DataFrame
            signals: Signal series
            probabilities: Probability series (optional)

        Returns:
            Combined DataFrame
        """
        # Ensure datetime index
        if not isinstance(prices.index, pd.DatetimeIndex):
            prices.index = pd.to_datetime(prices.index)

        # Align signals with prices
        data = prices.copy()
        data['signal'] = signals.reindex(prices.index, method='ffill').fillna(0)

        if probabilities is not None:
            data['probability'] = probabilities.reindex(prices.index, method='ffill').fillna(0.5)
        else:
            data['probability'] = 0.5

        # Ensure required columns
        required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
        for col in required_cols:
            if col not in data.columns:
                if col.lower() in data.columns:
                    data[col] = data[col.lower()]
                else:
                    raise ValueError(f"Missing required column: {col}")

        return data

    def run(
        self,
        data: pd.DataFrame,
        strategy_params: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Run backtest.

        Args:
            data: Prepared data with signals
            strategy_params: Strategy parameters

        Returns:
            Backtest results
        """
        strategy_params = strategy_params or {}

        # Create Cerebro engine
        self.cerebro = bt.Cerebro()

        # Add data
        bt_data = MLSignalData(
            dataname=data,
            datetime=None,
            open='Open',
            high='High',
            low='Low',
            close='Close',
            volume='Volume',
            signal='signal',
            probability='probability'
        )
        self.cerebro.adddata(bt_data)

        # Add strategy
        self.cerebro.addstrategy(MLSignalStrategy, **strategy_params)

        # Set initial capital
        self.cerebro.broker.setcash(self.initial_capital)

        # Set commission
        self.cerebro.broker.setcommission(commission=self.commission)

        # Add slippage
        self.cerebro.broker.set_slippage_perc(self.slippage)

        # Add analyzers
        self.cerebro.addanalyzer(bt.analyzers.SharpeRatio, _name='sharpe')
        self.cerebro.addanalyzer(bt.analyzers.DrawDown, _name='drawdown')
        self.cerebro.addanalyzer(bt.analyzers.Returns, _name='returns')
        self.cerebro.addanalyzer(bt.analyzers.TradeAnalyzer, _name='trades')
        self.cerebro.addanalyzer(bt.analyzers.SQN, _name='sqn')

        # Run backtest
        initial_value = self.cerebro.broker.getvalue()
        self.results = self.cerebro.run()
        final_value = self.cerebro.broker.getvalue()

        # Extract results
        strat = self.results[0]

        # Get analyzer results
        sharpe = strat.analyzers.sharpe.get_analysis()
        drawdown = strat.analyzers.drawdown.get_analysis()
        returns = strat.analyzers.returns.get_analysis()
        trades = strat.analyzers.trades.get_analysis()
        sqn = strat.analyzers.sqn.get_analysis()

        # Get daily values
        daily_values = pd.DataFrame(strat.daily_values)
        if not daily_values.empty:
            daily_values.set_index('date', inplace=True)

        results = {
            'initial_value': initial_value,
            'final_value': final_value,
            'total_return': (final_value - initial_value) / initial_value,
            'sharpe_ratio': sharpe.get('sharperatio', 0),
            'max_drawdown': drawdown.get('max', {}).get('drawdown', 0) / 100,
            'max_drawdown_duration': drawdown.get('max', {}).get('len', 0),
            'total_trades': trades.get('total', {}).get('total', 0),
            'won_trades': trades.get('won', {}).get('total', 0),
            'lost_trades': trades.get('lost', {}).get('total', 0),
            'sqn': sqn.get('sqn', 0),
            'daily_values': daily_values,
            'trades': strat.trades
        }

        return results

    def plot(self, **kwargs):
        """Plot backtest results."""
        if self.cerebro:
            self.cerebro.plot(**kwargs)


# Test Backtrader Engine
print("=" * 70)
print("🧪 TESTING BACKTRADER INTEGRATION")
print("=" * 70)

if BACKTRADER_AVAILABLE:
    # Create sample data
    np.random.seed(42)
    n = 200
    dates = pd.date_range(start='2023-01-01', periods=n, freq='D')

    # Generate synthetic price data
    returns = np.random.randn(n) * 0.02
    prices = 100 * np.exp(np.cumsum(returns))

    sample_prices = pd.DataFrame({
        'Open': prices * (1 + np.random.randn(n) * 0.005),
        'High': prices * (1 + np.abs(np.random.randn(n)) * 0.01),
        'Low': prices * (1 - np.abs(np.random.randn(n)) * 0.01),
        'Close': prices,
        'Volume': np.random.randint(100000, 1000000, n)
    }, index=dates)

    # Generate sample signals
    sample_signals = pd.Series(
        np.random.choice([-1, 0, 1], n, p=[0.2, 0.6, 0.2]),
        index=dates
    )

    # Create engine and run backtest
    engine = BacktraderEngine(initial_capital=100000)
    data = engine.prepare_data(sample_prices, sample_signals)

    print("\n📈 Running backtest...")
    bt_results = engine.run(data)

    print(f"\n✅ Backtest completed!")
    print(f"   Initial Value: ${bt_results['initial_value']:,.2f}")
    print(f"   Final Value: ${bt_results['final_value']:,.2f}")
    print(f"   Total Return: {bt_results['total_return']*100:.2f}%")
    print(f"   Sharpe Ratio: {bt_results['sharpe_ratio']:.4f}" if bt_results['sharpe_ratio'] else "   Sharpe Ratio: N/A")
    print(f"   Max Drawdown: {bt_results['max_drawdown']*100:.2f}%")
    print(f"   Total Trades: {bt_results['total_trades']}")
    print(f"   Win/Loss: {bt_results['won_trades']}/{bt_results['lost_trades']}")
else:
    print("⚠️ Backtrader not available")

print("\n" + "=" * 70)
print("✅ Backtrader Integration ready!")


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Union
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class BacktestResult:
    """Data class for backtest results."""
    total_return: float
    cagr: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    max_drawdown: float
    max_drawdown_duration: int
    volatility: float
    win_rate: float
    profit_factor: float
    total_trades: int
    avg_trade_return: float
    equity_curve: pd.Series
    returns: pd.Series
    trades: List[Dict]


class BacktestingAgent(BaseAgent):
    """
    Comprehensive backtesting agent.

    Features:
    - Integration with Backtrader
    - Fallback simple backtester
    - Comprehensive performance metrics
    - Transaction cost modeling
    - Capacity analysis

    Attributes:
        results: Backtest results
        equity_curve: Portfolio equity over time
        trades: List of executed trades
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        use_backtrader: bool = True
    ):
        """
        Initialize Backtesting Agent.

        Args:
            config: System configuration
            logger: Logger instance
            use_backtrader: Whether to use Backtrader
        """
        super().__init__("BacktestingAgent", config, logger)

        self.use_backtrader = use_backtrader and BACKTRADER_AVAILABLE
        self.results: Optional[BacktestResult] = None
        self.equity_curve: Optional[pd.Series] = None
        self.trades: List[Dict] = []

        # Transaction costs from config
        self.commission = self.config.backtest.commission_pct
        self.slippage = self.config.backtest.slippage_pct
        self.initial_capital = self.config.backtest.initial_capital

    def run_simple_backtest(
        self,
        prices: pd.DataFrame,
        signals: pd.Series,
        position_sizes: Optional[pd.Series] = None
    ) -> BacktestResult:
        """
        Run simple vectorized backtest.

        Args:
            prices: OHLCV DataFrame
            signals: Signal series
            position_sizes: Position size series (optional)

        Returns:
            BacktestResult object
        """
        self.logger.info("Running simple vectorized backtest...")

        # Align data
        close_prices = prices['Close'] if 'Close' in prices else prices['close']

        # Align signals with prices
        aligned_signals = signals.reindex(close_prices.index, method='ffill').fillna(0)

        # Calculate returns
        price_returns = close_prices.pct_change()

        # Strategy returns: signal at t determines position, return realized at t+1
        strategy_positions = aligned_signals.shift(1).fillna(0)  # Enter next day

        if position_sizes is not None:
            aligned_sizes = position_sizes.reindex(close_prices.index, method='ffill').fillna(0)
            strategy_positions = strategy_positions * aligned_sizes.shift(1).fillna(0)

        # Calculate transaction costs
        position_changes = strategy_positions.diff().abs()
        transaction_costs = position_changes * (self.commission + self.slippage)

        # Net strategy returns
        gross_returns = strategy_positions * price_returns
        net_returns = gross_returns - transaction_costs
        net_returns = net_returns.fillna(0)

        # Calculate equity curve
        equity = self.initial_capital * (1 + net_returns).cumprod()

        # Calculate performance metrics
        metrics = self._calculate_metrics(net_returns, equity)

        # Identify trades
        trades = self._identify_trades(strategy_positions, close_prices, net_returns)

        result = BacktestResult(
            total_return=metrics['total_return'],
            cagr=metrics['cagr'],
            sharpe_ratio=metrics['sharpe_ratio'],
            sortino_ratio=metrics['sortino_ratio'],
            calmar_ratio=metrics['calmar_ratio'],
            max_drawdown=metrics['max_drawdown'],
            max_drawdown_duration=metrics['max_drawdown_duration'],
            volatility=metrics['volatility'],
            win_rate=metrics['win_rate'],
            profit_factor=metrics['profit_factor'],
            total_trades=len(trades),
            avg_trade_return=metrics['avg_trade_return'],
            equity_curve=equity,
            returns=net_returns,
            trades=trades
        )

        self.results = result
        self.equity_curve = equity
        self.trades = trades

        return result

    def run_backtrader_backtest(
        self,
        prices: pd.DataFrame,
        signals: pd.Series,
        probabilities: Optional[pd.Series] = None,
        strategy_params: Optional[Dict] = None
    ) -> BacktestResult:
        """
        Run backtest using Backtrader.

        Args:
            prices: OHLCV DataFrame
            signals: Signal series
            probabilities: ML probabilities (optional)
            strategy_params: Strategy parameters

        Returns:
            BacktestResult object
        """
        self.logger.info("Running Backtrader backtest...")

        # Create engine
        engine = BacktraderEngine(
            initial_capital=self.initial_capital,
            commission=self.commission,
            slippage=self.slippage
        )

        # Prepare data
        data = engine.prepare_data(prices, signals, probabilities)

        # Run backtest
        bt_results = engine.run(data, strategy_params or {})

        # Convert to BacktestResult
        daily_values = bt_results['daily_values']
        if not daily_values.empty:
            equity = daily_values['value']
            returns = equity.pct_change().fillna(0)
        else:
            equity = pd.Series([self.initial_capital])
            returns = pd.Series([0])

        # Calculate metrics
        metrics = self._calculate_metrics(returns, equity)

        result = BacktestResult(
            total_return=bt_results['total_return'],
            cagr=metrics['cagr'],
            sharpe_ratio=bt_results['sharpe_ratio'] or metrics['sharpe_ratio'],
            sortino_ratio=metrics['sortino_ratio'],
            calmar_ratio=metrics['calmar_ratio'],
            max_drawdown=bt_results['max_drawdown'],
            max_drawdown_duration=bt_results['max_drawdown_duration'],
            volatility=metrics['volatility'],
            win_rate=bt_results['won_trades'] / max(1, bt_results['total_trades']),
            profit_factor=metrics['profit_factor'],
            total_trades=bt_results['total_trades'],
            avg_trade_return=metrics['avg_trade_return'],
            equity_curve=equity,
            returns=returns,
            trades=bt_results['trades']
        )

        self.results = result
        self.equity_curve = equity
        self.trades = bt_results['trades']

        return result

    def _calculate_metrics(
        self,
        returns: pd.Series,
        equity: pd.Series
    ) -> Dict[str, float]:
        """Calculate comprehensive performance metrics."""
        returns = returns.dropna()

        if len(returns) == 0:
            return {k: 0.0 for k in [
                'total_return', 'cagr', 'sharpe_ratio', 'sortino_ratio',
                'calmar_ratio', 'max_drawdown', 'max_drawdown_duration',
                'volatility', 'win_rate', 'profit_factor', 'avg_trade_return'
            ]}

        # Total return
        total_return = (equity.iloc[-1] / equity.iloc[0]) - 1 if len(equity) > 1 else 0

        # CAGR
        years = len(returns) / 252
        cagr = (1 + total_return) ** (1 / max(years, 0.01)) - 1 if years > 0 else 0

        # Volatility
        volatility = returns.std() * np.sqrt(252)

        # Sharpe Ratio
        risk_free = self.config.risk.risk_free_rate / 252
        excess_returns = returns - risk_free
        sharpe = np.sqrt(252) * excess_returns.mean() / returns.std() if returns.std() > 0 else 0

        # Sortino Ratio
        downside_returns = returns[returns < 0]
        downside_std = downside_returns.std() if len(downside_returns) > 0 else 0.001
        sortino = np.sqrt(252) * excess_returns.mean() / downside_std if downside_std > 0 else 0

        # Max Drawdown
        cummax = equity.expanding().max()
        drawdown = (equity - cummax) / cummax
        max_dd = abs(drawdown.min())

        # Max Drawdown Duration
        drawdown_duration = 0
        current_duration = 0
        for dd in drawdown:
            if dd < 0:
                current_duration += 1
                drawdown_duration = max(drawdown_duration, current_duration)
            else:
                current_duration = 0

        # Calmar Ratio
        calmar = cagr / max_dd if max_dd > 0 else 0

        # Win Rate
        winning_days = (returns > 0).sum()
        total_days = len(returns)
        win_rate = winning_days / total_days if total_days > 0 else 0

        # Profit Factor
        gross_profits = returns[returns > 0].sum()
        gross_losses = abs(returns[returns < 0].sum())
        profit_factor = gross_profits / gross_losses if gross_losses > 0 else 999

        # Average Trade Return
        avg_return = returns.mean()

        return {
            'total_return': total_return,
            'cagr': cagr,
            'sharpe_ratio': sharpe,
            'sortino_ratio': sortino,
            'calmar_ratio': calmar,
            'max_drawdown': max_dd,
            'max_drawdown_duration': drawdown_duration,
            'volatility': volatility,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'avg_trade_return': avg_return
        }

    def _identify_trades(
        self,
        positions: pd.Series,
        prices: pd.Series,
        returns: pd.Series
    ) -> List[Dict]:
        """Identify individual trades from position series."""
        trades = []

        # Find position changes
        position_diff = positions.diff().fillna(0)
        entries = positions[position_diff > 0].index
        exits = positions[position_diff < 0].index

        # Match entries with exits
        for i, entry_date in enumerate(entries):
            # Find next exit
            later_exits = [e for e in exits if e > entry_date]
            if later_exits:
                exit_date = later_exits[0]

                entry_price = prices.loc[entry_date]
                exit_price = prices.loc[exit_date]
                trade_return = (exit_price - entry_price) / entry_price

                trades.append({
                    'entry_date': entry_date,
                    'exit_date': exit_date,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'return': trade_return,
                    'duration': (exit_date - entry_date).days if hasattr(exit_date - entry_date, 'days') else 0
                })

        return trades

    def run_capacity_analysis(
        self,
        prices: pd.DataFrame,
        signals: pd.Series,
        capital_levels: List[float] = None
    ) -> pd.DataFrame:
        """
        Analyze strategy capacity at different capital levels.

        Args:
            prices: OHLCV DataFrame
            signals: Signal series
            capital_levels: Capital levels to test

        Returns:
            DataFrame with capacity analysis
        """
        self.logger.info("Running capacity analysis...")

        capital_levels = capital_levels or [100000, 500000, 1000000, 5000000, 10000000]

        results = []

        for capital in capital_levels:
            # Temporarily set capital
            original_capital = self.initial_capital
            self.initial_capital = capital

            # Run backtest
            result = self.run_simple_backtest(prices, signals)

            # Estimate market impact
            avg_volume = prices['Volume'].mean() if 'Volume' in prices else 1000000
            avg_trade_size = capital * 0.2  # Assuming 20% position
            adv_pct = avg_trade_size / avg_volume

            # Estimated degradation
            impact = 0.1 * np.sqrt(adv_pct)  # Simplified impact model
            adjusted_sharpe = result.sharpe_ratio * (1 - impact)

            results.append({
                'capital': capital,
                'total_return': result.total_return,
                'sharpe_ratio': result.sharpe_ratio,
                'adjusted_sharpe': adjusted_sharpe,
                'adv_pct': adv_pct * 100,
                'estimated_impact': impact * 100,
                'max_drawdown': result.max_drawdown
            })

            # Restore original capital
            self.initial_capital = original_capital

        return pd.DataFrame(results)

    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary."""
        if self.results is None:
            return {}

        r = self.results

        return {
            'Performance': {
                'Total Return': f"{r.total_return*100:.2f}%",
                'CAGR': f"{r.cagr*100:.2f}%",
                'Volatility': f"{r.volatility*100:.2f}%",
            },
            'Risk-Adjusted': {
                'Sharpe Ratio': f"{r.sharpe_ratio:.3f}",
                'Sortino Ratio': f"{r.sortino_ratio:.3f}",
                'Calmar Ratio': f"{r.calmar_ratio:.3f}",
            },
            'Risk': {
                'Max Drawdown': f"{r.max_drawdown*100:.2f}%",
                'Max DD Duration': f"{r.max_drawdown_duration} days",
            },
            'Trading': {
                'Total Trades': r.total_trades,
                'Win Rate': f"{r.win_rate*100:.1f}%",
                'Profit Factor': f"{r.profit_factor:.2f}",
            }
        }

    def run(
        self,
        prices: pd.DataFrame,
        signals: pd.Series,
        probabilities: Optional[pd.Series] = None,
        benchmark_prices: Optional[pd.Series] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            prices: OHLCV DataFrame
            signals: Signal series
            probabilities: ML probabilities
            benchmark_prices: Benchmark prices for comparison

        Returns:
            AgentResult with backtest results
        """
        def execute():
            # Run backtest
            if self.use_backtrader and BACKTRADER_AVAILABLE:
                result = self.run_backtrader_backtest(
                    prices, signals, probabilities,
                    kwargs.get('strategy_params')
                )
            else:
                result = self.run_simple_backtest(
                    prices, signals,
                    kwargs.get('position_sizes')
                )

            # Calculate benchmark performance if provided
            benchmark_metrics = None
            if benchmark_prices is not None:
                bench_returns = benchmark_prices.pct_change().dropna()
                bench_equity = self.initial_capital * (1 + bench_returns).cumprod()
                benchmark_metrics = self._calculate_metrics(bench_returns, bench_equity)

            # Get performance summary
            summary = self.get_performance_summary()

            return {
                'result': result,
                'total_return': result.total_return,
                'sharpe_ratio': result.sharpe_ratio,
                'max_drawdown': result.max_drawdown,
                'equity_curve': result.equity_curve,
                'returns': result.returns,
                'trades': result.trades,
                'total_trades': result.total_trades,
                'win_rate': result.win_rate,
                'summary': summary,
                'benchmark_metrics': benchmark_metrics
            }

        return self._execute_with_timing(execute)


# Test Backtesting Agent
print("=" * 70)
print("🧪 TESTING BACKTESTING AGENT")
print("=" * 70)

# Use sample data from previous cell
if 'sample_prices' in dir() and 'sample_signals' in dir():
    backtest_agent = BacktestingAgent(config=config, use_backtrader=False)

    print("\n📊 Running backtest...")
    backtest_result = backtest_agent.run(sample_prices, sample_signals)

    if backtest_result.success:
        print(f"\n✅ Backtest completed!")
        print(f"\n📈 Performance Summary:")
        for category, metrics in backtest_result.data['summary'].items():
            print(f"\n   {category}:")
            for metric, value in metrics.items():
                print(f"      {metric}: {value}")
    else:
        print(f"❌ Error: {backtest_result.errors}")
else:
    # Create sample data
    np.random.seed(42)
    n = 200
    dates = pd.date_range(start='2023-01-01', periods=n, freq='D')

    prices = 100 * np.exp(np.cumsum(np.random.randn(n) * 0.02))
    sample_prices = pd.DataFrame({
        'Open': prices * (1 + np.random.randn(n) * 0.005),
        'High': prices * (1 + np.abs(np.random.randn(n)) * 0.01),
        'Low': prices * (1 - np.abs(np.random.randn(n)) * 0.01),
        'Close': prices,
        'Volume': np.random.randint(100000, 1000000, n)
    }, index=dates)

    sample_signals = pd.Series(
        np.random.choice([-1, 0, 1], n, p=[0.2, 0.6, 0.2]),
        index=dates
    )

    backtest_agent = BacktestingAgent(config=config, use_backtrader=False)
    backtest_result = backtest_agent.run(sample_prices, sample_signals)

    if backtest_result.success:
        print(f"\n✅ Backtest completed!")
        for category, metrics in backtest_result.data['summary'].items():
            print(f"\n   {category}:")
            for metric, value in metrics.items():
                print(f"      {metric}: {value}")

print("\n" + "=" * 70)
print("✅ Backtesting Agent ready!")