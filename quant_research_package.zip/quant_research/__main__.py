"""
__main__.py
===========
CLI entry point — lets you run the full pipeline with:

    python -m quant_research
    python -m quant_research --tickers AAPL MSFT --no-report
    quant-run                    # if installed via pip install -e .

Usage
-----
    python -m quant_research [OPTIONS]

Options
-------
  --tickers       Space-separated ticker symbols  (default: AAPL MSFT)
  --start-date    History start date YYYY-MM-DD   (default: 2010-01-01)
  --no-report     Skip HTML report generation
  --no-save       Skip saving model artefacts
  --project-dir   Override base storage directory
  --serve         Start the FastAPI inference server after the pipeline
  --port          FastAPI port                     (default: 8000)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        prog="quant_research",
        description="AI Quantitative Research System — end-to-end ML pipeline",
    )
    parser.add_argument(
        "--tickers", nargs="+", default=["AAPL", "MSFT"],
        help="Ticker symbols to process (default: AAPL MSFT)",
    )
    parser.add_argument(
        "--start-date", default="2010-01-01",
        help="Historical data start date YYYY-MM-DD (default: 2010-01-01)",
    )
    parser.add_argument(
        "--no-report", action="store_true",
        help="Skip HTML report generation",
    )
    parser.add_argument(
        "--no-save", action="store_true",
        help="Skip saving model artefacts to disk",
    )
    parser.add_argument(
        "--project-dir", default=None,
        help="Override base storage directory (default: ./quant_research_system)",
    )
    parser.add_argument(
        "--serve", action="store_true",
        help="Start the FastAPI inference server after the pipeline completes",
    )
    parser.add_argument(
        "--port", type=int, default=8000,
        help="FastAPI server port (default: 8000)",
    )
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    # ── Bootstrap paths ────────────────────────────────────────────────────
    from quant_research.config import PathManager, SystemConfig

    project_dir = args.project_dir or "quant_research_system"
    path_manager = PathManager(project_name=project_dir)

    # ── Build config ───────────────────────────────────────────────────────
    config = SystemConfig()
    config.data_config.tickers      = args.tickers
    config.data_config.start_date   = args.start_date

    # ── Run pipeline ───────────────────────────────────────────────────────
    from quant_research.pipeline import run_complete_pipeline

    results = run_complete_pipeline(
        tickers          = args.tickers,
        generate_reports = not args.no_report,
        save_models      = not args.no_save,
        config           = config,
    )

    if results:
        print("\n✅ Pipeline complete.")
        if not args.no_report and results.get("reports"):
            print("📄 Reports saved:")
            for r in results["reports"]:
                print(f"   {r}")

    # ── Optionally start API server ────────────────────────────────────────
    if args.serve:
        print(f"\n🚀 Starting FastAPI server on port {args.port} …")
        import uvicorn
        from quant_research.api.server import app
        uvicorn.run(app, host="0.0.0.0", port=args.port)


if __name__ == "__main__":
    main()
