"""
tests/unit_tests.py
===================
29 unit tests covering config, indicators, agents, models, signals, risk, portfolio
Run: python -m pytest quant_research/tests/unit_tests.py -v
"""
from __future__ import annotations


import unittest
from unittest.mock import Mock, patch, MagicMock
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


class TestConfiguration(unittest.TestCase):
    """Test configuration system."""

    def test_system_config_creation(self):
        """Test SystemConfig creation."""
        config = SystemConfig()
        self.assertIsNotNone(config)
        self.assertIsNotNone(config.data)
        self.assertIsNotNone(config.ml)

    def test_config_default_values(self):
        """Test default configuration values."""
        config = SystemConfig()
        self.assertEqual(len(config.data.tickers), 6)
        self.assertEqual(config.ml.random_seed, 42)
        self.assertEqual(config.backtest.initial_capital, 100000)

    def test_config_to_dict(self):
        """Test configuration serialization."""
        config = SystemConfig()
        config_dict = config.to_dict()
        self.assertIsInstance(config_dict, dict)
        self.assertIn('data', config_dict)
        self.assertIn('ml', config_dict)


class TestTechnicalIndicators(unittest.TestCase):
    """Test technical indicator calculations."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        self.prices = pd.Series(100 + np.cumsum(np.random.randn(100)))
        self.high = self.prices * 1.01
        self.low = self.prices * 0.99
        self.volume = pd.Series(np.random.randint(1000, 10000, 100))

    def test_sma(self):
        """Test Simple Moving Average."""
        sma = TechnicalIndicators.sma(self.prices, 20)
        self.assertEqual(len(sma), len(self.prices))
        self.assertFalse(sma.isna().all())

    def test_ema(self):
        """Test Exponential Moving Average."""
        ema = TechnicalIndicators.ema(self.prices, 20)
        self.assertEqual(len(ema), len(self.prices))
        self.assertFalse(ema.isna().all())

    def test_rsi(self):
        """Test RSI calculation."""
        rsi = TechnicalIndicators.rsi(self.prices, 14)
        self.assertEqual(len(rsi), len(self.prices))
        self.assertTrue((rsi >= 0).all() and (rsi <= 100).all())

    def test_macd(self):
        """Test MACD calculation."""
        macd, signal, histogram = TechnicalIndicators.macd(self.prices)
        self.assertEqual(len(macd), len(self.prices))
        self.assertEqual(len(signal), len(self.prices))
        self.assertEqual(len(histogram), len(self.prices))

    def test_bollinger_bands(self):
        """Test Bollinger Bands calculation."""
        upper, middle, lower = TechnicalIndicators.bollinger_bands(self.prices)
        self.assertTrue((upper >= middle).all())
        self.assertTrue((middle >= lower).all())

    def test_atr(self):
        """Test ATR calculation."""
        atr = TechnicalIndicators.atr(self.high, self.low, self.prices)
        self.assertEqual(len(atr), len(self.prices))
        self.assertTrue((atr >= 0).all())


class TestUtilityFunctions(unittest.TestCase):
    """Test utility functions."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        self.returns = pd.Series(np.random.randn(100) * 0.02)
        self.prices = pd.Series(100 * np.exp(np.cumsum(self.returns)))

    def test_calculate_returns(self):
        """Test returns calculation."""
        returns = calculate_returns(self.prices, method='simple')
        self.assertEqual(len(returns), len(self.prices))

    def test_calculate_sharpe_ratio(self):
        """Test Sharpe ratio calculation."""
        sharpe = calculate_sharpe_ratio(self.returns)
        self.assertIsInstance(sharpe, float)

    def test_calculate_sortino_ratio(self):
        """Test Sortino ratio calculation."""
        sortino = calculate_sortino_ratio(self.returns)
        self.assertIsInstance(sortino, float)

    def test_calculate_max_drawdown(self):
        """Test max drawdown calculation."""
        equity = (1 + self.returns).cumprod()
        max_dd, peak, trough = calculate_max_drawdown(equity)
        self.assertLessEqual(max_dd, 0)


class TestAgentBase(unittest.TestCase):
    """Test base agent functionality."""

    def test_base_agent_creation(self):
        """Test BaseAgent creation."""
        class TestAgent(BaseAgent):
            def run(self):
                return AgentResult(success=True, data="test")

        agent = TestAgent("TestAgent")
        self.assertEqual(agent.name, "TestAgent")
        self.assertEqual(agent.status, AgentStatus.IDLE)

    def test_agent_result_creation(self):
        """Test AgentResult creation."""
        result = AgentResult(
            success=True,
            data={"key": "value"},
            message="Success"
        )
        self.assertTrue(result.success)
        self.assertEqual(result.data["key"], "value")

    def test_agent_status_transitions(self):
        """Test agent status transitions."""
        class TestAgent(BaseAgent):
            def run(self):
                return self._execute_with_timing(lambda: "result")

        agent = TestAgent("TestAgent")
        result = agent.run()
        self.assertEqual(agent.status, AgentStatus.COMPLETED)


class TestFeatureEngineering(unittest.TestCase):
    """Test feature engineering."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        n = 200
        self.df = pd.DataFrame({
            'Open': 100 + np.cumsum(np.random.randn(n) * 0.5),
            'High': 101 + np.cumsum(np.random.randn(n) * 0.5),
            'Low': 99 + np.cumsum(np.random.randn(n) * 0.5),
            'Close': 100 + np.cumsum(np.random.randn(n) * 0.5),
            'Volume': np.random.randint(100000, 1000000, n)
        }, index=pd.date_range(start='2023-01-01', periods=n))

        # Fix OHLC consistency
        self.df['High'] = self.df[['Open', 'High', 'Close']].max(axis=1)
        self.df['Low'] = self.df[['Open', 'Low', 'Close']].min(axis=1)

    def test_feature_generation(self):
        """Test feature generation."""
        agent = FeatureEngineeringAgent(config=config)
        features = agent.generate_features(self.df)

        self.assertGreater(len(features.columns), 10)
        self.assertIn('returns', features.columns)
        self.assertIn('rsi', features.columns)

    def test_ml_data_preparation(self):
        """Test ML data preparation."""
        agent = FeatureEngineeringAgent(config=config)
        features = agent.generate_features(self.df)
        X, y, feature_names = agent.prepare_ml_data(features)

        self.assertEqual(len(X), len(y))
        self.assertGreater(len(feature_names), 0)


class TestMLModels(unittest.TestCase):
    """Test ML model agents."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        n = 200
        self.X = pd.DataFrame(
            np.random.randn(n, 10),
            columns=[f'feature_{i}' for i in range(10)]
        )
        self.y = pd.Series((self.X.sum(axis=1) > 0).astype(int))

        # Split
        self.split = int(0.8 * n)
        self.X_train = self.X[:self.split]
        self.y_train = self.y[:self.split]
        self.X_test = self.X[self.split:]
        self.y_test = self.y[self.split:]

    def test_logistic_regression_agent(self):
        """Test Logistic Regression agent."""
        agent = LogisticRegressionAgent(config=config)
        result = agent.run(self.X_train, self.y_train, self.X_test, self.y_test)

        self.assertTrue(result.success)
        self.assertIn('test_accuracy', result.data)
        self.assertGreater(result.data['test_accuracy'], 0.3)

    def test_random_forest_agent(self):
        """Test Random Forest agent."""
        agent = RandomForestAgent(config=config, n_estimators=10)
        result = agent.run(self.X_train, self.y_train, self.X_test, self.y_test)

        self.assertTrue(result.success)
        self.assertIn('feature_importance', result.data)

    @unittest.skipUnless(XGBOOST_AVAILABLE, "XGBoost not available")
    def test_xgboost_agent(self):
        """Test XGBoost agent."""
        agent = XGBoostAgent(config=config, n_estimators=10)
        result = agent.run(self.X_train, self.y_train, None, None, self.X_test, self.y_test)

        self.assertTrue(result.success)


class TestSignalGeneration(unittest.TestCase):
    """Test signal generation."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        n = 100
        dates = pd.date_range(start='2023-01-01', periods=n)
        self.probabilities = pd.Series(np.random.beta(2, 2, n), index=dates)
        self.returns = pd.Series(np.random.randn(n) * 0.02, index=dates)

    def test_signal_generation(self):
        """Test basic signal generation."""
        agent = SignalGenerationAgent(config=config)
        signals = agent.generate_signals(self.probabilities)

        self.assertEqual(len(signals), len(self.probabilities))
        self.assertTrue(signals.isin([-1, 0, 1]).all())

    def test_threshold_optimization(self):
        """Test threshold optimization."""
        agent = SignalGenerationAgent(config=config)
        thresholds = agent.optimize_thresholds(
            self.probabilities, self.returns, method='grid'
        )

        self.assertIn('buy_threshold', thresholds)
        self.assertIn('sell_threshold', thresholds)
        self.assertGreater(thresholds['buy_threshold'], thresholds['sell_threshold'])


class TestRiskManagement(unittest.TestCase):
    """Test risk management."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        n = 500
        self.returns = pd.Series(np.random.randn(n) * 0.02)

    def test_var_calculation(self):
        """Test VaR calculation."""
        agent = RiskManagementAgent(config=config)
        var = agent.calculate_var(self.returns, 0.95)

        self.assertLess(var, 0)  # VaR should be negative

    def test_cvar_calculation(self):
        """Test CVaR calculation."""
        agent = RiskManagementAgent(config=config)
        cvar = agent.calculate_cvar(self.returns, 0.95)
        var = agent.calculate_var(self.returns, 0.95)

        self.assertLessEqual(cvar, var)  # CVaR should be <= VaR

    def test_drawdown_calculation(self):
        """Test drawdown calculation."""
        agent = RiskManagementAgent(config=config)
        equity = (1 + self.returns).cumprod()
        dd_series, max_dd, max_dur, peak, trough = agent.calculate_drawdowns(equity)

        self.assertGreaterEqual(max_dd, 0)
        self.assertGreaterEqual(max_dur, 0)


class TestPortfolioOptimization(unittest.TestCase):
    """Test portfolio optimization."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        n = 200
        n_assets = 5
        self.returns = pd.DataFrame(
            np.random.randn(n, n_assets) * 0.02,
            columns=[f'Asset_{i}' for i in range(n_assets)]
        )

    def test_max_sharpe_optimization(self):
        """Test maximum Sharpe optimization."""
        agent = PortfolioOptimizationAgent(config=config)
        weights = agent.optimize_max_sharpe(self.returns)

        self.assertAlmostEqual(weights.sum(), 1.0, places=5)
        self.assertTrue((weights >= 0).all())

    def test_min_variance_optimization(self):
        """Test minimum variance optimization."""
        agent = PortfolioOptimizationAgent(config=config)
        weights = agent.optimize_min_variance(self.returns)

        self.assertAlmostEqual(weights.sum(), 1.0, places=5)

    def test_risk_parity_optimization(self):
        """Test risk parity optimization."""
        agent = PortfolioOptimizationAgent(config=config)
        weights = agent.optimize_risk_parity(self.returns)

        self.assertAlmostEqual(weights.sum(), 1.0, places=5)


# Run tests
def run_tests():
    """Run all unit tests."""
    print("=" * 70)
    print("🧪 RUNNING UNIT TESTS")
    print("=" * 70)

    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add test classes
    test_classes = [
        TestConfiguration,
        TestTechnicalIndicators,
        TestUtilityFunctions,
        TestAgentBase,
        TestFeatureEngineering,
        TestMLModels,
        TestSignalGeneration,
        TestRiskManagement,
        TestPortfolioOptimization,
    ]

    for test_class in test_classes:
        suite.addTests(loader.loadTestsFromTestCase(test_class))

    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Summary
    print("\n" + "=" * 70)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success: {result.wasSuccessful()}")
    print("=" * 70)

    return result


# Run tests
test_result = run_tests()