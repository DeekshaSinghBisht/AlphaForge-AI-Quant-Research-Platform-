"""
tests/integration_tests.py
==========================
6 integration tests covering full pipeline sub-chains end-to-end
Run: python -m pytest quant_research/tests/integration_tests.py -v
"""
from __future__ import annotations


import unittest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


class IntegrationTestSuite(unittest.TestCase):
    """Integration tests for the complete pipeline."""

    @classmethod
    def setUpClass(cls):
        """Set up test fixtures."""
        np.random.seed(42)

        # Generate test data
        n = 300
        cls.dates = pd.date_range(start='2022-01-01', periods=n, freq='D')

        # Generate price data
        returns = np.random.randn(n) * 0.02
        prices = 100 * np.exp(np.cumsum(returns))

        cls.price_data = pd.DataFrame({
            'Open': prices * (1 + np.random.randn(n) * 0.005),
            'High': prices * (1 + np.abs(np.random.randn(n)) * 0.01),
            'Low': prices * (1 - np.abs(np.random.randn(n)) * 0.01),
            'Close': prices,
            'Volume': np.random.randint(100000, 1000000, n),
            'Returns': np.concatenate([[0], returns[1:]])
        }, index=cls.dates)

        # Fix OHLC consistency
        cls.price_data['High'] = cls.price_data[['Open', 'High', 'Close']].max(axis=1)
        cls.price_data['Low'] = cls.price_data[['Open', 'Low', 'Close']].min(axis=1)

        # Config
        cls.config = SystemConfig()

    def test_data_to_features_pipeline(self):
        """Test data acquisition to feature engineering pipeline."""
        # Feature engineering
        feature_agent = FeatureEngineeringAgent(config=self.config)
        result = feature_agent.run(self.price_data)

        self.assertTrue(result.success)
        self.assertIn('X', result.data)
        self.assertIn('y', result.data)
        self.assertGreater(result.data['n_features'], 10)

    def test_features_to_model_pipeline(self):
        """Test feature engineering to model training pipeline."""
        # Generate features
        feature_agent = FeatureEngineeringAgent(config=self.config)
        feature_result = feature_agent.run(self.price_data)

        X = feature_result.data['X']
        y = feature_result.data['y']

        # Train model
        split = int(0.8 * len(X))
        X_train, X_test = X[:split], X[split:]
        y_train, y_test = y[:split], y[split:]

        rf_agent = RandomForestAgent(config=self.config, n_estimators=50)
        model_result = rf_agent.run(X_train, y_train, X_test, y_test)

        self.assertTrue(model_result.success)
        self.assertIn('test_accuracy', model_result.data)

    def test_model_to_signal_pipeline(self):
        """Test model prediction to signal generation pipeline."""
        # Generate features
        feature_agent = FeatureEngineeringAgent(config=self.config)
        feature_result = feature_agent.run(self.price_data)

        X = feature_result.data['X']
        y = feature_result.data['y']

        # Train model
        split = int(0.8 * len(X))
        X_train = X[:split]
        y_train = y[:split]

        rf_agent = RandomForestAgent(config=self.config, n_estimators=50)
        rf_agent.fit(X_train, y_train)

        # Generate predictions
        probabilities = pd.Series(
            rf_agent.predict_proba(X),
            index=X.index
        )

        # Generate signals
        returns = self.price_data['Returns'].reindex(X.index)
        signal_agent = SignalGenerationAgent(config=self.config)
        signal_result = signal_agent.run(probabilities, returns=returns)

        self.assertTrue(signal_result.success)
        self.assertIn('signals', signal_result.data)

    def test_signal_to_backtest_pipeline(self):
        """Test signal generation to backtesting pipeline."""
        # Create simple signals
        signals = pd.Series(
            np.random.choice([-1, 0, 1], len(self.dates), p=[0.2, 0.6, 0.2]),
            index=self.dates
        )

        # Run backtest
        backtest_agent = BacktestingAgent(config=self.config, use_backtrader=False)
        backtest_result = backtest_agent.run(self.price_data, signals)

        self.assertTrue(backtest_result.success)
        self.assertIn('total_return', backtest_result.data)
        self.assertIn('sharpe_ratio', backtest_result.data)

    def test_backtest_to_risk_pipeline(self):
        """Test backtesting to risk analysis pipeline."""
        # Create signals
        signals = pd.Series(
            np.random.choice([-1, 0, 1], len(self.dates), p=[0.2, 0.6, 0.2]),
            index=self.dates
        )

        # Run backtest
        backtest_agent = BacktestingAgent(config=self.config, use_backtrader=False)
        backtest_result = backtest_agent.run(self.price_data, signals)

        # Risk analysis
        returns = backtest_result.data['returns']
        risk_agent = RiskManagementAgent(config=self.config)
        risk_result = risk_agent.run(returns)

        self.assertTrue(risk_result.success)
        self.assertIn('var_95', risk_result.data)
        self.assertIn('max_drawdown', risk_result.data)

    def test_full_mini_pipeline(self):
        """Test complete mini pipeline end-to-end."""
        # 1. Feature Engineering
        feature_agent = FeatureEngineeringAgent(config=self.config)
        feature_result = feature_agent.run(self.price_data)
        self.assertTrue(feature_result.success)

        X = feature_result.data['X']
        y = feature_result.data['y']

        # 2. Train/Test Split
        split = int(0.7 * len(X))
        X_train, X_test = X[:split], X[split:]
        y_train, y_test = y[:split], y[split:]

        # 3. Model Training
        rf_agent = RandomForestAgent(config=self.config, n_estimators=50)
        model_result = rf_agent.run(X_train, y_train, X_test, y_test)
        self.assertTrue(model_result.success)

        # 4. Generate Signals
        probabilities = pd.Series(
            rf_agent.predict_proba(X_test),
            index=X_test.index
        )

        signal_agent = SignalGenerationAgent(config=self.config)
        signals = signal_agent.generate_signals(probabilities)

        # 5. Backtest
        test_prices = self.price_data.loc[X_test.index]
        backtest_agent = BacktestingAgent(config=self.config, use_backtrader=False)
        backtest_result = backtest_agent.run(test_prices, signals)
        self.assertTrue(backtest_result.success)

        # 6. Risk Analysis
        returns = backtest_result.data['returns']
        risk_agent = RiskManagementAgent(config=self.config)
        risk_result = risk_agent.run(returns)
        self.assertTrue(risk_result.success)

        # 7. Verify outputs
        print("\n   📊 Pipeline Results:")
        print(f"      Model Accuracy: {model_result.data['test_accuracy']:.4f}")
        print(f"      Total Return: {backtest_result.data['total_return']*100:.2f}%")
        print(f"      Sharpe Ratio: {backtest_result.data['sharpe_ratio']:.4f}")
        print(f"      Max Drawdown: {risk_result.data['max_drawdown']*100:.2f}%")


def run_integration_tests():
    """Run all integration tests."""
    print("=" * 70)
    print("🔗 RUNNING INTEGRATION TESTS")
    print("=" * 70)

    # Create test suite
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(IntegrationTestSuite)

    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Summary
    print("\n" + "=" * 70)
    print(f"Integration Tests: {result.testsRun}")
    print(f"Passed: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failed: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("=" * 70)

    return result


# Run integration tests
integration_result = run_integration_tests()