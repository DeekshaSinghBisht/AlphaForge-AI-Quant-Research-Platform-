"""
charts.py
=========
ReportGenerator (chart helpers)
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Union
from datetime import datetime
from pathlib import Path
import json
import base64
from io import BytesIO
import warnings
warnings.filterwarnings('ignore')

# Visualization imports
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns

# Set style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")


class ReportGenerator:
    """
    Utility class for generating report components.

    Features:
    - Chart generation
    - Table formatting
    - HTML/PDF export
    """

    def __init__(self, output_dir: Path = None):
        """
        Initialize Report Generator.

        Args:
            output_dir: Output directory for reports
        """
        self.output_dir = output_dir or REPORTS_PATH
        self.figures: Dict[str, plt.Figure] = {}
        self.tables: Dict[str, pd.DataFrame] = {}

    def create_equity_curve_chart(
        self,
        equity_curve: pd.Series,
        benchmark_equity: Optional[pd.Series] = None,
        title: str = "Portfolio Equity Curve"
    ) -> plt.Figure:
        """Create equity curve chart."""
        fig, ax = plt.subplots(figsize=(12, 6))

        ax.plot(equity_curve.index, equity_curve.values,
                label='Strategy', linewidth=2, color='#2E86AB')

        if benchmark_equity is not None:
            # Normalize benchmark to same starting point
            bench_norm = benchmark_equity / benchmark_equity.iloc[0] * equity_curve.iloc[0]
            ax.plot(bench_norm.index, bench_norm.values,
                   label='Benchmark', linewidth=2, color='#A23B72', alpha=0.7)

        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Portfolio Value ($)', fontsize=12)
        ax.legend(loc='upper left')
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        plt.xticks(rotation=45)

        # Add grid
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        self.figures['equity_curve'] = fig

        return fig

    def create_drawdown_chart(
        self,
        equity_curve: pd.Series,
        title: str = "Drawdown Analysis"
    ) -> plt.Figure:
        """Create drawdown chart."""
        # Calculate drawdown
        running_max = equity_curve.expanding().max()
        drawdown = (equity_curve - running_max) / running_max * 100

        fig, ax = plt.subplots(figsize=(12, 4))

        ax.fill_between(drawdown.index, drawdown.values, 0,
                       color='#E74C3C', alpha=0.5)
        ax.plot(drawdown.index, drawdown.values,
               color='#C0392B', linewidth=1)

        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Drawdown (%)', fontsize=12)
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        plt.xticks(rotation=45)

        # Highlight max drawdown
        max_dd_idx = drawdown.idxmin()
        max_dd_val = drawdown.min()
        ax.annotate(f'Max DD: {max_dd_val:.1f}%',
                   xy=(max_dd_idx, max_dd_val),
                   xytext=(10, -20), textcoords='offset points',
                   fontsize=10, color='#C0392B',
                   arrowprops=dict(arrowstyle='->', color='#C0392B'))

        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        self.figures['drawdown'] = fig

        return fig

    def create_returns_distribution_chart(
        self,
        returns: pd.Series,
        title: str = "Returns Distribution"
    ) -> plt.Figure:
        """Create returns distribution chart."""
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Histogram
        ax1 = axes[0]
        returns_pct = returns * 100
        ax1.hist(returns_pct, bins=50, density=True, alpha=0.7,
                color='#3498DB', edgecolor='white')

        # Fit normal distribution
        mu, std = returns_pct.mean(), returns_pct.std()
        x = np.linspace(returns_pct.min(), returns_pct.max(), 100)
        from scipy.stats import norm
        ax1.plot(x, norm.pdf(x, mu, std), 'r-', linewidth=2,
                label=f'Normal (μ={mu:.2f}%, σ={std:.2f}%)')

        ax1.set_title('Daily Returns Distribution', fontsize=12, fontweight='bold')
        ax1.set_xlabel('Return (%)', fontsize=10)
        ax1.set_ylabel('Density', fontsize=10)
        ax1.legend()
        ax1.axvline(x=0, color='black', linestyle='--', alpha=0.5)

        # QQ Plot
        ax2 = axes[1]
        from scipy import stats
        stats.probplot(returns.dropna(), dist="norm", plot=ax2)
        ax2.set_title('Q-Q Plot (Normal)', fontsize=12, fontweight='bold')
        ax2.get_lines()[0].set_markerfacecolor('#3498DB')
        ax2.get_lines()[0].set_markeredgecolor('#2980B9')

        plt.tight_layout()
        self.figures['returns_distribution'] = fig

        return fig

    def create_rolling_metrics_chart(
        self,
        returns: pd.Series,
        window: int = 63,
        title: str = "Rolling Performance Metrics"
    ) -> plt.Figure:
        """Create rolling metrics chart."""
        fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)

        # Rolling Sharpe
        ax1 = axes[0]
        rf = 0.05 / 252
        rolling_sharpe = (
            (returns.rolling(window).mean() - rf) /
            returns.rolling(window).std()
        ) * np.sqrt(252)

        ax1.plot(rolling_sharpe.index, rolling_sharpe.values,
                color='#2E86AB', linewidth=1.5)
        ax1.axhline(y=0, color='red', linestyle='--', alpha=0.5)
        ax1.axhline(y=1, color='green', linestyle='--', alpha=0.5)
        ax1.fill_between(rolling_sharpe.index, rolling_sharpe.values, 0,
                        where=rolling_sharpe.values > 0, alpha=0.3, color='green')
        ax1.fill_between(rolling_sharpe.index, rolling_sharpe.values, 0,
                        where=rolling_sharpe.values < 0, alpha=0.3, color='red')
        ax1.set_ylabel('Rolling Sharpe', fontsize=10)
        ax1.set_title(title, fontsize=14, fontweight='bold')

        # Rolling Volatility
        ax2 = axes[1]
        rolling_vol = returns.rolling(window).std() * np.sqrt(252) * 100
        ax2.plot(rolling_vol.index, rolling_vol.values,
                color='#E74C3C', linewidth=1.5)
        ax2.fill_between(rolling_vol.index, rolling_vol.values, 0,
                        alpha=0.3, color='#E74C3C')
        ax2.set_ylabel('Rolling Vol (%)', fontsize=10)

        # Rolling Returns
        ax3 = axes[2]
        rolling_ret = returns.rolling(window).mean() * 252 * 100
        ax3.plot(rolling_ret.index, rolling_ret.values,
                color='#27AE60', linewidth=1.5)
        ax3.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax3.fill_between(rolling_ret.index, rolling_ret.values, 0,
                        where=rolling_ret.values > 0, alpha=0.3, color='green')
        ax3.fill_between(rolling_ret.index, rolling_ret.values, 0,
                        where=rolling_ret.values < 0, alpha=0.3, color='red')
        ax3.set_ylabel('Rolling Return (%)', fontsize=10)
        ax3.set_xlabel('Date', fontsize=10)

        for ax in axes:
            ax.grid(True, alpha=0.3)
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))

        plt.tight_layout()
        self.figures['rolling_metrics'] = fig

        return fig

    def create_monthly_returns_heatmap(
        self,
        returns: pd.Series,
        title: str = "Monthly Returns Heatmap"
    ) -> plt.Figure:
        """Create monthly returns heatmap."""
        # Resample to monthly
        monthly_returns = returns.resample('M').apply(
            lambda x: (1 + x).prod() - 1
        ) * 100

        # Create pivot table
        monthly_df = pd.DataFrame({
            'Year': monthly_returns.index.year,
            'Month': monthly_returns.index.month,
            'Return': monthly_returns.values
        })

        pivot = monthly_df.pivot(index='Year', columns='Month', values='Return')
        pivot.columns = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        fig, ax = plt.subplots(figsize=(14, 6))

        sns.heatmap(pivot, annot=True, fmt='.1f', center=0,
                   cmap='RdYlGn', linewidths=0.5,
                   cbar_kws={'label': 'Return (%)'}, ax=ax)

        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Month', fontsize=12)
        ax.set_ylabel('Year', fontsize=12)

        plt.tight_layout()
        self.figures['monthly_heatmap'] = fig

        return fig

    def create_portfolio_weights_chart(
        self,
        weights: pd.Series,
        title: str = "Portfolio Allocation"
    ) -> plt.Figure:
        """Create portfolio weights pie chart."""
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Filter non-zero weights
        weights_filtered = weights[weights > 0.01].sort_values(ascending=False)

        # Pie chart
        ax1 = axes[0]
        colors = plt.cm.Set3(np.linspace(0, 1, len(weights_filtered)))
        wedges, texts, autotexts = ax1.pie(
            weights_filtered.values,
            labels=weights_filtered.index,
            autopct='%1.1f%%',
            colors=colors,
            startangle=90
        )
        ax1.set_title('Portfolio Weights', fontsize=12, fontweight='bold')

        # Bar chart
        ax2 = axes[1]
        bars = ax2.barh(weights_filtered.index, weights_filtered.values * 100,
                       color=colors)
        ax2.set_xlabel('Weight (%)', fontsize=10)
        ax2.set_title('Allocation by Asset', fontsize=12, fontweight='bold')
        ax2.invert_yaxis()

        # Add value labels
        for bar, val in zip(bars, weights_filtered.values):
            ax2.text(val * 100 + 0.5, bar.get_y() + bar.get_height()/2,
                    f'{val*100:.1f}%', va='center', fontsize=9)

        plt.tight_layout()
        self.figures['portfolio_weights'] = fig

        return fig

    def create_monte_carlo_chart(
        self,
        simulations: np.ndarray,
        initial_value: float = 100000,
        title: str = "Monte Carlo Simulation"
    ) -> plt.Figure:
        """Create Monte Carlo simulation fan chart."""
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # Fan chart
        ax1 = axes[0]
        horizon = simulations.shape[1]
        x = np.arange(horizon)

        # Calculate percentiles
        p5 = np.percentile(simulations, 5, axis=0)
        p25 = np.percentile(simulations, 25, axis=0)
        p50 = np.percentile(simulations, 50, axis=0)
        p75 = np.percentile(simulations, 75, axis=0)
        p95 = np.percentile(simulations, 95, axis=0)

        ax1.fill_between(x, p5, p95, alpha=0.2, color='blue', label='5-95%')
        ax1.fill_between(x, p25, p75, alpha=0.4, color='blue', label='25-75%')
        ax1.plot(x, p50, 'b-', linewidth=2, label='Median')
        ax1.axhline(y=initial_value, color='red', linestyle='--',
                   alpha=0.7, label='Initial Value')

        ax1.set_title(title, fontsize=12, fontweight='bold')
        ax1.set_xlabel('Days', fontsize=10)
        ax1.set_ylabel('Portfolio Value ($)', fontsize=10)
        ax1.legend(loc='upper left')
        ax1.grid(True, alpha=0.3)

        # Terminal value distribution
        ax2 = axes[1]
        terminal_values = simulations[:, -1]
        ax2.hist(terminal_values, bins=50, density=True, alpha=0.7,
                color='#3498DB', edgecolor='white')
        ax2.axvline(x=initial_value, color='red', linestyle='--',
                   linewidth=2, label='Initial Value')
        ax2.axvline(x=np.median(terminal_values), color='green', linestyle='--',
                   linewidth=2, label=f'Median: ${np.median(terminal_values):,.0f}')

        ax2.set_title('Terminal Value Distribution', fontsize=12, fontweight='bold')
        ax2.set_xlabel('Portfolio Value ($)', fontsize=10)
        ax2.set_ylabel('Density', fontsize=10)
        ax2.legend()

        plt.tight_layout()
        self.figures['monte_carlo'] = fig

        return fig

    def figure_to_base64(self, fig: plt.Figure) -> str:
        """Convert figure to base64 string for HTML embedding."""
        buffer = BytesIO()
        fig.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
        buffer.seek(0)
        img_str = base64.b64encode(buffer.read()).decode()
        plt.close(fig)
        return img_str

    def save_figure(self, fig: plt.Figure, name: str, dpi: int = 150) -> Path:
        """Save figure to file."""
        filepath = self.output_dir / f"{name}.png"
        fig.savefig(filepath, dpi=dpi, bbox_inches='tight')
        return filepath


# Test Report Generator
print("=" * 70)
print("🧪 TESTING REPORT GENERATOR")
print("=" * 70)

# Create sample data
np.random.seed(42)
n = 500
dates = pd.date_range(start='2021-01-01', periods=n, freq='D')

sample_returns = pd.Series(
    np.random.randn(n) * 0.015 + 0.0003,
    index=dates
)
sample_equity = 100000 * (1 + sample_returns).cumprod()

benchmark_returns = pd.Series(
    np.random.randn(n) * 0.012,
    index=dates
)
benchmark_equity = 100000 * (1 + benchmark_returns).cumprod()

# Test chart generation
report_gen = ReportGenerator()

print("\n📊 Generating charts...")

# Equity curve
fig1 = report_gen.create_equity_curve_chart(sample_equity, benchmark_equity)
print("   ✅ Equity curve chart")

# Drawdown
fig2 = report_gen.create_drawdown_chart(sample_equity)
print("   ✅ Drawdown chart")

# Returns distribution
fig3 = report_gen.create_returns_distribution_chart(sample_returns)
print("   ✅ Returns distribution chart")

# Rolling metrics
fig4 = report_gen.create_rolling_metrics_chart(sample_returns)
print("   ✅ Rolling metrics chart")

# Monthly heatmap
fig5 = report_gen.create_monthly_returns_heatmap(sample_returns)
print("   ✅ Monthly heatmap")

# Display one chart
plt.figure(figsize=(12, 6))
report_gen.create_equity_curve_chart(sample_equity, benchmark_equity)
plt.show()

print("\n✅ Report Generator ready!")