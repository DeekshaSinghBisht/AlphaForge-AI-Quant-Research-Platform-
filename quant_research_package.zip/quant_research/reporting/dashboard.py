"""
dashboard.py
============
VisualizationDashboard + QuantVisualizer
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Rectangle
import seaborn as sns
from typing import Dict, Optional, Any, List
import warnings
warnings.filterwarnings('ignore')

plt.style.use('seaborn-v0_8-whitegrid')


class VisualizationDashboard:
    """
    Interactive visualization dashboard for research results.

    Creates comprehensive multi-panel visualizations.
    """

    def __init__(self, figsize: tuple = (16, 20)):
        """
        Initialize dashboard.

        Args:
            figsize: Figure size
        """
        self.figsize = figsize
        self.colors = {
            'primary': '#2E86AB',
            'secondary': '#A23B72',
            'success': '#27AE60',
            'danger': '#E74C3C',
            'warning': '#F39C12',
            'info': '#3498DB',
            'dark': '#1a1a2e'
        }

    def create_performance_dashboard(
        self,
        equity_curve: pd.Series,
        returns: pd.Series,
        benchmark_equity: Optional[pd.Series] = None,
        title: str = "Strategy Performance Dashboard"
    ) -> plt.Figure:
        """
        Create comprehensive performance dashboard.

        Args:
            equity_curve: Portfolio equity curve
            returns: Strategy returns
            benchmark_equity: Benchmark equity (optional)
            title: Dashboard title

        Returns:
            Matplotlib figure
        """
        fig = plt.figure(figsize=self.figsize)
        gs = gridspec.GridSpec(4, 2, height_ratios=[2, 1, 1, 1], hspace=0.3, wspace=0.2)

        # Title
        fig.suptitle(title, fontsize=16, fontweight='bold', y=0.98)

        # 1. Equity Curve (top, spanning both columns)
        ax1 = fig.add_subplot(gs[0, :])
        ax1.plot(equity_curve.index, equity_curve.values,
                label='Strategy', color=self.colors['primary'], linewidth=2)

        if benchmark_equity is not None:
            bench_norm = benchmark_equity / benchmark_equity.iloc[0] * equity_curve.iloc[0]
            ax1.plot(bench_norm.index, bench_norm.values,
                    label='Benchmark', color=self.colors['secondary'],
                    linewidth=2, alpha=0.7)

        ax1.set_title('Equity Curve', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Portfolio Value ($)')
        ax1.legend(loc='upper left')
        ax1.grid(True, alpha=0.3)

        # Calculate and annotate key metrics
        total_return = (equity_curve.iloc[-1] / equity_curve.iloc[0] - 1) * 100
        ax1.annotate(f'Total Return: {total_return:.1f}%',
                    xy=(0.02, 0.95), xycoords='axes fraction',
                    fontsize=10, fontweight='bold',
                    bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

        # 2. Drawdown Chart
        ax2 = fig.add_subplot(gs[1, :])
        running_max = equity_curve.expanding().max()
        drawdown = (equity_curve - running_max) / running_max * 100

        ax2.fill_between(drawdown.index, drawdown.values, 0,
                        color=self.colors['danger'], alpha=0.5)
        ax2.plot(drawdown.index, drawdown.values,
                color=self.colors['danger'], linewidth=1)
        ax2.set_title('Drawdown', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Drawdown (%)')
        ax2.grid(True, alpha=0.3)

        # Annotate max drawdown
        max_dd = drawdown.min()
        ax2.annotate(f'Max DD: {max_dd:.1f}%',
                    xy=(0.02, 0.1), xycoords='axes fraction',
                    fontsize=10, color=self.colors['danger'], fontweight='bold')

        # 3. Returns Distribution
        ax3 = fig.add_subplot(gs[2, 0])
        returns_pct = returns * 100
        ax3.hist(returns_pct, bins=50, density=True, alpha=0.7,
                color=self.colors['info'], edgecolor='white')
        ax3.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax3.axvline(x=returns_pct.mean(), color=self.colors['success'],
                   linestyle='-', linewidth=2, label=f'Mean: {returns_pct.mean():.2f}%')
        ax3.set_title('Daily Returns Distribution', fontsize=12, fontweight='bold')
        ax3.set_xlabel('Return (%)')
        ax3.set_ylabel('Density')
        ax3.legend()

        # 4. Rolling Sharpe Ratio
        ax4 = fig.add_subplot(gs[2, 1])
        rf = 0.05 / 252
        rolling_sharpe = (
            (returns.rolling(63).mean() - rf) /
            returns.rolling(63).std()
        ) * np.sqrt(252)

        ax4.plot(rolling_sharpe.index, rolling_sharpe.values,
                color=self.colors['primary'], linewidth=1.5)
        ax4.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax4.axhline(y=1, color=self.colors['success'], linestyle='--', alpha=0.5)
        ax4.axhline(y=2, color=self.colors['success'], linestyle=':', alpha=0.5)
        ax4.fill_between(rolling_sharpe.index, rolling_sharpe.values, 0,
                        where=rolling_sharpe.values > 0, alpha=0.3, color='green')
        ax4.fill_between(rolling_sharpe.index, rolling_sharpe.values, 0,
                        where=rolling_sharpe.values < 0, alpha=0.3, color='red')
        ax4.set_title('Rolling Sharpe Ratio (63-day)', fontsize=12, fontweight='bold')
        ax4.set_ylabel('Sharpe Ratio')
        ax4.grid(True, alpha=0.3)

        # 5. Monthly Returns Heatmap
        ax5 = fig.add_subplot(gs[3, 0])
        monthly_returns = returns.resample('M').apply(lambda x: (1+x).prod()-1) * 100

        monthly_df = pd.DataFrame({
            'Year': monthly_returns.index.year,
            'Month': monthly_returns.index.month,
            'Return': monthly_returns.values
        })

        if len(monthly_df['Year'].unique()) > 1:
            pivot = monthly_df.pivot(index='Year', columns='Month', values='Return')
            sns.heatmap(pivot, annot=True, fmt='.1f', center=0,
                       cmap='RdYlGn', linewidths=0.5, ax=ax5,
                       cbar_kws={'label': 'Return (%)'})
            ax5.set_title('Monthly Returns (%)', fontsize=12, fontweight='bold')
        else:
            ax5.bar(monthly_df['Month'], monthly_df['Return'],
                   color=[self.colors['success'] if r > 0 else self.colors['danger']
                         for r in monthly_df['Return']])
            ax5.set_title('Monthly Returns (%)', fontsize=12, fontweight='bold')
            ax5.set_xlabel('Month')
            ax5.set_ylabel('Return (%)')

        # 6. Key Metrics Summary
        ax6 = fig.add_subplot(gs[3, 1])
        ax6.axis('off')

        # Calculate metrics
        sharpe = calculate_sharpe_ratio(returns)
        sortino = calculate_sortino_ratio(returns)
        calmar = (returns.mean() * 252) / abs(drawdown.min() / 100) if drawdown.min() != 0 else 0
        volatility = returns.std() * np.sqrt(252) * 100
        win_rate = (returns > 0).mean() * 100

        metrics_text = f"""
        ╔══════════════════════════════════════╗
        ║         PERFORMANCE METRICS          ║
        ╠══════════════════════════════════════╣
        ║  Total Return:     {total_return:>10.2f}%     ║
        ║  Annual Volatility:{volatility:>10.2f}%     ║
        ║  Sharpe Ratio:     {sharpe:>10.3f}       ║
        ║  Sortino Ratio:    {sortino:>10.3f}       ║
        ║  Calmar Ratio:     {calmar:>10.3f}       ║
        ║  Max Drawdown:     {max_dd:>10.2f}%     ║
        ║  Win Rate:         {win_rate:>10.1f}%     ║
        ╚══════════════════════════════════════╝
        """

        ax6.text(0.5, 0.5, metrics_text, fontsize=11, fontfamily='monospace',
                ha='center', va='center', transform=ax6.transAxes,
                bbox=dict(boxstyle='round', facecolor='#f8f9fa', edgecolor='#1a1a2e'))

        plt.tight_layout()

        return fig

    def create_model_comparison_chart(
        self,
        model_results: Dict[str, Dict[str, float]],
        metric: str = 'accuracy'
    ) -> plt.Figure:
        """
        Create model comparison chart.

        Args:
            model_results: Dictionary of model results
            metric: Metric to compare

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        models = list(model_results.keys())

        # Accuracy comparison
        ax1 = axes[0]
        accuracies = [model_results[m].get('accuracy', 0) for m in models]
        colors = [self.colors['primary'], self.colors['secondary'],
                 self.colors['success'], self.colors['warning']][:len(models)]

        bars = ax1.bar(models, accuracies, color=colors, alpha=0.8)
        ax1.set_title('Model Accuracy Comparison', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Accuracy')
        ax1.set_ylim(0, 1)

        for bar, acc in zip(bars, accuracies):
            ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{acc:.3f}', ha='center', fontsize=10)

        # AUC comparison
        ax2 = axes[1]
        aucs = [model_results[m].get('auc', 0.5) for m in models]

        bars = ax2.bar(models, aucs, color=colors, alpha=0.8)
        ax2.set_title('Model AUC Comparison', fontsize=12, fontweight='bold')
        ax2.set_ylabel('AUC')
        ax2.set_ylim(0.4, 1)
        ax2.axhline(y=0.5, color='red', linestyle='--', alpha=0.5, label='Random')
        ax2.legend()

        for bar, auc in zip(bars, aucs):
            ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{auc:.3f}', ha='center', fontsize=10)

        plt.tight_layout()

        return fig

    def create_risk_dashboard(
        self,
        returns: pd.Series,
        var_95: float,
        cvar_95: float,
        title: str = "Risk Analysis Dashboard"
    ) -> plt.Figure:
        """
        Create risk analysis dashboard.

        Args:
            returns: Strategy returns
            var_95: 95% VaR
            cvar_95: 95% CVaR
            title: Dashboard title

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle(title, fontsize=14, fontweight='bold')

        # 1. VaR visualization
        ax1 = axes[0, 0]
        returns_pct = returns * 100
        ax1.hist(returns_pct, bins=50, density=True, alpha=0.7,
                color=self.colors['info'], edgecolor='white')
        ax1.axvline(x=var_95*100, color=self.colors['warning'], linewidth=2,
                   linestyle='--', label=f'VaR (95%): {var_95*100:.2f}%')
        ax1.axvline(x=cvar_95*100, color=self.colors['danger'], linewidth=2,
                   linestyle='--', label=f'CVaR (95%): {cvar_95*100:.2f}%')
        ax1.set_title('Value at Risk', fontsize=12, fontweight='bold')
        ax1.set_xlabel('Return (%)')
        ax1.legend()

        # 2. Rolling volatility
        ax2 = axes[0, 1]
        rolling_vol = returns.rolling(21).std() * np.sqrt(252) * 100
        ax2.plot(rolling_vol.index, rolling_vol.values, color=self.colors['danger'])
        ax2.fill_between(rolling_vol.index, rolling_vol.values, 0,
                        alpha=0.3, color=self.colors['danger'])
        ax2.set_title('Rolling Volatility (21-day)', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Annualized Vol (%)')
        ax2.grid(True, alpha=0.3)

        # 3. Return autocorrelation
        ax3 = axes[1, 0]
        lags = range(1, 21)
        autocorr = [returns.autocorr(lag) for lag in lags]
        ax3.bar(lags, autocorr, color=self.colors['primary'], alpha=0.7)
        ax3.axhline(y=0, color='black', linestyle='-', alpha=0.5)
        ax3.axhline(y=1.96/np.sqrt(len(returns)), color='red', linestyle='--', alpha=0.5)
        ax3.axhline(y=-1.96/np.sqrt(len(returns)), color='red', linestyle='--', alpha=0.5)
        ax3.set_title('Return Autocorrelation', fontsize=12, fontweight='bold')
        ax3.set_xlabel('Lag (days)')
        ax3.set_ylabel('Autocorrelation')

        # 4. Risk metrics table
        ax4 = axes[1, 1]
        ax4.axis('off')

        # Calculate additional metrics
        volatility = returns.std() * np.sqrt(252) * 100
        skewness = returns.skew()
        kurtosis = returns.kurtosis()

        metrics_data = [
            ['VaR (95%)', f'{var_95*100:.2f}%'],
            ['CVaR (95%)', f'{cvar_95*100:.2f}%'],
            ['Volatility (Ann.)', f'{volatility:.2f}%'],
            ['Skewness', f'{skewness:.3f}'],
            ['Kurtosis', f'{kurtosis:.3f}'],
            ['Worst Day', f'{returns.min()*100:.2f}%'],
            ['Best Day', f'{returns.max()*100:.2f}%'],
        ]

        table = ax4.table(cellText=metrics_data,
                         colLabels=['Metric', 'Value'],
                         loc='center',
                         cellLoc='center',
                         colWidths=[0.4, 0.3])
        table.auto_set_font_size(False)
        table.set_fontsize(11)
        table.scale(1.5, 2)

        # Style header
        for i in range(2):
            table[(0, i)].set_facecolor(self.colors['dark'])
            table[(0, i)].set_text_props(color='white', fontweight='bold')

        plt.tight_layout()

        return fig


# Test Visualization Dashboard
print("=" * 70)
print("🧪 TESTING VISUALIZATION DASHBOARD")
print("=" * 70)

# Create sample data
np.random.seed(42)
n = 500
dates = pd.date_range(start='2021-01-01', periods=n, freq='D')

sample_returns = pd.Series(
    np.random.randn(n) * 0.015 + 0.0003,
    index=dates
)
sample_equity = 100000 * (1 + sample_returns).cumprod()

benchmark_returns = pd.Series(
    np.random.randn(n) * 0.012,
    index=dates
)
benchmark_equity = 100000 * (1 + benchmark_returns).cumprod()

# Create dashboard
dashboard = VisualizationDashboard()

print("\n📊 Creating Performance Dashboard...")
fig = dashboard.create_performance_dashboard(
    sample_equity, sample_returns, benchmark_equity
)
plt.show()

print("\n✅ Visualization Dashboard ready!")


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.dates as mdates
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
import seaborn as sns
from typing import Dict, Optional, Any, List, Tuple
import warnings
warnings.filterwarnings('ignore')

# Set professional style
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['figure.figsize'] = (12, 6)
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 10


class QuantVisualizer:
    """
    Complete visualization suite for quantitative research.

    All charts needed for comprehensive analysis.
    """

    def __init__(self):
        """Initialize visualizer with color schemes."""
        self.colors = {
            'primary': '#2E86AB',
            'secondary': '#A23B72',
            'success': '#27AE60',
            'danger': '#E74C3C',
            'warning': '#F39C12',
            'info': '#3498DB',
            'purple': '#9B59B6',
            'dark': '#1a1a2e',
            'light': '#f8f9fa'
        }

        self.cmap_diverging = 'RdYlGn'
        self.cmap_sequential = 'Blues'

    # ========================================================================
    # PERFORMANCE CHARTS
    # ========================================================================

    def plot_equity_curve(
        self,
        equity: pd.Series,
        benchmark: Optional[pd.Series] = None,
        title: str = "Portfolio Equity Curve",
        figsize: Tuple[int, int] = (14, 6)
    ) -> plt.Figure:
        """
        Plot equity curve with optional benchmark comparison.

        Args:
            equity: Portfolio equity series
            benchmark: Benchmark equity series (optional)
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)

        # Plot strategy
        ax.plot(equity.index, equity.values,
                label='Strategy', color=self.colors['primary'], linewidth=2)

        # Plot benchmark
        if benchmark is not None:
            # Normalize to same starting point
            bench_norm = benchmark / benchmark.iloc[0] * equity.iloc[0]
            ax.plot(bench_norm.index, bench_norm.values,
                   label='Benchmark', color=self.colors['secondary'],
                   linewidth=2, alpha=0.7)

        # Formatting
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Date')
        ax.set_ylabel('Portfolio Value ($)')
        ax.legend(loc='upper left')
        ax.grid(True, alpha=0.3)

        # Format x-axis
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        plt.xticks(rotation=45)

        # Add annotations
        total_return = (equity.iloc[-1] / equity.iloc[0] - 1) * 100
        ax.annotate(f'Total Return: {total_return:.1f}%',
                   xy=(0.02, 0.95), xycoords='axes fraction',
                   fontsize=11, fontweight='bold',
                   bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))

        plt.tight_layout()
        return fig

    def plot_drawdown(
        self,
        equity: pd.Series,
        title: str = "Drawdown Analysis",
        figsize: Tuple[int, int] = (14, 4)
    ) -> plt.Figure:
        """
        Plot drawdown chart.

        Args:
            equity: Portfolio equity series
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)

        # Calculate drawdown
        running_max = equity.expanding().max()
        drawdown = (equity - running_max) / running_max * 100

        # Plot
        ax.fill_between(drawdown.index, drawdown.values, 0,
                       color=self.colors['danger'], alpha=0.5)
        ax.plot(drawdown.index, drawdown.values,
               color=self.colors['danger'], linewidth=1)

        # Formatting
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Date')
        ax.set_ylabel('Drawdown (%)')
        ax.grid(True, alpha=0.3)

        # Highlight max drawdown
        max_dd_idx = drawdown.idxmin()
        max_dd_val = drawdown.min()
        ax.annotate(f'Max DD: {max_dd_val:.1f}%',
                   xy=(max_dd_idx, max_dd_val),
                   xytext=(20, -20), textcoords='offset points',
                   fontsize=10, color=self.colors['danger'], fontweight='bold',
                   arrowprops=dict(arrowstyle='->', color=self.colors['danger']))

        plt.tight_layout()
        return fig

    def plot_underwater(
        self,
        equity: pd.Series,
        title: str = "Underwater Plot",
        figsize: Tuple[int, int] = (14, 5)
    ) -> plt.Figure:
        """
        Plot underwater chart (time spent in drawdown).

        Args:
            equity: Portfolio equity series
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(2, 1, figsize=figsize,
                                  gridspec_kw={'height_ratios': [2, 1]})

        # Equity curve
        ax1 = axes[0]
        ax1.plot(equity.index, equity.values, color=self.colors['primary'], linewidth=1.5)
        ax1.fill_between(equity.index, equity.values, equity.iloc[0],
                        alpha=0.3, color=self.colors['primary'])
        ax1.set_ylabel('Portfolio Value ($)')
        ax1.set_title(title, fontsize=14, fontweight='bold')
        ax1.grid(True, alpha=0.3)

        # Drawdown
        ax2 = axes[1]
        running_max = equity.expanding().max()
        drawdown = (equity - running_max) / running_max * 100

        ax2.fill_between(drawdown.index, drawdown.values, 0,
                        color=self.colors['danger'], alpha=0.7)
        ax2.set_ylabel('Drawdown (%)')
        ax2.set_xlabel('Date')
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    # ========================================================================
    # RETURNS ANALYSIS
    # ========================================================================

    def plot_returns_distribution(
        self,
        returns: pd.Series,
        title: str = "Returns Distribution",
        figsize: Tuple[int, int] = (14, 5)
    ) -> plt.Figure:
        """
        Plot returns distribution with statistics.

        Args:
            returns: Returns series
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        returns_pct = returns * 100

        # Histogram
        ax1 = axes[0]
        ax1.hist(returns_pct.dropna(), bins=50, density=True, alpha=0.7,
                color=self.colors['info'], edgecolor='white')

        # Fit normal distribution
        mu, std = returns_pct.mean(), returns_pct.std()
        x = np.linspace(returns_pct.min(), returns_pct.max(), 100)
        from scipy.stats import norm
        ax1.plot(x, norm.pdf(x, mu, std), 'r-', linewidth=2,
                label=f'Normal (μ={mu:.3f}%, σ={std:.3f}%)')

        ax1.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax1.axvline(x=mu, color=self.colors['success'], linestyle='-', linewidth=2)
        ax1.set_title('Daily Returns Histogram', fontsize=12, fontweight='bold')
        ax1.set_xlabel('Return (%)')
        ax1.set_ylabel('Density')
        ax1.legend()

        # Box plot by year
        ax2 = axes[1]
        if isinstance(returns.index, pd.DatetimeIndex):
            returns_df = pd.DataFrame({
                'Returns': returns_pct,
                'Year': returns.index.year
            })
            returns_df.boxplot(column='Returns', by='Year', ax=ax2)
            ax2.set_title('Returns by Year', fontsize=12, fontweight='bold')
            ax2.set_xlabel('Year')
            ax2.set_ylabel('Return (%)')
            plt.suptitle('')
        else:
            # QQ plot as fallback
            from scipy import stats
            stats.probplot(returns.dropna(), dist="norm", plot=ax2)
            ax2.set_title('Q-Q Plot', fontsize=12, fontweight='bold')

        plt.tight_layout()
        return fig

    def plot_rolling_metrics(
        self,
        returns: pd.Series,
        window: int = 63,
        title: str = "Rolling Performance Metrics",
        figsize: Tuple[int, int] = (14, 10)
    ) -> plt.Figure:
        """
        Plot rolling performance metrics.

        Args:
            returns: Returns series
            window: Rolling window size
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(3, 1, figsize=figsize, sharex=True)

        # Rolling Sharpe
        ax1 = axes[0]
        rf = 0.05 / 252
        rolling_sharpe = (
            (returns.rolling(window).mean() - rf) /
            returns.rolling(window).std()
        ) * np.sqrt(252)

        ax1.plot(rolling_sharpe.index, rolling_sharpe.values,
                color=self.colors['primary'], linewidth=1.5)
        ax1.axhline(y=0, color='red', linestyle='--', alpha=0.5)
        ax1.axhline(y=1, color='green', linestyle='--', alpha=0.5, label='Sharpe=1')
        ax1.axhline(y=2, color='green', linestyle=':', alpha=0.5, label='Sharpe=2')
        ax1.fill_between(rolling_sharpe.index, rolling_sharpe.values, 0,
                        where=rolling_sharpe.values > 0, alpha=0.3, color='green')
        ax1.fill_between(rolling_sharpe.index, rolling_sharpe.values, 0,
                        where=rolling_sharpe.values < 0, alpha=0.3, color='red')
        ax1.set_ylabel('Rolling Sharpe')
        ax1.set_title(title, fontsize=14, fontweight='bold')
        ax1.legend(loc='upper right')
        ax1.grid(True, alpha=0.3)

        # Rolling Volatility
        ax2 = axes[1]
        rolling_vol = returns.rolling(window).std() * np.sqrt(252) * 100
        ax2.plot(rolling_vol.index, rolling_vol.values,
                color=self.colors['danger'], linewidth=1.5)
        ax2.fill_between(rolling_vol.index, rolling_vol.values, 0,
                        alpha=0.3, color=self.colors['danger'])
        ax2.set_ylabel('Rolling Volatility (%)')
        ax2.grid(True, alpha=0.3)

        # Rolling Returns
        ax3 = axes[2]
        rolling_ret = returns.rolling(window).mean() * 252 * 100
        ax3.plot(rolling_ret.index, rolling_ret.values,
                color=self.colors['success'], linewidth=1.5)
        ax3.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax3.fill_between(rolling_ret.index, rolling_ret.values, 0,
                        where=rolling_ret.values > 0, alpha=0.3, color='green')
        ax3.fill_between(rolling_ret.index, rolling_ret.values, 0,
                        where=rolling_ret.values < 0, alpha=0.3, color='red')
        ax3.set_ylabel('Rolling Return (%)')
        ax3.set_xlabel('Date')
        ax3.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    def plot_monthly_heatmap(
        self,
        returns: pd.Series,
        title: str = "Monthly Returns Heatmap (%)",
        figsize: Tuple[int, int] = (14, 6)
    ) -> plt.Figure:
        """
        Plot monthly returns heatmap.

        Args:
            returns: Returns series
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)

        # Calculate monthly returns
        monthly = returns.resample('M').apply(lambda x: (1+x).prod()-1) * 100

        # Create pivot table
        monthly_df = pd.DataFrame({
            'Year': monthly.index.year,
            'Month': monthly.index.month,
            'Return': monthly.values
        })

        pivot = monthly_df.pivot(index='Year', columns='Month', values='Return')
        pivot.columns = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        # Add annual returns
        annual = returns.resample('Y').apply(lambda x: (1+x).prod()-1) * 100
        pivot['Annual'] = annual.values

        # Plot heatmap
        sns.heatmap(pivot, annot=True, fmt='.1f', center=0,
                   cmap=self.cmap_diverging, linewidths=0.5,
                   cbar_kws={'label': 'Return (%)'}, ax=ax,
                   annot_kws={'size': 9})

        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Month')
        ax.set_ylabel('Year')

        plt.tight_layout()
        return fig

    # ========================================================================
    # MODEL PERFORMANCE
    # ========================================================================

    def plot_model_comparison(
        self,
        model_metrics: Dict[str, Dict[str, float]],
        title: str = "Model Performance Comparison",
        figsize: Tuple[int, int] = (14, 5)
    ) -> plt.Figure:
        """
        Plot model comparison bar charts.

        Args:
            model_metrics: Dict of model name -> metrics dict
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(1, 3, figsize=figsize)

        models = list(model_metrics.keys())
        colors = [self.colors['primary'], self.colors['secondary'],
                 self.colors['success'], self.colors['warning']][:len(models)]

        # Accuracy
        ax1 = axes[0]
        accuracies = [model_metrics[m].get('accuracy', 0) for m in models]
        bars = ax1.bar(models, accuracies, color=colors, alpha=0.8)
        ax1.set_title('Accuracy', fontsize=12, fontweight='bold')
        ax1.set_ylim(0, 1)
        ax1.axhline(y=0.5, color='red', linestyle='--', alpha=0.5)
        for bar, val in zip(bars, accuracies):
            ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{val:.3f}', ha='center', fontsize=9)

        # AUC
        ax2 = axes[1]
        aucs = [model_metrics[m].get('auc', 0.5) for m in models]
        bars = ax2.bar(models, aucs, color=colors, alpha=0.8)
        ax2.set_title('AUC-ROC', fontsize=12, fontweight='bold')
        ax2.set_ylim(0.4, 1)
        ax2.axhline(y=0.5, color='red', linestyle='--', alpha=0.5, label='Random')
        for bar, val in zip(bars, aucs):
            ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{val:.3f}', ha='center', fontsize=9)

        # F1 Score
        ax3 = axes[2]
        f1s = [model_metrics[m].get('f1', 0) for m in models]
        bars = ax3.bar(models, f1s, color=colors, alpha=0.8)
        ax3.set_title('F1 Score', fontsize=12, fontweight='bold')
        ax3.set_ylim(0, 1)
        for bar, val in zip(bars, f1s):
            ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{val:.3f}', ha='center', fontsize=9)

        fig.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        return fig

    def plot_feature_importance(
        self,
        importance: pd.Series,
        top_n: int = 20,
        title: str = "Feature Importance",
        figsize: Tuple[int, int] = (10, 8)
    ) -> plt.Figure:
        """
        Plot feature importance bar chart.

        Args:
            importance: Feature importance series
            top_n: Number of top features to show
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)

        # Get top N features
        top_features = importance.sort_values(ascending=True).tail(top_n)

        # Plot horizontal bar chart
        colors = plt.cm.Blues(np.linspace(0.3, 0.9, len(top_features)))
        bars = ax.barh(range(len(top_features)), top_features.values, color=colors)

        ax.set_yticks(range(len(top_features)))
        ax.set_yticklabels(top_features.index)
        ax.set_xlabel('Importance')
        ax.set_title(title, fontsize=14, fontweight='bold')

        # Add value labels
        for bar, val in zip(bars, top_features.values):
            ax.text(val + 0.001, bar.get_y() + bar.get_height()/2,
                   f'{val:.4f}', va='center', fontsize=9)

        plt.tight_layout()
        return fig

    def plot_confusion_matrix(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        title: str = "Confusion Matrix",
        figsize: Tuple[int, int] = (8, 6)
    ) -> plt.Figure:
        """
        Plot confusion matrix.

        Args:
            y_true: True labels
            y_pred: Predicted labels
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        from sklearn.metrics import confusion_matrix

        fig, ax = plt.subplots(figsize=figsize)

        cm = confusion_matrix(y_true, y_pred)

        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                   xticklabels=['Predicted 0', 'Predicted 1'],
                   yticklabels=['Actual 0', 'Actual 1'])

        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Predicted')
        ax.set_ylabel('Actual')

        plt.tight_layout()
        return fig

    def plot_roc_curve(
        self,
        y_true: np.ndarray,
        y_prob: np.ndarray,
        title: str = "ROC Curve",
        figsize: Tuple[int, int] = (8, 6)
    ) -> plt.Figure:
        """
        Plot ROC curve.

        Args:
            y_true: True labels
            y_prob: Predicted probabilities
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        from sklearn.metrics import roc_curve, auc

        fig, ax = plt.subplots(figsize=figsize)

        fpr, tpr, _ = roc_curve(y_true, y_prob)
        roc_auc = auc(fpr, tpr)

        ax.plot(fpr, tpr, color=self.colors['primary'], linewidth=2,
               label=f'ROC curve (AUC = {roc_auc:.3f})')
        ax.plot([0, 1], [0, 1], color='red', linestyle='--', alpha=0.5,
               label='Random (AUC = 0.5)')

        ax.fill_between(fpr, tpr, alpha=0.3, color=self.colors['primary'])

        ax.set_xlim([0, 1])
        ax.set_ylim([0, 1.05])
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.legend(loc='lower right')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    # ========================================================================
    # RISK ANALYSIS
    # ========================================================================

    def plot_var_analysis(
        self,
        returns: pd.Series,
        var_95: float,
        cvar_95: float,
        title: str = "Value at Risk Analysis",
        figsize: Tuple[int, int] = (14, 5)
    ) -> plt.Figure:
        """
        Plot VaR analysis chart.

        Args:
            returns: Returns series
            var_95: 95% VaR value
            cvar_95: 95% CVaR value
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        returns_pct = returns * 100

        # Distribution with VaR
        ax1 = axes[0]
        ax1.hist(returns_pct.dropna(), bins=50, density=True, alpha=0.7,
                color=self.colors['info'], edgecolor='white')

        ax1.axvline(x=var_95*100, color=self.colors['warning'], linewidth=2,
                   linestyle='--', label=f'VaR (95%): {var_95*100:.2f}%')
        ax1.axvline(x=cvar_95*100, color=self.colors['danger'], linewidth=2,
                   linestyle='--', label=f'CVaR (95%): {cvar_95*100:.2f}%')

        # Shade tail risk
        var_x = var_95 * 100
        x_fill = np.linspace(returns_pct.min(), var_x, 100)
        from scipy.stats import norm
        mu, std = returns_pct.mean(), returns_pct.std()
        ax1.fill_between(x_fill, norm.pdf(x_fill, mu, std), 0,
                        alpha=0.3, color=self.colors['danger'])

        ax1.set_title('VaR Distribution', fontsize=12, fontweight='bold')
        ax1.set_xlabel('Return (%)')
        ax1.set_ylabel('Density')
        ax1.legend()

        # Rolling VaR
        ax2 = axes[1]
        rolling_var = returns.rolling(63).quantile(0.05) * 100
        rolling_cvar = returns.rolling(63).apply(
            lambda x: x[x <= x.quantile(0.05)].mean()
        ) * 100

        ax2.plot(rolling_var.index, rolling_var.values,
                color=self.colors['warning'], label='Rolling VaR (95%)')
        ax2.plot(rolling_cvar.index, rolling_cvar.values,
                color=self.colors['danger'], label='Rolling CVaR (95%)')
        ax2.fill_between(rolling_cvar.index, rolling_cvar.values, 0,
                        alpha=0.3, color=self.colors['danger'])

        ax2.set_title('Rolling Risk Metrics', fontsize=12, fontweight='bold')
        ax2.set_xlabel('Date')
        ax2.set_ylabel('Return (%)')
        ax2.legend()
        ax2.grid(True, alpha=0.3)

        fig.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        return fig

    # ========================================================================
    # PORTFOLIO ANALYSIS
    # ========================================================================

    def plot_portfolio_weights(
        self,
        weights: pd.Series,
        title: str = "Portfolio Allocation",
        figsize: Tuple[int, int] = (14, 5)
    ) -> plt.Figure:
        """
        Plot portfolio weights pie and bar charts.

        Args:
            weights: Portfolio weights series
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # Filter non-zero weights
        weights_filtered = weights[weights > 0.01].sort_values(ascending=False)
        colors = plt.cm.Set3(np.linspace(0, 1, len(weights_filtered)))

        # Pie chart
        ax1 = axes[0]
        wedges, texts, autotexts = ax1.pie(
            weights_filtered.values,
            labels=weights_filtered.index,
            autopct='%1.1f%%',
            colors=colors,
            startangle=90
        )
        ax1.set_title('Weight Distribution', fontsize=12, fontweight='bold')

        # Bar chart
        ax2 = axes[1]
        bars = ax2.barh(weights_filtered.index, weights_filtered.values * 100,
                       color=colors)
        ax2.set_xlabel('Weight (%)')
        ax2.set_title('Allocation by Asset', fontsize=12, fontweight='bold')
        ax2.invert_yaxis()

        for bar, val in zip(bars, weights_filtered.values):
            ax2.text(val * 100 + 0.5, bar.get_y() + bar.get_height()/2,
                    f'{val*100:.1f}%', va='center', fontsize=9)

        fig.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        return fig

    def plot_efficient_frontier(
        self,
        returns_df: pd.DataFrame,
        optimal_weights: Optional[pd.Series] = None,
        n_portfolios: int = 1000,
        title: str = "Efficient Frontier",
        figsize: Tuple[int, int] = (10, 7)
    ) -> plt.Figure:
        """
        Plot efficient frontier with random portfolios.

        Args:
            returns_df: Returns DataFrame for assets
            optimal_weights: Optimal portfolio weights (optional)
            n_portfolios: Number of random portfolios to generate
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)

        n_assets = len(returns_df.columns)
        results = {'returns': [], 'volatility': [], 'sharpe': [], 'weights': []}

        # Generate random portfolios
        np.random.seed(42)
        for _ in range(n_portfolios):
            weights = np.random.random(n_assets)
            weights /= weights.sum()

            portfolio_return = np.dot(weights, returns_df.mean()) * 252
            portfolio_vol = np.sqrt(np.dot(weights.T, np.dot(returns_df.cov() * 252, weights)))
            sharpe = portfolio_return / portfolio_vol

            results['returns'].append(portfolio_return)
            results['volatility'].append(portfolio_vol)
            results['sharpe'].append(sharpe)
            results['weights'].append(weights)

        # Plot random portfolios
        scatter = ax.scatter(results['volatility'], results['returns'],
                           c=results['sharpe'], cmap='viridis',
                           alpha=0.5, s=10)

        plt.colorbar(scatter, label='Sharpe Ratio')

        # Plot individual assets
        for i, col in enumerate(returns_df.columns):
            asset_ret = returns_df[col].mean() * 252
            asset_vol = returns_df[col].std() * np.sqrt(252)
            ax.scatter(asset_vol, asset_ret, marker='o', s=100,
                      label=col, zorder=5)

        # Plot optimal portfolio
        if optimal_weights is not None:
            opt_return = np.dot(optimal_weights, returns_df.mean()) * 252
            opt_vol = np.sqrt(np.dot(optimal_weights.T,
                                    np.dot(returns_df.cov() * 252, optimal_weights)))
            ax.scatter(opt_vol, opt_return, marker='*', s=300,
                      c='red', label='Optimal Portfolio', zorder=10)

        ax.set_xlabel('Volatility (Annual)')
        ax.set_ylabel('Return (Annual)')
        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.legend(loc='upper left')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    # ========================================================================
    # MONTE CARLO
    # ========================================================================

    def plot_monte_carlo(
        self,
        simulations: np.ndarray,
        initial_value: float = 100000,
        title: str = "Monte Carlo Simulation",
        figsize: Tuple[int, int] = (14, 5)
    ) -> plt.Figure:
        """
        Plot Monte Carlo simulation results.

        Args:
            simulations: Simulation paths (n_sims x horizon)
            initial_value: Initial portfolio value
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        horizon = simulations.shape[1]
        x = np.arange(horizon)

        # Fan chart
        ax1 = axes[0]

        p5 = np.percentile(simulations, 5, axis=0)
        p25 = np.percentile(simulations, 25, axis=0)
        p50 = np.percentile(simulations, 50, axis=0)
        p75 = np.percentile(simulations, 75, axis=0)
        p95 = np.percentile(simulations, 95, axis=0)

        ax1.fill_between(x, p5, p95, alpha=0.2, color='blue', label='5-95%')
        ax1.fill_between(x, p25, p75, alpha=0.4, color='blue', label='25-75%')
        ax1.plot(x, p50, 'b-', linewidth=2, label='Median')
        ax1.axhline(y=initial_value, color='red', linestyle='--',
                   alpha=0.7, label='Initial Value')

        ax1.set_title('Simulation Paths', fontsize=12, fontweight='bold')
        ax1.set_xlabel('Days')
        ax1.set_ylabel('Portfolio Value ($)')
        ax1.legend(loc='upper left')
        ax1.grid(True, alpha=0.3)

        # Terminal distribution
        ax2 = axes[1]
        terminal_values = simulations[:, -1]

        ax2.hist(terminal_values, bins=50, density=True, alpha=0.7,
                color=self.colors['info'], edgecolor='white')
        ax2.axvline(x=initial_value, color='red', linestyle='--',
                   linewidth=2, label='Initial Value')
        ax2.axvline(x=np.median(terminal_values), color='green', linestyle='--',
                   linewidth=2, label=f'Median: ${np.median(terminal_values):,.0f}')

        ax2.set_title('Terminal Value Distribution', fontsize=12, fontweight='bold')
        ax2.set_xlabel('Portfolio Value ($)')
        ax2.set_ylabel('Density')
        ax2.legend()

        fig.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        return fig

    # ========================================================================
    # SIGNALS & TRADING
    # ========================================================================

    def plot_signals_on_price(
        self,
        prices: pd.Series,
        signals: pd.Series,
        title: str = "Trading Signals",
        figsize: Tuple[int, int] = (14, 6)
    ) -> plt.Figure:
        """
        Plot trading signals overlaid on price chart.

        Args:
            prices: Price series
            signals: Signal series (1=buy, -1=sell, 0=hold)
            title: Chart title
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=figsize)

        # Plot price
        ax.plot(prices.index, prices.values, color='black', linewidth=1,
               label='Price', alpha=0.7)

        # Plot buy signals
        buy_signals = signals[signals == 1]
        ax.scatter(buy_signals.index, prices.loc[buy_signals.index],
                  marker='^', color=self.colors['success'], s=100,
                  label='Buy Signal', zorder=5)

        # Plot sell signals
        sell_signals = signals[signals == -1]
        ax.scatter(sell_signals.index, prices.loc[sell_signals.index],
                  marker='v', color=self.colors['danger'], s=100,
                  label='Sell Signal', zorder=5)

        ax.set_title(title, fontsize=14, fontweight='bold')
        ax.set_xlabel('Date')
        ax.set_ylabel('Price ($)')
        ax.legend(loc='upper left')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        return fig

    # ========================================================================
    # COMPREHENSIVE DASHBOARD
    # ========================================================================

    def create_full_dashboard(
        self,
        equity: pd.Series,
        returns: pd.Series,
        benchmark_equity: Optional[pd.Series] = None,
        signals: Optional[pd.Series] = None,
        figsize: Tuple[int, int] = (16, 20)
    ) -> plt.Figure:
        """
        Create comprehensive multi-panel dashboard.

        Args:
            equity: Portfolio equity curve
            returns: Strategy returns
            benchmark_equity: Benchmark equity (optional)
            signals: Trading signals (optional)
            figsize: Figure size

        Returns:
            Matplotlib figure
        """
        fig = plt.figure(figsize=figsize)
        gs = gridspec.GridSpec(5, 2, height_ratios=[2, 1.5, 1.5, 1.5, 1],
                              hspace=0.35, wspace=0.25)

        # Title
        fig.suptitle('📊 Quantitative Research Dashboard',
                    fontsize=18, fontweight='bold', y=0.98)

        # 1. Equity Curve (top, full width)
        ax1 = fig.add_subplot(gs[0, :])
        ax1.plot(equity.index, equity.values,
                label='Strategy', color=self.colors['primary'], linewidth=2)
        if benchmark_equity is not None:
            bench_norm = benchmark_equity / benchmark_equity.iloc[0] * equity.iloc[0]
            ax1.plot(bench_norm.index, bench_norm.values,
                    label='Benchmark', color=self.colors['secondary'],
                    linewidth=2, alpha=0.7)
        ax1.set_title('Equity Curve', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Portfolio Value ($)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # 2. Drawdown
        ax2 = fig.add_subplot(gs[1, 0])
        running_max = equity.expanding().max()
        drawdown = (equity - running_max) / running_max * 100
        ax2.fill_between(drawdown.index, drawdown.values, 0,
                        color=self.colors['danger'], alpha=0.5)
        ax2.set_title('Drawdown', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Drawdown (%)')
        ax2.grid(True, alpha=0.3)

        # 3. Returns Distribution
        ax3 = fig.add_subplot(gs[1, 1])
        returns_pct = returns * 100
        ax3.hist(returns_pct.dropna(), bins=40, density=True,
                alpha=0.7, color=self.colors['info'])
        ax3.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax3.set_title('Daily Returns Distribution', fontsize=12, fontweight='bold')
        ax3.set_xlabel('Return (%)')

        # 4. Rolling Sharpe
        ax4 = fig.add_subplot(gs[2, 0])
        rf = 0.05 / 252
        rolling_sharpe = ((returns.rolling(63).mean() - rf) /
                         returns.rolling(63).std()) * np.sqrt(252)
        ax4.plot(rolling_sharpe.index, rolling_sharpe.values,
                color=self.colors['primary'])
        ax4.axhline(y=0, color='red', linestyle='--', alpha=0.5)
        ax4.axhline(y=1, color='green', linestyle='--', alpha=0.5)
        ax4.set_title('Rolling Sharpe (63-day)', fontsize=12, fontweight='bold')
        ax4.grid(True, alpha=0.3)

        # 5. Rolling Volatility
        ax5 = fig.add_subplot(gs[2, 1])
        rolling_vol = returns.rolling(21).std() * np.sqrt(252) * 100
        ax5.plot(rolling_vol.index, rolling_vol.values, color=self.colors['danger'])
        ax5.fill_between(rolling_vol.index, rolling_vol.values, 0,
                        alpha=0.3, color=self.colors['danger'])
        ax5.set_title('Rolling Volatility (21-day)', fontsize=12, fontweight='bold')
        ax5.set_ylabel('Volatility (%)')
        ax5.grid(True, alpha=0.3)

        # 6. Monthly Returns Heatmap
        ax6 = fig.add_subplot(gs[3, :])
        monthly = returns.resample('M').apply(lambda x: (1+x).prod()-1) * 100
        monthly_df = pd.DataFrame({
            'Year': monthly.index.year,
            'Month': monthly.index.month,
            'Return': monthly.values
        })
        if len(monthly_df['Year'].unique()) > 1:
            pivot = monthly_df.pivot(index='Year', columns='Month', values='Return')
            pivot.columns = ['Jan','Feb','Mar','Apr','May','Jun',
                           'Jul','Aug','Sep','Oct','Nov','Dec'][:len(pivot.columns)]
            sns.heatmap(pivot, annot=True, fmt='.1f', center=0,
                       cmap=self.cmap_diverging, ax=ax6, cbar_kws={'label': '%'})
        ax6.set_title('Monthly Returns (%)', fontsize=12, fontweight='bold')

        # 7. Metrics Summary
        ax7 = fig.add_subplot(gs[4, :])
        ax7.axis('off')

        # Calculate metrics
        total_return = (equity.iloc[-1] / equity.iloc[0] - 1) * 100
        sharpe = calculate_sharpe_ratio(returns)
        sortino = calculate_sortino_ratio(returns)
        max_dd = drawdown.min()
        volatility = returns.std() * np.sqrt(252) * 100
        win_rate = (returns > 0).mean() * 100

        metrics_text = (
            f"Total Return: {total_return:.2f}%  |  "
            f"Sharpe: {sharpe:.3f}  |  "
            f"Sortino: {sortino:.3f}  |  "
            f"Max DD: {max_dd:.1f}%  |  "
            f"Volatility: {volatility:.1f}%  |  "
            f"Win Rate: {win_rate:.1f}%"
        )

        ax7.text(0.5, 0.5, metrics_text, fontsize=12, fontweight='bold',
                ha='center', va='center', transform=ax7.transAxes,
                bbox=dict(boxstyle='round', facecolor=self.colors['light'],
                         edgecolor=self.colors['dark']))

        return fig


# ============================================================================
# CREATE VISUALIZATIONS
# ============================================================================

print("=" * 70)
print("📊 CREATING VISUALIZATIONS")
print("=" * 70)

# Initialize visualizer
viz = QuantVisualizer()

# Generate sample data for demonstration
np.random.seed(42)
n = 500
dates = pd.date_range(start='2021-01-01', periods=n, freq='D')

# Sample returns and equity
sample_returns = pd.Series(np.random.randn(n) * 0.015 + 0.0003, index=dates)
sample_equity = 100000 * (1 + sample_returns).cumprod()

# Benchmark
benchmark_returns = pd.Series(np.random.randn(n) * 0.012, index=dates)
benchmark_equity = 100000 * (1 + benchmark_returns).cumprod()

# Sample signals
sample_signals = pd.Series(np.random.choice([-1, 0, 1], n, p=[0.15, 0.7, 0.15]), index=dates)

print("\n📈 Available Visualization Methods:")
print("   1. viz.plot_equity_curve(equity, benchmark)")
print("   2. viz.plot_drawdown(equity)")
print("   3. viz.plot_underwater(equity)")
print("   4. viz.plot_returns_distribution(returns)")
print("   5. viz.plot_rolling_metrics(returns)")
print("   6. viz.plot_monthly_heatmap(returns)")
print("   7. viz.plot_model_comparison(model_metrics)")
print("   8. viz.plot_feature_importance(importance)")
print("   9. viz.plot_confusion_matrix(y_true, y_pred)")
print("   10. viz.plot_roc_curve(y_true, y_prob)")
print("   11. viz.plot_var_analysis(returns, var, cvar)")
print("   12. viz.plot_portfolio_weights(weights)")
print("   13. viz.plot_efficient_frontier(returns_df)")
print("   14. viz.plot_monte_carlo(simulations)")
print("   15. viz.plot_signals_on_price(prices, signals)")
print("   16. viz.create_full_dashboard(equity, returns)")

# Display comprehensive dashboard
print("\n🎨 Displaying Full Dashboard...")
fig = viz.create_full_dashboard(
    sample_equity,
    sample_returns,
    benchmark_equity,
    sample_signals
)
plt.show()

# Display individual charts
print("\n📊 Individual Charts:")

# Equity curve
print("   → Equity Curve")
fig = viz.plot_equity_curve(sample_equity, benchmark_equity)
plt.show()

# Monthly heatmap
print("   → Monthly Heatmap")
fig = viz.plot_monthly_heatmap(sample_returns)
plt.show()

# Rolling metrics
print("   → Rolling Metrics")
fig = viz.plot_rolling_metrics(sample_returns)
plt.show()

print("\n✅ All visualizations ready!")
print("   Use 'viz' object to create any chart.")