"""
report.py
=========
ReportGenerationAgent (HTML)
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


from jinja2 import Template
from datetime import datetime
import webbrowser
import os


class ReportGenerationAgent(BaseAgent):
    """
    Agent for generating comprehensive research reports.

    Features:
    - HTML report generation
    - PDF export (if weasyprint available)
    - Interactive visualizations
    - Executive summary

    Attributes:
        report_generator: ReportGenerator utility
        report_data: Compiled report data
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        output_dir: Optional[Path] = None
    ):
        """
        Initialize Report Generation Agent.

        Args:
            config: System configuration
            logger: Logger instance
            output_dir: Output directory for reports
        """
        super().__init__("ReportGenerationAgent", config, logger)

        self.output_dir = output_dir or REPORTS_PATH
        self.report_generator = ReportGenerator(self.output_dir)
        self.report_data: Dict[str, Any] = {}

    def compile_report_data(
        self,
        backtest_results: Dict[str, Any],
        risk_metrics: Dict[str, Any],
        model_metrics: Optional[Dict[str, Any]] = None,
        portfolio_weights: Optional[pd.Series] = None,
        monte_carlo_results: Optional[Dict[str, Any]] = None,
        statistical_tests: Optional[List[Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Compile all data for the report.

        Args:
            backtest_results: Backtest results dictionary
            risk_metrics: Risk analysis results
            model_metrics: ML model performance metrics
            portfolio_weights: Portfolio allocation weights
            monte_carlo_results: Monte Carlo simulation results
            statistical_tests: Statistical test results

        Returns:
            Compiled report data
        """
        self.logger.info("Compiling report data...")

        # Get current timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Compile data
        self.report_data = {
            'title': 'Quantitative Research Report',
            'generated_at': timestamp,
            'config': {
                'tickers': self.config.data.tickers,
                'start_date': self.config.data.start_date,
                'initial_capital': self.config.backtest.initial_capital,
                'commission': self.config.backtest.commission_pct,
            },
            'backtest': backtest_results,
            'risk': risk_metrics,
            'model': model_metrics or {},
            'portfolio_weights': portfolio_weights.to_dict() if portfolio_weights is not None else {},
            'monte_carlo': monte_carlo_results or {},
            'statistical_tests': statistical_tests or [],
            'charts': {},
            **kwargs
        }

        return self.report_data

    def generate_charts(
        self,
        equity_curve: pd.Series,
        returns: pd.Series,
        benchmark_equity: Optional[pd.Series] = None,
        portfolio_weights: Optional[pd.Series] = None,
        monte_carlo_simulations: Optional[np.ndarray] = None
    ) -> Dict[str, str]:
        """
        Generate all charts for the report.

        Args:
            equity_curve: Portfolio equity curve
            returns: Strategy returns
            benchmark_equity: Benchmark equity curve
            portfolio_weights: Portfolio weights
            monte_carlo_simulations: Monte Carlo simulation paths

        Returns:
            Dictionary of chart names to base64 encoded images
        """
        self.logger.info("Generating report charts...")

        charts = {}

        # Equity curve
        fig = self.report_generator.create_equity_curve_chart(
            equity_curve, benchmark_equity
        )
        charts['equity_curve'] = self.report_generator.figure_to_base64(fig)

        # Drawdown
        fig = self.report_generator.create_drawdown_chart(equity_curve)
        charts['drawdown'] = self.report_generator.figure_to_base64(fig)

        # Returns distribution
        fig = self.report_generator.create_returns_distribution_chart(returns)
        charts['returns_distribution'] = self.report_generator.figure_to_base64(fig)

        # Rolling metrics
        fig = self.report_generator.create_rolling_metrics_chart(returns)
        charts['rolling_metrics'] = self.report_generator.figure_to_base64(fig)

        # Monthly heatmap
        fig = self.report_generator.create_monthly_returns_heatmap(returns)
        charts['monthly_heatmap'] = self.report_generator.figure_to_base64(fig)

        # Portfolio weights
        if portfolio_weights is not None:
            fig = self.report_generator.create_portfolio_weights_chart(portfolio_weights)
            charts['portfolio_weights'] = self.report_generator.figure_to_base64(fig)

        # Monte Carlo
        if monte_carlo_simulations is not None:
            fig = self.report_generator.create_monte_carlo_chart(monte_carlo_simulations)
            charts['monte_carlo'] = self.report_generator.figure_to_base64(fig)

        self.report_data['charts'] = charts

        return charts

    def generate_html_report(self) -> str:
        """
        Generate HTML report from compiled data.

        Returns:
            HTML content as string
        """
        self.logger.info("Generating HTML report...")

        html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ title }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f5f7fa;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 40px 20px;
            text-align: center;
            margin-bottom: 30px;
        }

        header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        header p {
            color: #a0a0a0;
            font-size: 1.1em;
        }

        .section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .section h2 {
            color: #1a1a2e;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .metric-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border-left: 4px solid #3498db;
        }

        .metric-card.positive {
            border-left-color: #27ae60;
        }

        .metric-card.negative {
            border-left-color: #e74c3c;
        }

        .metric-card h3 {
            color: #666;
            font-size: 0.9em;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .metric-card .value {
            font-size: 1.8em;
            font-weight: bold;
            color: #1a1a2e;
        }

        .chart-container {
            text-align: center;
            margin: 20px 0;
        }

        .chart-container img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #1a1a2e;
            color: white;
            font-weight: 600;
        }

        table tr:hover {
            background-color: #f5f5f5;
        }

        .highlight-positive {
            color: #27ae60;
            font-weight: bold;
        }

        .highlight-negative {
            color: #e74c3c;
            font-weight: bold;
        }

        .executive-summary {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 25px;
        }

        .executive-summary h2 {
            color: white;
            border-bottom-color: #3498db;
        }

        .executive-summary p {
            color: #d0d0d0;
            font-size: 1.1em;
            line-height: 1.8;
        }

        .two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        @media (max-width: 768px) {
            .two-column {
                grid-template-columns: 1fr;
            }
        }

        footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 0.9em;
        }

        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
        }

        .badge-success {
            background-color: #d4edda;
            color: #155724;
        }

        .badge-warning {
            background-color: #fff3cd;
            color: #856404;
        }

        .badge-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <header>
        <h1>📊 {{ title }}</h1>
        <p>Generated: {{ generated_at }}</p>
    </header>

    <div class="container">
        <!-- Executive Summary -->
        <div class="executive-summary">
            <h2>📋 Executive Summary</h2>
            <p>
                This quantitative research report presents a comprehensive analysis of the trading strategy
                performance over the period from {{ config.start_date }} to present. The strategy was
                backtested with an initial capital of ${{ "{:,.0f}".format(config.initial_capital) }}
                and trading costs of {{ "%.2f"|format(config.commission * 100) }}%.
            </p>
            <br>
            <p>
                <strong>Key Findings:</strong> The strategy achieved a
                {% if backtest.total_return > 0 %}
                <span class="highlight-positive">{{ "%.2f"|format(backtest.total_return * 100) }}%</span>
                {% else %}
                <span class="highlight-negative">{{ "%.2f"|format(backtest.total_return * 100) }}%</span>
                {% endif %}
                total return with a Sharpe ratio of {{ "%.3f"|format(backtest.sharpe_ratio) }} and
                maximum drawdown of {{ "%.2f"|format(backtest.max_drawdown * 100) }}%.
            </p>
        </div>

        <!-- Performance Metrics -->
        <div class="section">
            <h2>📈 Performance Metrics</h2>
            <div class="metrics-grid">
                <div class="metric-card {% if backtest.total_return > 0 %}positive{% else %}negative{% endif %}">
                    <h3>Total Return</h3>
                    <div class="value">{{ "%.2f"|format(backtest.total_return * 100) }}%</div>
                </div>
                <div class="metric-card {% if backtest.sharpe_ratio > 1 %}positive{% elif backtest.sharpe_ratio < 0 %}negative{% endif %}">
                    <h3>Sharpe Ratio</h3>
                    <div class="value">{{ "%.3f"|format(backtest.sharpe_ratio) }}</div>
                </div>
                <div class="metric-card negative">
                    <h3>Max Drawdown</h3>
                    <div class="value">{{ "%.2f"|format(backtest.max_drawdown * 100) }}%</div>
                </div>
                <div class="metric-card">
                    <h3>Total Trades</h3>
                    <div class="value">{{ backtest.total_trades }}</div>
                </div>
                <div class="metric-card {% if backtest.win_rate > 0.5 %}positive{% else %}negative{% endif %}">
                    <h3>Win Rate</h3>
                    <div class="value">{{ "%.1f"|format(backtest.win_rate * 100) }}%</div>
                </div>
                <div class="metric-card">
                    <h3>Volatility</h3>
                    <div class="value">{{ "%.2f"|format(risk.volatility * 100) }}%</div>
                </div>
            </div>
        </div>

        <!-- Equity Curve -->
        <div class="section">
            <h2>📊 Equity Curve</h2>
            {% if charts.equity_curve %}
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.equity_curve }}" alt="Equity Curve">
            </div>
            {% endif %}
        </div>

        <!-- Drawdown Analysis -->
        <div class="section">
            <h2>📉 Drawdown Analysis</h2>
            {% if charts.drawdown %}
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.drawdown }}" alt="Drawdown">
            </div>
            {% endif %}
        </div>

        <!-- Risk Metrics -->
        <div class="section">
            <h2>⚠️ Risk Analysis</h2>
            <div class="metrics-grid">
                <div class="metric-card">
                    <h3>VaR (95%)</h3>
                    <div class="value">{{ "%.2f"|format(risk.var_95 * 100) }}%</div>
                </div>
                <div class="metric-card">
                    <h3>CVaR (95%)</h3>
                    <div class="value">{{ "%.2f"|format(risk.cvar_95 * 100) }}%</div>
                </div>
                <div class="metric-card">
                    <h3>Sortino Ratio</h3>
                    <div class="value">{{ "%.3f"|format(risk.sortino_ratio) }}</div>
                </div>
                <div class="metric-card">
                    <h3>Calmar Ratio</h3>
                    <div class="value">{{ "%.3f"|format(risk.calmar_ratio) }}</div>
                </div>
            </div>

            {% if charts.returns_distribution %}
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.returns_distribution }}" alt="Returns Distribution">
            </div>
            {% endif %}
        </div>

        <!-- Rolling Performance -->
        <div class="section">
            <h2>📈 Rolling Performance</h2>
            {% if charts.rolling_metrics %}
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.rolling_metrics }}" alt="Rolling Metrics">
            </div>
            {% endif %}
        </div>

        <!-- Monthly Returns -->
        <div class="section">
            <h2>📅 Monthly Returns</h2>
            {% if charts.monthly_heatmap %}
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.monthly_heatmap }}" alt="Monthly Heatmap">
            </div>
            {% endif %}
        </div>

        <!-- Portfolio Allocation -->
        {% if charts.portfolio_weights %}
        <div class="section">
            <h2>💼 Portfolio Allocation</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.portfolio_weights }}" alt="Portfolio Weights">
            </div>
        </div>
        {% endif %}

        <!-- Monte Carlo Simulation -->
        {% if charts.monte_carlo %}
        <div class="section">
            <h2>🎲 Monte Carlo Simulation</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{{ charts.monte_carlo }}" alt="Monte Carlo">
            </div>
            {% if monte_carlo %}
            <div class="metrics-grid">
                <div class="metric-card">
                    <h3>Prob. of Profit</h3>
                    <div class="value">{{ "%.1f"|format(monte_carlo.probability_profit * 100) }}%</div>
                </div>
                <div class="metric-card">
                    <h3>Prob. of Ruin</h3>
                    <div class="value">{{ "%.1f"|format(monte_carlo.probability_ruin * 100) }}%</div>
                </div>
                <div class="metric-card">
                    <h3>Expected Return</h3>
                    <div class="value">{{ "%.2f"|format(monte_carlo.expected_return * 100) }}%</div>
                </div>
            </div>
            {% endif %}
        </div>
        {% endif %}

        <!-- Statistical Tests -->
        {% if statistical_tests %}
        <div class="section">
            <h2>🔬 Statistical Validation</h2>
            <table>
                <thead>
                    <tr>
                        <th>Test</th>
                        <th>Statistic</th>
                        <th>P-Value</th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    {% for test in statistical_tests %}
                    <tr>
                        <td>{{ test.test_name }}</td>
                        <td>{{ "%.4f"|format(test.statistic) }}</td>
                        <td>{{ "%.4f"|format(test.p_value) }}</td>
                        <td>
                            {% if test.significant %}
                            <span class="badge badge-success">Significant</span>
                            {% else %}
                            <span class="badge badge-warning">Not Significant</span>
                            {% endif %}
                        </td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% endif %}

        <!-- Configuration -->
        <div class="section">
            <h2>⚙️ Configuration</h2>
            <table>
                <tr><th>Parameter</th><th>Value</th></tr>
                <tr><td>Tickers</td><td>{{ config.tickers | join(', ') }}</td></tr>
                <tr><td>Start Date</td><td>{{ config.start_date }}</td></tr>
                <tr><td>Initial Capital</td><td>${{ "{:,.0f}".format(config.initial_capital) }}</td></tr>
                <tr><td>Commission</td><td>{{ "%.2f"|format(config.commission * 100) }}%</td></tr>
            </table>
        </div>
    </div>

    <footer>
        <p>Generated by AI Quantitative Research System | {{ generated_at }}</p>
    </footer>
</body>
</html>
        """

        template = Template(html_template)
        html_content = template.render(**self.report_data)

        return html_content

    def save_report(
        self,
        html_content: str,
        filename: str = None
    ) -> Path:
        """
        Save HTML report to file.

        Args:
            html_content: HTML content
            filename: Output filename

        Returns:
            Path to saved report
        """
        filename = filename or f"research_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        filepath = self.output_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html_content)

        self.logger.info(f"Report saved to: {filepath}")

        return filepath

    def run(
        self,
        backtest_results: Dict[str, Any],
        equity_curve: pd.Series,
        returns: pd.Series,
        risk_metrics: Dict[str, Any],
        benchmark_equity: Optional[pd.Series] = None,
        model_metrics: Optional[Dict[str, Any]] = None,
        portfolio_weights: Optional[pd.Series] = None,
        monte_carlo_results: Optional[Dict[str, Any]] = None,
        monte_carlo_simulations: Optional[np.ndarray] = None,
        statistical_tests: Optional[List[Any]] = None,
        save_report: bool = True,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            backtest_results: Backtest results
            equity_curve: Portfolio equity curve
            returns: Strategy returns
            risk_metrics: Risk analysis results
            benchmark_equity: Benchmark equity curve
            model_metrics: ML model metrics
            portfolio_weights: Portfolio weights
            monte_carlo_results: Monte Carlo results
            monte_carlo_simulations: Monte Carlo simulation paths
            statistical_tests: Statistical test results
            save_report: Whether to save the report

        Returns:
            AgentResult with report
        """
        def execute():
            # Compile data
            self.compile_report_data(
                backtest_results=backtest_results,
                risk_metrics=risk_metrics,
                model_metrics=model_metrics,
                portfolio_weights=portfolio_weights,
                monte_carlo_results=monte_carlo_results,
                statistical_tests=statistical_tests
            )

            # Generate charts
            charts = self.generate_charts(
                equity_curve=equity_curve,
                returns=returns,
                benchmark_equity=benchmark_equity,
                portfolio_weights=portfolio_weights,
                monte_carlo_simulations=monte_carlo_simulations
            )

            # Generate HTML
            html_content = self.generate_html_report()

            # Save report
            report_path = None
            if save_report:
                report_path = self.save_report(html_content)

            return {
                'html_content': html_content,
                'report_path': str(report_path) if report_path else None,
                'charts': list(charts.keys()),
                'data': self.report_data
            }

        return self._execute_with_timing(execute)


# Test Report Generation Agent
print("=" * 70)
print("🧪 TESTING REPORT GENERATION AGENT")
print("=" * 70)

# Prepare sample data
backtest_data = {
    'total_return': 0.25,
    'sharpe_ratio': 1.45,
    'max_drawdown': 0.12,
    'total_trades': 156,
    'win_rate': 0.58
}

risk_data = {
    'var_95': -0.025,
    'cvar_95': -0.035,
    'volatility': 0.18,
    'sortino_ratio': 1.85,
    'calmar_ratio': 2.1
}

# Create report agent
report_agent = ReportGenerationAgent(config=config)

print("\n📄 Generating report...")
report_result = report_agent.run(
    backtest_results=backtest_data,
    equity_curve=sample_equity,
    returns=sample_returns,
    risk_metrics=risk_data,
    benchmark_equity=benchmark_equity,
    save_report=True
)

if report_result.success:
    print(f"\n✅ Report generated successfully!")
    print(f"   Report path: {report_result.data['report_path']}")
    print(f"   Charts included: {len(report_result.data['charts'])}")

    # Display link in Colab
    if IN_COLAB and report_result.data['report_path']:
        from google.colab import files
        print(f"\n📥 Download report from: {report_result.data['report_path']}")
else:
    print(f"❌ Error: {report_result.errors}")

print("\n" + "=" * 70)
print("✅ Report Generation Agent ready!")