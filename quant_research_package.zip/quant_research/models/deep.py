"""
deep.py
=======
AttentionLayer + build_lstm_model + LSTMAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Optional, List, Tuple, Union, Dict, Any
import warnings
warnings.filterwarnings('ignore')

# TensorFlow imports
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, Model, callbacks
from tensorflow.keras.layers import (
    LSTM, Dense, Dropout, BatchNormalization,
    Input, Bidirectional, Attention, MultiHeadAttention,
    LayerNormalization, GlobalAveragePooling1D
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint

# Set memory growth for GPU
physical_devices = tf.config.list_physical_devices('GPU')
if physical_devices:
    for device in physical_devices:
        tf.config.experimental.set_memory_growth(device, True)
    print(f"✅ GPU available: {len(physical_devices)} device(s)")
else:
    print("⚠️ No GPU available, using CPU")


class AttentionLayer(layers.Layer):
    """
    Custom attention layer for LSTM.
    Implements scaled dot-product attention.
    """

    def __init__(self, units: int, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)
        self.units = units
        self.W = None
        self.b = None
        self.u = None

    def build(self, input_shape):
        self.W = self.add_weight(
            name='attention_weight',
            shape=(input_shape[-1], self.units),
            initializer='glorot_uniform',
            trainable=True
        )
        self.b = self.add_weight(
            name='attention_bias',
            shape=(self.units,),
            initializer='zeros',
            trainable=True
        )
        self.u = self.add_weight(
            name='attention_context',
            shape=(self.units,),
            initializer='glorot_uniform',
            trainable=True
        )
        super(AttentionLayer, self).build(input_shape)

    def call(self, inputs):
        # inputs shape: (batch_size, time_steps, features)

        # Score calculation
        score = tf.tanh(tf.tensordot(inputs, self.W, axes=1) + self.b)
        attention_weights = tf.nn.softmax(
            tf.tensordot(score, self.u, axes=1), axis=1
        )

        # Context vector
        context = inputs * tf.expand_dims(attention_weights, -1)
        context = tf.reduce_sum(context, axis=1)

        return context, attention_weights

    def get_config(self):
        config = super().get_config()
        config.update({'units': self.units})
        return config


def build_lstm_model(
    input_shape: Tuple[int, int],
    lstm_units: List[int] = [128, 64],
    dropout_rate: float = 0.3,
    use_attention: bool = True,
    use_bidirectional: bool = False,
    learning_rate: float = 0.001,
    l2_reg: float = 0.01
) -> Model:
    """
    Build LSTM model with optional attention.

    Args:
        input_shape: (sequence_length, n_features)
        lstm_units: List of LSTM units for each layer
        dropout_rate: Dropout rate
        use_attention: Whether to use attention mechanism
        use_bidirectional: Whether to use bidirectional LSTM
        learning_rate: Learning rate
        l2_reg: L2 regularization factor

    Returns:
        Compiled Keras model
    """
    inputs = Input(shape=input_shape, name='input')
    x = inputs

    # LSTM layers
    for i, units in enumerate(lstm_units):
        return_sequences = (i < len(lstm_units) - 1) or use_attention

        lstm_layer = LSTM(
            units,
            return_sequences=return_sequences,
            kernel_regularizer=keras.regularizers.l2(l2_reg),
            recurrent_regularizer=keras.regularizers.l2(l2_reg),
            name=f'lstm_{i}'
        )

        if use_bidirectional:
            x = Bidirectional(lstm_layer, name=f'bidirectional_{i}')(x)
        else:
            x = lstm_layer(x)

        x = BatchNormalization(name=f'bn_{i}')(x)
        x = Dropout(dropout_rate, name=f'dropout_{i}')(x)

    # Attention layer
    if use_attention:
        attention_units = lstm_units[-1] if not use_bidirectional else lstm_units[-1] * 2
        x, attention_weights = AttentionLayer(attention_units, name='attention')(x)

    # Dense layers
    x = Dense(32, activation='relu', name='dense_1')(x)
    x = Dropout(dropout_rate / 2, name='dropout_dense')(x)

    # Output layer
    outputs = Dense(1, activation='sigmoid', name='output')(x)

    model = Model(inputs=inputs, outputs=outputs, name='LSTM_Classifier')

    # Compile model
    model.compile(
        optimizer=Adam(learning_rate=learning_rate),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.AUC(name='auc')]
    )

    return model


def build_transformer_model(
    input_shape: Tuple[int, int],
    num_heads: int = 4,
    ff_dim: int = 64,
    num_transformer_blocks: int = 2,
    dropout_rate: float = 0.3,
    learning_rate: float = 0.001
) -> Model:
    """
    Build Transformer model for sequence classification.

    Args:
        input_shape: (sequence_length, n_features)
        num_heads: Number of attention heads
        ff_dim: Feed-forward dimension
        num_transformer_blocks: Number of transformer blocks
        dropout_rate: Dropout rate
        learning_rate: Learning rate

    Returns:
        Compiled Keras model
    """
    inputs = Input(shape=input_shape, name='input')
    x = inputs

    # Transformer blocks
    for i in range(num_transformer_blocks):
        # Multi-head attention
        attention_output = MultiHeadAttention(
            num_heads=num_heads,
            key_dim=input_shape[-1],
            name=f'multihead_attention_{i}'
        )(x, x)
        attention_output = Dropout(dropout_rate)(attention_output)
        x = LayerNormalization(epsilon=1e-6)(x + attention_output)

        # Feed-forward network
        ff_output = Dense(ff_dim, activation='relu')(x)
        ff_output = Dense(input_shape[-1])(ff_output)
        ff_output = Dropout(dropout_rate)(ff_output)
        x = LayerNormalization(epsilon=1e-6)(x + ff_output)

    # Global pooling
    x = GlobalAveragePooling1D()(x)

    # Dense layers
    x = Dense(32, activation='relu')(x)
    x = Dropout(dropout_rate)(x)

    # Output
    outputs = Dense(1, activation='sigmoid', name='output')(x)

    model = Model(inputs=inputs, outputs=outputs, name='Transformer_Classifier')

    model.compile(
        optimizer=Adam(learning_rate=learning_rate),
        loss='binary_crossentropy',
        metrics=['accuracy', tf.keras.metrics.AUC(name='auc')]
    )

    return model


# Create sequence data generator
def create_sequences(
    X: np.ndarray,
    y: np.ndarray,
    sequence_length: int
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Create sequences for LSTM training.

    Args:
        X: Feature matrix (n_samples, n_features)
        y: Target variable (n_samples,)
        sequence_length: Length of each sequence

    Returns:
        Tuple of (X_sequences, y_sequences)
    """
    X_seq, y_seq = [], []

    for i in range(sequence_length, len(X)):
        X_seq.append(X[i - sequence_length:i])
        y_seq.append(y[i])

    return np.array(X_seq), np.array(y_seq)


# Test model architecture
print("=" * 70)
print("🧪 TESTING LSTM ARCHITECTURE")
print("=" * 70)

# Create sample model
sequence_length = 20
n_features = 30

sample_model = build_lstm_model(
    input_shape=(sequence_length, n_features),
    lstm_units=[128, 64],
    dropout_rate=0.3,
    use_attention=True,
    use_bidirectional=False
)

print("\n📐 Model Architecture:")
sample_model.summary()

print("\n✅ LSTM Architecture ready!")


import numpy as np
import pandas as pd
from typing import Optional, List, Tuple, Union, Dict, Any
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
import warnings
warnings.filterwarnings('ignore')


class LSTMAgent(MLAgent):
    """
    LSTM Neural Network agent for sequence classification.

    Features:
    - Configurable architecture (units, layers, attention)
    - Early stopping and learning rate scheduling
    - Sequence data handling
    - Model checkpointing
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        sequence_length: int = 20,
        lstm_units: List[int] = None,
        dropout_rate: float = 0.3,
        use_attention: bool = True,
        use_bidirectional: bool = False,
        learning_rate: float = 0.001,
        **kwargs
    ):
        """
        Initialize LSTM Agent.

        Args:
            config: System configuration
            logger: Logger instance
            sequence_length: Length of input sequences
            lstm_units: List of LSTM units per layer
            dropout_rate: Dropout rate
            use_attention: Whether to use attention
            use_bidirectional: Whether to use bidirectional LSTM
            learning_rate: Learning rate
        """
        super().__init__("LSTMAgent", config, logger)

        self.sequence_length = sequence_length or self.config.ml.sequence_length
        self.lstm_units = lstm_units or self.config.ml.lstm_units
        self.dropout_rate = dropout_rate or self.config.ml.lstm_dropout
        self.use_attention = use_attention or self.config.ml.use_attention
        self.use_bidirectional = use_bidirectional
        self.learning_rate = learning_rate or self.config.ml.learning_rate

        self.model = None
        self.scaler = StandardScaler()
        self.history = None

    def _build_model(self, n_features: int) -> None:
        """Build the LSTM model."""
        self.model = build_lstm_model(
            input_shape=(self.sequence_length, n_features),
            lstm_units=self.lstm_units,
            dropout_rate=self.dropout_rate,
            use_attention=self.use_attention,
            use_bidirectional=self.use_bidirectional,
            learning_rate=self.learning_rate
        )
        self.logger.info(f"Built LSTM model with {n_features} features")

    def _prepare_sequences(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None
    ) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """
        Prepare sequences for LSTM.

        Args:
            X: Feature matrix
            y: Target variable (optional)

        Returns:
            Tuple of (X_sequences, y_sequences)
        """
        X_seq = []
        y_seq = [] if y is not None else None

        for i in range(self.sequence_length, len(X)):
            X_seq.append(X[i - self.sequence_length:i])
            if y is not None:
                y_seq.append(y[i])

        X_seq = np.array(X_seq)
        y_seq = np.array(y_seq) if y is not None else None

        return X_seq, y_seq

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        X_val: Optional[Union[pd.DataFrame, np.ndarray]] = None,
        y_val: Optional[Union[pd.Series, np.ndarray]] = None,
        epochs: int = None,
        batch_size: int = None,
        verbose: int = 0,
        **kwargs
    ) -> 'LSTMAgent':
        """
        Fit the LSTM model.

        Args:
            X: Training features
            y: Training target
            X_val: Validation features
            y_val: Validation target
            epochs: Number of epochs
            batch_size: Batch size
            verbose: Verbosity level

        Returns:
            Self
        """
        epochs = epochs or self.config.ml.epochs
        batch_size = batch_size or self.config.ml.batch_size

        self.logger.info("Fitting LSTM model...")

        # Store feature names
        if isinstance(X, pd.DataFrame):
            self.feature_names = X.columns.tolist()
            X = X.values

        if isinstance(y, pd.Series):
            y = y.values

        # Scale features
        X_scaled = self.scaler.fit_transform(X)

        # Create sequences
        X_seq, y_seq = self._prepare_sequences(X_scaled, y)

        self.logger.info(f"Training sequences: {X_seq.shape}")

        # Build model
        n_features = X.shape[1]
        self._build_model(n_features)

        # Prepare validation data
        validation_data = None
        if X_val is not None and y_val is not None:
            if isinstance(X_val, pd.DataFrame):
                X_val = X_val.values
            if isinstance(y_val, pd.Series):
                y_val = y_val.values

            X_val_scaled = self.scaler.transform(X_val)
            X_val_seq, y_val_seq = self._prepare_sequences(X_val_scaled, y_val)
            validation_data = (X_val_seq, y_val_seq)
            self.logger.info(f"Validation sequences: {X_val_seq.shape}")

        # Callbacks
        callback_list = [
            EarlyStopping(
                monitor='val_loss' if validation_data else 'loss',
                patience=self.config.ml.early_stopping_patience,
                restore_best_weights=True,
                verbose=verbose
            ),
            ReduceLROnPlateau(
                monitor='val_loss' if validation_data else 'loss',
                factor=0.5,
                patience=5,
                min_lr=1e-6,
                verbose=verbose
            )
        ]

        # Train model
        self.history = self.model.fit(
            X_seq, y_seq,
            epochs=epochs,
            batch_size=batch_size,
            validation_data=validation_data,
            callbacks=callback_list,
            verbose=verbose
        )

        self.is_fitted = True

        # Log final metrics
        final_loss = self.history.history['loss'][-1]
        final_acc = self.history.history['accuracy'][-1]
        self.logger.info(f"Final training - Loss: {final_loss:.4f}, Accuracy: {final_acc:.4f}")

        if validation_data:
            val_loss = self.history.history['val_loss'][-1]
            val_acc = self.history.history['val_accuracy'][-1]
            self.logger.info(f"Final validation - Loss: {val_loss:.4f}, Accuracy: {val_acc:.4f}")

        return self

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate predictions.

        Args:
            X: Feature matrix

        Returns:
            Binary predictions
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        # Scale and create sequences
        X_scaled = self.scaler.transform(X)
        X_seq, _ = self._prepare_sequences(X_scaled)

        # Predict
        probs = self.model.predict(X_seq, verbose=0).flatten()
        predictions = (probs > 0.5).astype(int)

        return predictions

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate probability predictions.

        Args:
            X: Feature matrix

        Returns:
            Probability array
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        # Scale and create sequences
        X_scaled = self.scaler.transform(X)
        X_seq, _ = self._prepare_sequences(X_scaled)

        # Predict probabilities
        probs = self.model.predict(X_seq, verbose=0).flatten()

        return probs

    def predict_with_index(
        self,
        X: pd.DataFrame
    ) -> Tuple[pd.Series, pd.Series]:
        """
        Generate predictions with proper index alignment.

        Args:
            X: Feature DataFrame with DatetimeIndex

        Returns:
            Tuple of (predictions Series, probabilities Series)
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        # Get aligned index (after sequence creation)
        aligned_index = X.index[self.sequence_length:]

        # Generate predictions
        predictions = self.predict(X)
        probabilities = self.predict_proba(X)

        # Ensure lengths match
        min_len = min(len(aligned_index), len(predictions))

        pred_series = pd.Series(predictions[:min_len], index=aligned_index[:min_len])
        prob_series = pd.Series(probabilities[:min_len], index=aligned_index[:min_len])

        return pred_series, prob_series

    def get_training_history(self) -> Dict[str, List[float]]:
        """Get training history."""
        if self.history is None:
            return {}
        return self.history.history

    def save_model(self, path: Path) -> None:
        """Save model to file."""
        if self.model is not None:
            self.model.save(path)
            self.logger.info(f"Model saved to {path}")

            # Save scaler
            scaler_path = path.parent / f"{path.stem}_scaler.pkl"
            import joblib
            joblib.dump(self.scaler, scaler_path)

    def load_model(self, path: Path) -> None:
        """Load model from file."""
        if path.exists():
            self.model = keras.models.load_model(
                path,
                custom_objects={'AttentionLayer': AttentionLayer}
            )
            self.is_fitted = True
            self.logger.info(f"Model loaded from {path}")

            # Load scaler
            scaler_path = path.parent / f"{path.stem}_scaler.pkl"
            if scaler_path.exists():
                import joblib
                self.scaler = joblib.load(scaler_path)

    def run(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: Optional[pd.DataFrame] = None,
        y_val: Optional[pd.Series] = None,
        X_test: Optional[pd.DataFrame] = None,
        y_test: Optional[pd.Series] = None,
        epochs: int = None,
        batch_size: int = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            X_train: Training features
            y_train: Training target
            X_val: Validation features
            y_val: Validation target
            X_test: Test features
            y_test: Test target
            epochs: Number of epochs
            batch_size: Batch size

        Returns:
            AgentResult with training results
        """
        def execute():
            # Fit model
            self.fit(
                X_train, y_train,
                X_val, y_val,
                epochs=epochs,
                batch_size=batch_size,
                verbose=kwargs.get('verbose', 0)
            )

            # Training predictions
            train_preds = self.predict(X_train)
            train_probs = self.predict_proba(X_train)

            # Align targets for evaluation (account for sequence truncation)
            y_train_aligned = y_train.values[self.sequence_length:] if isinstance(y_train, pd.Series) else y_train[self.sequence_length:]

            results = {
                'model': self.model,
                'history': self.get_training_history(),
                'train_predictions': train_preds,
                'train_probabilities': train_probs,
                'train_accuracy': accuracy_score(y_train_aligned[:len(train_preds)], train_preds),
                'sequence_length': self.sequence_length,
                'scaler': self.scaler
            }

            # Validation predictions
            if X_val is not None and y_val is not None:
                val_preds = self.predict(X_val)
                val_probs = self.predict_proba(X_val)
                y_val_aligned = y_val.values[self.sequence_length:] if isinstance(y_val, pd.Series) else y_val[self.sequence_length:]

                results['val_predictions'] = val_preds
                results['val_probabilities'] = val_probs
                results['val_accuracy'] = accuracy_score(y_val_aligned[:len(val_preds)], val_preds)
                try:
                    results['val_auc'] = roc_auc_score(y_val_aligned[:len(val_probs)], val_probs)
                except:
                    results['val_auc'] = 0.5

            # Test predictions
            if X_test is not None and y_test is not None:
                test_preds = self.predict(X_test)
                test_probs = self.predict_proba(X_test)
                y_test_aligned = y_test.values[self.sequence_length:] if isinstance(y_test, pd.Series) else y_test[self.sequence_length:]

                results['test_predictions'] = test_preds
                results['test_probabilities'] = test_probs
                results['test_accuracy'] = accuracy_score(y_test_aligned[:len(test_preds)], test_preds)
                try:
                    results['test_auc'] = roc_auc_score(y_test_aligned[:len(test_probs)], test_probs)
                except:
                    results['test_auc'] = 0.5

                results['classification_report'] = classification_report(
                    y_test_aligned[:len(test_preds)],
                    test_preds,
                    output_dict=True
                )

            return results

        return self._execute_with_timing(execute)


# Test LSTM Agent
print("=" * 70)
print("🧪 TESTING LSTM AGENT")
print("=" * 70)

# Generate sample sequential data
np.random.seed(42)
n_samples = 500
n_features = 20
sequence_length = 20

# Create sample data
X_lstm_sample = pd.DataFrame(
    np.random.randn(n_samples, n_features),
    columns=[f'feature_{i}' for i in range(n_features)]
)

# Create target with some pattern
y_lstm_sample = pd.Series(
    (X_lstm_sample.rolling(5).mean().sum(axis=1) > 0).astype(int).values
)

# Split data
train_size = int(0.7 * n_samples)
val_size = int(0.15 * n_samples)

X_train_lstm = X_lstm_sample[:train_size]
y_train_lstm = y_lstm_sample[:train_size]
X_val_lstm = X_lstm_sample[train_size:train_size+val_size]
y_val_lstm = y_lstm_sample[train_size:train_size+val_size]
X_test_lstm = X_lstm_sample[train_size+val_size:]
y_test_lstm = y_lstm_sample[train_size+val_size:]

print(f"\nData shapes:")
print(f"  Train: {X_train_lstm.shape}, Val: {X_val_lstm.shape}, Test: {X_test_lstm.shape}")

# Create and train LSTM agent
lstm_agent = LSTMAgent(
    config=config,
    sequence_length=sequence_length,
    lstm_units=[64, 32],
    dropout_rate=0.3,
    use_attention=True
)

print("\n🧠 Training LSTM model (reduced epochs for demo)...")
lstm_result = lstm_agent.run(
    X_train_lstm, y_train_lstm,
    X_val_lstm, y_val_lstm,
    X_test_lstm, y_test_lstm,
    epochs=10,  # Reduced for demo
    batch_size=32,
    verbose=0
)

if lstm_result.success:
    print(f"\n✅ LSTM training completed!")
    print(f"   Train Accuracy: {lstm_result.data['train_accuracy']:.4f}")
    print(f"   Val Accuracy: {lstm_result.data['val_accuracy']:.4f}")
    print(f"   Val AUC: {lstm_result.data['val_auc']:.4f}")
    print(f"   Test Accuracy: {lstm_result.data['test_accuracy']:.4f}")
    print(f"   Test AUC: {lstm_result.data['test_auc']:.4f}")

    # Plot training history
    history = lstm_result.data['history']
    if history:
        print(f"\n📈 Training History:")
        print(f"   Final Loss: {history['loss'][-1]:.4f}")
        print(f"   Final Val Loss: {history.get('val_loss', [0])[-1]:.4f}")
else:
    print(f"❌ Error: {lstm_result.errors}")

print("\n" + "=" * 70)
print("✅ LSTM Agent ready!")