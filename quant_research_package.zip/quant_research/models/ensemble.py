"""
ensemble.py
===========
EnsembleAgent (Stacking)
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import List, Dict, Optional, Any, Union, Tuple
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.model_selection import cross_val_predict, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, roc_auc_score
import warnings
warnings.filterwarnings('ignore')


class EnsembleAgent(MLAgent):
    """
    Ensemble model agent using stacking with a meta-learner.

    Combines predictions from multiple base models using:
    - Stacking with meta-model (Logistic Regression)
    - Weighted averaging with learned weights
    - Optional regime-aware weighting

    This replaces hardcoded ensemble weights with learned weights.

    Attributes:
        base_models: Dictionary of base model agents
        meta_model: Meta-learner model
        base_predictions: Out-of-fold predictions from base models
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        meta_model_type: str = 'logistic',
        use_probabilities: bool = True,
        include_features: bool = False,
        n_folds: int = 5
    ):
        """
        Initialize Ensemble Agent.

        Args:
            config: System configuration
            logger: Logger instance
            meta_model_type: Type of meta-model ('logistic', 'ridge')
            use_probabilities: Whether to use probabilities or predictions
            include_features: Whether to include original features in meta-model
            n_folds: Number of folds for generating out-of-fold predictions
        """
        super().__init__("EnsembleAgent", config, logger)

        self.meta_model_type = meta_model_type
        self.use_probabilities = use_probabilities
        self.include_features = include_features
        self.n_folds = n_folds

        self.base_models: Dict[str, MLAgent] = {}
        self.meta_model = None
        self.meta_scaler = StandardScaler()
        self.base_predictions: Dict[str, np.ndarray] = {}
        self.model_weights: Dict[str, float] = {}

        # Initialize meta-model
        if meta_model_type == 'logistic':
            self.meta_model = LogisticRegression(
                penalty='l2',
                C=1.0,
                solver='lbfgs',
                max_iter=1000,
                random_state=self.config.ml.random_seed
            )
        elif meta_model_type == 'ridge':
            self.meta_model = Ridge(
                alpha=1.0,
                random_state=self.config.ml.random_seed
            )

    def add_base_model(
        self,
        name: str,
        model: MLAgent
    ) -> None:
        """
        Add a base model to the ensemble.

        Args:
            name: Model name
            model: MLAgent instance
        """
        self.base_models[name] = model
        self.logger.info(f"Added base model: {name}")

    def _generate_oof_predictions(
        self,
        X: np.ndarray,
        y: np.ndarray
    ) -> Dict[str, np.ndarray]:
        """
        Generate out-of-fold predictions for all base models.

        Args:
            X: Feature matrix
            y: Target variable

        Returns:
            Dictionary of OOF predictions per model
        """
        self.logger.info(f"Generating OOF predictions with {self.n_folds} folds...")

        oof_predictions = {name: np.zeros(len(y)) for name in self.base_models}
        kfold = KFold(n_splits=self.n_folds, shuffle=True, random_state=self.config.ml.random_seed)

        for fold, (train_idx, val_idx) in enumerate(kfold.split(X)):
            self.logger.info(f"  Fold {fold + 1}/{self.n_folds}")

            X_train, X_val = X[train_idx], X[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]

            for name, model in self.base_models.items():
                # Clone model for this fold
                model_clone = model.__class__(config=self.config)

                # Fit on training fold
                if hasattr(model_clone, 'fit'):
                    # Handle LSTM differently (needs more data)
                    if 'LSTM' in name:
                        if len(X_train) > model_clone.sequence_length * 2:
                            model_clone.fit(
                                pd.DataFrame(X_train),
                                pd.Series(y_train),
                                epochs=20,
                                verbose=0
                            )
                            # Get predictions
                            if self.use_probabilities:
                                preds = model_clone.predict_proba(pd.DataFrame(X_val))
                            else:
                                preds = model_clone.predict(pd.DataFrame(X_val))

                            # Align predictions with validation indices
                            seq_len = model_clone.sequence_length
                            if len(preds) < len(val_idx):
                                # Pad with mean
                                pad_len = len(val_idx) - len(preds)
                                preds = np.concatenate([np.full(pad_len, preds.mean()), preds])
                        else:
                            preds = np.full(len(val_idx), 0.5)
                    else:
                        model_clone.fit(pd.DataFrame(X_train), pd.Series(y_train))

                        if self.use_probabilities and hasattr(model_clone, 'predict_proba'):
                            preds = model_clone.predict_proba(pd.DataFrame(X_val))
                        else:
                            preds = model_clone.predict(pd.DataFrame(X_val))

                    oof_predictions[name][val_idx] = preds

        self.base_predictions = oof_predictions
        return oof_predictions

    def _create_meta_features(
        self,
        predictions: Dict[str, np.ndarray],
        X: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        Create feature matrix for meta-model.

        Args:
            predictions: Dictionary of predictions per model
            X: Original features (optional)

        Returns:
            Meta-feature matrix
        """
        # Stack predictions
        meta_features = np.column_stack([predictions[name] for name in sorted(predictions.keys())])

        # Optionally include original features
        if self.include_features and X is not None:
            meta_features = np.column_stack([meta_features, X])

        return meta_features

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        **kwargs
    ) -> 'EnsembleAgent':
        """
        Fit the ensemble model.

        Args:
            X: Feature matrix
            y: Target variable

        Returns:
            Self
        """
        self.logger.info("Fitting ensemble model...")

        if isinstance(X, pd.DataFrame):
            self.feature_names = X.columns.tolist()
            X = X.values

        if isinstance(y, pd.Series):
            y = y.values

        # Generate out-of-fold predictions
        oof_predictions = self._generate_oof_predictions(X, y)

        # Create meta-features
        meta_features = self._create_meta_features(
            oof_predictions,
            X if self.include_features else None
        )

        # Scale meta-features
        meta_features_scaled = self.meta_scaler.fit_transform(meta_features)

        # Fit meta-model
        self.logger.info("Fitting meta-model...")
        self.meta_model.fit(meta_features_scaled, y)

        # Extract model weights
        self._extract_weights()

        # Fit all base models on full data
        self.logger.info("Fitting base models on full data...")
        for name, model in self.base_models.items():
            if 'LSTM' in name:
                model.fit(pd.DataFrame(X), pd.Series(y), epochs=30, verbose=0)
            else:
                model.fit(pd.DataFrame(X), pd.Series(y))

        self.is_fitted = True
        self.logger.info("Ensemble model fitted successfully")

        return self

    def _extract_weights(self) -> None:
        """Extract and normalize model weights from meta-model."""
        if hasattr(self.meta_model, 'coef_'):
            coefs = self.meta_model.coef_.flatten()

            # Get weights for base models (first N coefficients)
            n_models = len(self.base_models)
            model_coefs = coefs[:n_models]

            # Normalize to get weights
            abs_coefs = np.abs(model_coefs)
            weights = abs_coefs / abs_coefs.sum()

            for i, name in enumerate(sorted(self.base_models.keys())):
                self.model_weights[name] = weights[i]

            self.logger.info(f"Model weights: {self.model_weights}")

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate predictions.

        Args:
            X: Feature matrix

        Returns:
            Binary predictions
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        probs = self.predict_proba(X)
        return (probs > 0.5).astype(int)

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate probability predictions.

        Args:
            X: Feature matrix

        Returns:
            Probability array
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X_arr = X.values
        else:
            X_arr = X

        # Get predictions from all base models
        predictions = {}
        min_len = len(X_arr)

        for name, model in self.base_models.items():
            if 'LSTM' in name:
                preds = model.predict_proba(pd.DataFrame(X_arr) if not isinstance(X, pd.DataFrame) else X)
                # Handle sequence length mismatch
                if len(preds) < min_len:
                    pad_len = min_len - len(preds)
                    preds = np.concatenate([np.full(pad_len, preds.mean()), preds])
                min_len = min(min_len, len(preds))
            else:
                if self.use_probabilities and hasattr(model, 'predict_proba'):
                    preds = model.predict_proba(pd.DataFrame(X_arr) if not isinstance(X, pd.DataFrame) else X)
                else:
                    preds = model.predict(pd.DataFrame(X_arr) if not isinstance(X, pd.DataFrame) else X)

            predictions[name] = preds[:min_len]

        # Create meta-features
        meta_features = self._create_meta_features(
            predictions,
            X_arr[:min_len] if self.include_features else None
        )

        # Scale and predict
        meta_features_scaled = self.meta_scaler.transform(meta_features)

        if hasattr(self.meta_model, 'predict_proba'):
            probs = self.meta_model.predict_proba(meta_features_scaled)[:, 1]
        else:
            probs = self.meta_model.predict(meta_features_scaled)
            probs = np.clip(probs, 0, 1)

        return probs

    def predict_weighted_average(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate predictions using weighted average of base models.

        Args:
            X: Feature matrix

        Returns:
            Probability array
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X_arr = X.values
        else:
            X_arr = X

        # Get weighted predictions
        weighted_sum = np.zeros(len(X_arr))
        min_len = len(X_arr)

        for name, model in self.base_models.items():
            weight = self.model_weights.get(name, 1.0 / len(self.base_models))

            if 'LSTM' in name:
                preds = model.predict_proba(pd.DataFrame(X_arr))
                if len(preds) < min_len:
                    pad_len = min_len - len(preds)
                    preds = np.concatenate([np.full(pad_len, preds.mean()), preds])
                min_len = min(min_len, len(preds))
            else:
                if hasattr(model, 'predict_proba'):
                    preds = model.predict_proba(pd.DataFrame(X_arr))
                else:
                    preds = model.predict(pd.DataFrame(X_arr))

            weighted_sum[:min_len] += weight * preds[:min_len]

        return weighted_sum[:min_len]

    def get_model_weights(self) -> Dict[str, float]:
        """Get learned model weights."""
        return self.model_weights

    def get_base_model_predictions(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> Dict[str, np.ndarray]:
        """
        Get individual predictions from each base model.

        Args:
            X: Feature matrix

        Returns:
            Dictionary of predictions per model
        """
        predictions = {}

        for name, model in self.base_models.items():
            if hasattr(model, 'predict_proba'):
                predictions[name] = model.predict_proba(X)
            else:
                predictions[name] = model.predict(X)

        return predictions

    def run(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        y_test: Optional[pd.Series] = None,
        base_models: Optional[Dict[str, MLAgent]] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            X_train: Training features
            y_train: Training target
            X_test: Test features
            y_test: Test target
            base_models: Dictionary of base models to use

        Returns:
            AgentResult with ensemble results
        """
        def execute():
            # Add base models if provided
            if base_models:
                for name, model in base_models.items():
                    self.add_base_model(name, model)

            if not self.base_models:
                raise ValueError("No base models added to ensemble")

            # Fit ensemble
            self.fit(X_train, y_train)

            # Training predictions
            train_preds = self.predict(X_train)
            train_probs = self.predict_proba(X_train)

            # Handle length mismatch
            y_train_arr = y_train.values if isinstance(y_train, pd.Series) else y_train
            min_len = min(len(train_preds), len(y_train_arr))

            results = {
                'model': self.meta_model,
                'base_models': list(self.base_models.keys()),
                'model_weights': self.model_weights,
                'train_predictions': train_preds,
                'train_probabilities': train_probs,
                'train_accuracy': accuracy_score(y_train_arr[-min_len:], train_preds[-min_len:]),
                'oof_predictions': self.base_predictions
            }

            try:
                results['train_auc'] = roc_auc_score(y_train_arr[-min_len:], train_probs[-min_len:])
            except:
                results['train_auc'] = 0.5

            # Test predictions
            if X_test is not None and y_test is not None:
                test_preds = self.predict(X_test)
                test_probs = self.predict_proba(X_test)

                y_test_arr = y_test.values if isinstance(y_test, pd.Series) else y_test
                min_len_test = min(len(test_preds), len(y_test_arr))

                results['test_predictions'] = test_preds
                results['test_probabilities'] = test_probs
                results['test_accuracy'] = accuracy_score(y_test_arr[-min_len_test:], test_preds[-min_len_test:])

                try:
                    results['test_auc'] = roc_auc_score(y_test_arr[-min_len_test:], test_probs[-min_len_test:])
                except:
                    results['test_auc'] = 0.5

            return results

        return self._execute_with_timing(execute)


# Test Ensemble Agent
print("=" * 70)
print("🧪 TESTING ENSEMBLE AGENT")
print("=" * 70)

# Create base models
print("\n📦 Creating base models...")
lr_model = LogisticRegressionAgent(config=config)
rf_model = RandomForestAgent(config=config, n_estimators=50)

# Create ensemble (without LSTM for speed)
ensemble_agent = EnsembleAgent(
    config=config,
    meta_model_type='logistic',
    use_probabilities=True,
    n_folds=3
)

# Add base models
base_models = {
    'logistic_regression': lr_model,
    'random_forest': rf_model
}

if XGBOOST_AVAILABLE:
    xgb_model = XGBoostAgent(config=config, n_estimators=50)
    base_models['xgboost'] = xgb_model

# Use sample data from previous cells
if 'X_train' in dir():
    print("\n🎯 Training ensemble...")
    ensemble_result = ensemble_agent.run(
        X_train, y_train,
        X_test, y_test,
        base_models=base_models
    )

    if ensemble_result.success:
        print(f"\n✅ Ensemble training completed!")
        print(f"   Base models: {ensemble_result.data['base_models']}")
        print(f"   Model weights:")
        for name, weight in ensemble_result.data['model_weights'].items():
            print(f"      {name}: {weight:.4f}")
        print(f"\n   Train Accuracy: {ensemble_result.data['train_accuracy']:.4f}")
        print(f"   Train AUC: {ensemble_result.data['train_auc']:.4f}")
        print(f"   Test Accuracy: {ensemble_result.data['test_accuracy']:.4f}")
        print(f"   Test AUC: {ensemble_result.data['test_auc']:.4f}")
    else:
        print(f"❌ Error: {ensemble_result.errors}")
else:
    print("⚠️ Sample data not available. Run Cell 17 first.")

print("\n" + "=" * 70)
print("✅ Ensemble Agent ready!")