"""
classical.py
============
LogisticRegressionAgent + RandomForestAgent + XGBoostAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import pandas as pd
import numpy as np
from typing import Dict, Optional, Any, Union, List, Tuple
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)
import joblib
import warnings
warnings.filterwarnings('ignore')


class LogisticRegressionAgent(MLAgent):
    """
    Logistic Regression model agent for binary classification.

    Features:
    - L1/L2 regularization support
    - Class weight balancing
    - Probability calibration
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        **model_params
    ):
        """
        Initialize Logistic Regression Agent.

        Args:
            config: System configuration
            logger: Logger instance
            **model_params: Additional model parameters
        """
        super().__init__("LogisticRegressionAgent", config, logger)

        self.scaler = StandardScaler()
        self.model_params = {
            'penalty': 'l2',
            'C': 1.0,
            'solver': 'lbfgs',
            'max_iter': 1000,
            'class_weight': 'balanced',
            'random_state': self.config.ml.random_seed,
            **model_params
        }
        self.model = LogisticRegression(**self.model_params)

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        **kwargs
    ) -> 'LogisticRegressionAgent':
        """
        Fit the model.

        Args:
            X: Feature matrix
            y: Target variable

        Returns:
            Self
        """
        self.logger.info("Fitting Logistic Regression model...")

        # Store feature names
        if isinstance(X, pd.DataFrame):
            self.feature_names = X.columns.tolist()
            X = X.values

        # Scale features
        X_scaled = self.scaler.fit_transform(X)

        # Fit model
        self.model.fit(X_scaled, y)
        self.is_fitted = True

        # Log results
        if hasattr(self.model, 'n_iter_'):
            self.logger.info(f"Converged in {self.model.n_iter_[0]} iterations")

        return self

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate predictions.

        Args:
            X: Feature matrix

        Returns:
            Predictions
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled)

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate probability predictions.

        Args:
            X: Feature matrix

        Returns:
            Probabilities for positive class
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        X_scaled = self.scaler.transform(X)
        return self.model.predict_proba(X_scaled)[:, 1]

    def get_coefficients(self) -> pd.Series:
        """Get model coefficients."""
        if not self.is_fitted:
            return None

        return pd.Series(
            self.model.coef_[0],
            index=self.feature_names
        ).sort_values(key=abs, ascending=False)

    def run(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        y_test: Optional[pd.Series] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.
        """
        def execute():
            # Fit model
            self.fit(X_train, y_train)

            # Predictions on training data
            train_preds = self.predict(X_train)
            train_probs = self.predict_proba(X_train)

            results = {
                'model': self.model,
                'train_predictions': train_preds,
                'train_probabilities': train_probs,
                'train_accuracy': accuracy_score(y_train, train_preds),
                'coefficients': self.get_coefficients()
            }

            # Test predictions if provided
            if X_test is not None and y_test is not None:
                test_preds = self.predict(X_test)
                test_probs = self.predict_proba(X_test)

                results['test_predictions'] = test_preds
                results['test_probabilities'] = test_probs
                results['test_accuracy'] = accuracy_score(y_test, test_preds)
                results['test_auc'] = roc_auc_score(y_test, test_probs)
                results['classification_report'] = classification_report(
                    y_test, test_preds, output_dict=True
                )

            return results

        return self._execute_with_timing(execute)


class RandomForestAgent(MLAgent):
    """
    Random Forest model agent for classification.

    Features:
    - Feature importance extraction
    - Out-of-bag score estimation
    - Class weight balancing
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        **model_params
    ):
        """
        Initialize Random Forest Agent.

        Args:
            config: System configuration
            logger: Logger instance
            **model_params: Additional model parameters
        """
        super().__init__("RandomForestAgent", config, logger)

        self.model_params = {
            'n_estimators': 200,
            'max_depth': 10,
            'min_samples_split': 10,
            'min_samples_leaf': 5,
            'max_features': 'sqrt',
            'class_weight': 'balanced',
            'oob_score': True,
            'random_state': self.config.ml.random_seed,
            'n_jobs': -1,
            **model_params
        }
        self.model = RandomForestClassifier(**self.model_params)

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        **kwargs
    ) -> 'RandomForestAgent':
        """
        Fit the model.

        Args:
            X: Feature matrix
            y: Target variable

        Returns:
            Self
        """
        self.logger.info("Fitting Random Forest model...")

        # Store feature names
        if isinstance(X, pd.DataFrame):
            self.feature_names = X.columns.tolist()
            X = X.values

        if isinstance(y, pd.Series):
            y = y.values

        # Fit model
        self.model.fit(X, y)
        self.is_fitted = True

        # Log results
        if hasattr(self.model, 'oob_score_'):
            self.logger.info(f"OOB Score: {self.model.oob_score_:.4f}")

        return self

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """Generate predictions."""
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        return self.model.predict(X)

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """Generate probability predictions."""
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        return self.model.predict_proba(X)[:, 1]

    def get_feature_importance(self) -> pd.Series:
        """Get feature importance scores."""
        if not self.is_fitted:
            return None

        return pd.Series(
            self.model.feature_importances_,
            index=self.feature_names
        ).sort_values(ascending=False)

    def run(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_test: Optional[pd.DataFrame] = None,
        y_test: Optional[pd.Series] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.
        """
        def execute():
            # Fit model
            self.fit(X_train, y_train)

            # Training predictions
            train_preds = self.predict(X_train)
            train_probs = self.predict_proba(X_train)

            results = {
                'model': self.model,
                'train_predictions': train_preds,
                'train_probabilities': train_probs,
                'train_accuracy': accuracy_score(y_train, train_preds),
                'feature_importance': self.get_feature_importance(),
                'oob_score': self.model.oob_score_ if hasattr(self.model, 'oob_score_') else None
            }

            # Test predictions if provided
            if X_test is not None and y_test is not None:
                test_preds = self.predict(X_test)
                test_probs = self.predict_proba(X_test)

                results['test_predictions'] = test_preds
                results['test_probabilities'] = test_probs
                results['test_accuracy'] = accuracy_score(y_test, test_preds)
                results['test_auc'] = roc_auc_score(y_test, test_probs)
                results['classification_report'] = classification_report(
                    y_test, test_preds, output_dict=True
                )

            return results

        return self._execute_with_timing(execute)


# Utility function for model evaluation
def evaluate_model(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: Optional[np.ndarray] = None
) -> Dict[str, float]:
    """
    Evaluate model performance.

    Args:
        y_true: True labels
        y_pred: Predicted labels
        y_prob: Predicted probabilities

    Returns:
        Dictionary of metrics
    """
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision': precision_score(y_true, y_pred, zero_division=0),
        'recall': recall_score(y_true, y_pred, zero_division=0),
        'f1': f1_score(y_true, y_pred, zero_division=0),
    }

    if y_prob is not None:
        try:
            metrics['auc'] = roc_auc_score(y_true, y_prob)
        except ValueError:
            metrics['auc'] = 0.5

    return metrics


# Test ML Models
print("=" * 70)
print("🧪 TESTING ML MODELS")
print("=" * 70)

# Generate sample data for testing
np.random.seed(42)
n_samples = 1000
n_features = 20

X_sample = pd.DataFrame(
    np.random.randn(n_samples, n_features),
    columns=[f'feature_{i}' for i in range(n_features)]
)
y_sample = pd.Series((X_sample.sum(axis=1) > 0).astype(int))

# Split data
split_idx = int(0.8 * len(X_sample))
X_train, X_test = X_sample[:split_idx], X_sample[split_idx:]
y_train, y_test = y_sample[:split_idx], y_sample[split_idx:]

# Test Logistic Regression
print("\n📊 Logistic Regression:")
lr_agent = LogisticRegressionAgent(config=config)
lr_result = lr_agent.run(X_train, y_train, X_test, y_test)

if lr_result.success:
    print(f"   Train Accuracy: {lr_result.data['train_accuracy']:.4f}")
    print(f"   Test Accuracy: {lr_result.data['test_accuracy']:.4f}")
    print(f"   Test AUC: {lr_result.data['test_auc']:.4f}")

# Test Random Forest
print("\n🌲 Random Forest:")
rf_agent = RandomForestAgent(config=config)
rf_result = rf_agent.run(X_train, y_train, X_test, y_test)

if rf_result.success:
    print(f"   Train Accuracy: {rf_result.data['train_accuracy']:.4f}")
    print(f"   Test Accuracy: {rf_result.data['test_accuracy']:.4f}")
    print(f"   Test AUC: {rf_result.data['test_auc']:.4f}")
    print(f"   OOB Score: {rf_result.data['oob_score']:.4f}")
    print(f"\n   Top 5 Features:")
    for feat, imp in rf_result.data['feature_importance'].head(5).items():
        print(f"      {feat}: {imp:.4f}")

print("\n" + "=" * 70)
print("✅ Traditional ML Models ready!")


import pandas as pd
import numpy as np
from typing import Dict, Optional, Any, Union, List
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
import warnings
warnings.filterwarnings('ignore')

try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
    print("✅ XGBoost library available")
except ImportError:
    XGBOOST_AVAILABLE = False
    print("⚠️ XGBoost not available")


class XGBoostAgent(MLAgent):
    """
    XGBoost model agent for classification.

    Features:
    - Early stopping
    - Feature importance (gain, weight, cover)
    - GPU support (if available)
    - Handling class imbalance
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        **model_params
    ):
        """
        Initialize XGBoost Agent.

        Args:
            config: System configuration
            logger: Logger instance
            **model_params: Additional model parameters
        """
        super().__init__("XGBoostAgent", config, logger)

        if not XGBOOST_AVAILABLE:
            raise ImportError("XGBoost is not installed")

        self.model_params = {
            'objective': 'binary:logistic',
            'eval_metric': 'auc',
            'n_estimators': 200,
            'max_depth': 6,
            'learning_rate': 0.1,
            'subsample': 0.8,
            'colsample_bytree': 0.8,
            'min_child_weight': 1,
            'gamma': 0,
            'reg_alpha': 0.1,
            'reg_lambda': 1,
            'scale_pos_weight': 1,
            'random_state': self.config.ml.random_seed,
            'n_jobs': -1,
            'use_label_encoder': False,
            **model_params
        }

        self.model = xgb.XGBClassifier(**self.model_params)
        self.early_stopping_rounds = 20
        self.eval_set = None

    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        X_val: Optional[Union[pd.DataFrame, np.ndarray]] = None,
        y_val: Optional[Union[pd.Series, np.ndarray]] = None,
        early_stopping: bool = True,
        **kwargs
    ) -> 'XGBoostAgent':
        """
        Fit the model.

        Args:
            X: Training features
            y: Training target
            X_val: Validation features (for early stopping)
            y_val: Validation target
            early_stopping: Whether to use early stopping

        Returns:
            Self
        """
        self.logger.info("Fitting XGBoost model...")

        # Store feature names
        if isinstance(X, pd.DataFrame):
            self.feature_names = X.columns.tolist()
            X = X.values

        if isinstance(y, pd.Series):
            y = y.values

        # Calculate scale_pos_weight for imbalanced classes
        n_pos = np.sum(y == 1)
        n_neg = np.sum(y == 0)
        if n_pos > 0 and n_neg > 0:
            self.model.set_params(scale_pos_weight=n_neg / n_pos)

        # Prepare evaluation set
        fit_params = {}
        if X_val is not None and y_val is not None and early_stopping:
            if isinstance(X_val, pd.DataFrame):
                X_val = X_val.values
            if isinstance(y_val, pd.Series):
                y_val = y_val.values

            fit_params['eval_set'] = [(X_val, y_val)]
            fit_params['verbose'] = False

            # Use callbacks for early stopping in newer XGBoost
            try:
                fit_params['callbacks'] = [
                    xgb.callback.EarlyStopping(
                        rounds=self.early_stopping_rounds,
                        save_best=True
                    )
                ]
            except:
                fit_params['early_stopping_rounds'] = self.early_stopping_rounds

        # Fit model
        self.model.fit(X, y, **fit_params)
        self.is_fitted = True

        # Log best iteration
        if hasattr(self.model, 'best_iteration'):
            self.logger.info(f"Best iteration: {self.model.best_iteration}")

        return self

    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """Generate predictions."""
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        return self.model.predict(X)

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """Generate probability predictions."""
        if not self.is_fitted:
            raise ValueError("Model not fitted")

        if isinstance(X, pd.DataFrame):
            X = X.values

        return self.model.predict_proba(X)[:, 1]

    def get_feature_importance(
        self,
        importance_type: str = 'gain'
    ) -> pd.Series:
        """
        Get feature importance.

        Args:
            importance_type: 'gain', 'weight', or 'cover'

        Returns:
            Feature importance series
        """
        if not self.is_fitted:
            return None

        try:
            importance = self.model.get_booster().get_score(
                importance_type=importance_type
            )

            # Create series with all features (some may have 0 importance)
            imp_series = pd.Series(index=self.feature_names, dtype=float)
            for feat, imp in importance.items():
                if feat in imp_series.index:
                    imp_series[feat] = imp
                else:
                    # Handle f0, f1, etc. naming
                    idx = int(feat[1:]) if feat.startswith('f') else None
                    if idx is not None and idx < len(self.feature_names):
                        imp_series[self.feature_names[idx]] = imp

            imp_series = imp_series.fillna(0)
            return imp_series.sort_values(ascending=False)
        except Exception as e:
            # Fallback to feature_importances_
            return pd.Series(
                self.model.feature_importances_,
                index=self.feature_names
            ).sort_values(ascending=False)

    def get_all_importances(self) -> Dict[str, pd.Series]:
        """Get all types of feature importance."""
        return {
            'gain': self.get_feature_importance('gain'),
            'weight': self.get_feature_importance('weight'),
            'cover': self.get_feature_importance('cover')
        }

    def run(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: Optional[pd.DataFrame] = None,
        y_val: Optional[pd.Series] = None,
        X_test: Optional[pd.DataFrame] = None,
        y_test: Optional[pd.Series] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.
        """
        def execute():
            # Fit model
            self.fit(X_train, y_train, X_val, y_val)

            # Training predictions
            train_preds = self.predict(X_train)
            train_probs = self.predict_proba(X_train)

            results = {
                'model': self.model,
                'train_predictions': train_preds,
                'train_probabilities': train_probs,
                'train_accuracy': accuracy_score(y_train, train_preds),
                'feature_importance': self.get_feature_importance(),
            }

            # Validation predictions
            if X_val is not None and y_val is not None:
                val_preds = self.predict(X_val)
                val_probs = self.predict_proba(X_val)
                results['val_accuracy'] = accuracy_score(y_val, val_preds)
                results['val_auc'] = roc_auc_score(y_val, val_probs)

            # Test predictions
            if X_test is not None and y_test is not None:
                test_preds = self.predict(X_test)
                test_probs = self.predict_proba(X_test)

                results['test_predictions'] = test_preds
                results['test_probabilities'] = test_probs
                results['test_accuracy'] = accuracy_score(y_test, test_preds)
                results['test_auc'] = roc_auc_score(y_test, test_probs)
                results['classification_report'] = classification_report(
                    y_test, test_preds, output_dict=True
                )

            return results

        return self._execute_with_timing(execute)


# Test XGBoost
print("=" * 70)
print("🧪 TESTING XGBOOST MODEL")
print("=" * 70)

if XGBOOST_AVAILABLE:
    # Use sample data from previous cell
    if 'X_train' in dir():
        # Split validation from training
        val_split = int(0.8 * len(X_train))
        X_tr, X_val_xgb = X_train[:val_split], X_train[val_split:]
        y_tr, y_val_xgb = y_train[:val_split], y_train[val_split:]

        print("\n🚀 XGBoost:")
        xgb_agent = XGBoostAgent(config=config)
        xgb_result = xgb_agent.run(X_tr, y_tr, X_val_xgb, y_val_xgb, X_test, y_test)

        if xgb_result.success:
            print(f"   Train Accuracy: {xgb_result.data['train_accuracy']:.4f}")
            print(f"   Val Accuracy: {xgb_result.data['val_accuracy']:.4f}")
            print(f"   Val AUC: {xgb_result.data['val_auc']:.4f}")
            print(f"   Test Accuracy: {xgb_result.data['test_accuracy']:.4f}")
            print(f"   Test AUC: {xgb_result.data['test_auc']:.4f}")
            print(f"\n   Top 5 Features (by gain):")
            for feat, imp in xgb_result.data['feature_importance'].head(5).items():
                print(f"      {feat}: {imp:.4f}")
        else:
            print(f"❌ Error: {xgb_result.errors}")
    else:
        print("⚠️ Sample data not available. Run Cell 17 first.")
else:
    print("⚠️ XGBoost not available")

print("\n" + "=" * 70)
print("✅ XGBoost Model ready!")