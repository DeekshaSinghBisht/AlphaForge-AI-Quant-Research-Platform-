"""
tuning.py
=========
HyperparameterAgent (Optuna)
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, Union, List, Callable
from sklearn.model_selection import cross_val_score, TimeSeriesSplit
from sklearn.metrics import roc_auc_score, accuracy_score
import warnings
warnings.filterwarnings('ignore')

try:
    import optuna
    from optuna.samplers import TPESampler
    from optuna.pruners import MedianPruner
    OPTUNA_AVAILABLE = True
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    print("✅ Optuna available for hyperparameter optimization")
except ImportError:
    OPTUNA_AVAILABLE = False
    print("⚠️ Optuna not available")


class HyperparameterAgent(BaseAgent):
    """
    Agent for automated hyperparameter optimization.

    Uses Optuna for Bayesian optimization of model hyperparameters.
    Supports all model types in the system.

    Attributes:
        study: Optuna study object
        best_params: Best hyperparameters found
        best_score: Best score achieved
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        n_trials: int = 50,
        timeout: int = 3600,
        cv_folds: int = 5,
        scoring: str = 'roc_auc'
    ):
        """
        Initialize Hyperparameter Agent.

        Args:
            config: System configuration
            logger: Logger instance
            n_trials: Number of optimization trials
            timeout: Maximum optimization time in seconds
            cv_folds: Number of cross-validation folds
            scoring: Scoring metric
        """
        super().__init__("HyperparameterAgent", config, logger)

        if not OPTUNA_AVAILABLE:
            raise ImportError("Optuna is required for hyperparameter optimization")

        self.n_trials = n_trials or self.config.ml.optuna_trials
        self.timeout = timeout or self.config.ml.optuna_timeout
        self.cv_folds = cv_folds
        self.scoring = scoring

        self.study = None
        self.best_params: Dict[str, Any] = {}
        self.best_score: float = 0.0
        self.optimization_history: List[Dict] = []

    def _create_objective(
        self,
        model_type: str,
        X: np.ndarray,
        y: np.ndarray,
        use_timeseries_cv: bool = True
    ) -> Callable:
        """
        Create Optuna objective function for a model type.

        Args:
            model_type: Type of model to optimize
            X: Feature matrix
            y: Target variable
            use_timeseries_cv: Whether to use time series CV

        Returns:
            Objective function
        """
        if use_timeseries_cv:
            cv = TimeSeriesSplit(n_splits=self.cv_folds)
        else:
            cv = self.cv_folds

        def objective(trial: optuna.Trial) -> float:
            if model_type == 'logistic_regression':
                params = {
                    'C': trial.suggest_float('C', 1e-4, 10.0, log=True),
                    'penalty': trial.suggest_categorical('penalty', ['l1', 'l2']),
                    'solver': 'saga',
                    'max_iter': 1000,
                    'random_state': self.config.ml.random_seed
                }
                from sklearn.linear_model import LogisticRegression
                model = LogisticRegression(**params)

            elif model_type == 'random_forest':
                params = {
                    'n_estimators': trial.suggest_int('n_estimators', 50, 300),
                    'max_depth': trial.suggest_int('max_depth', 3, 15),
                    'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
                    'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
                    'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', None]),
                    'random_state': self.config.ml.random_seed,
                    'n_jobs': -1
                }
                from sklearn.ensemble import RandomForestClassifier
                model = RandomForestClassifier(**params)

            elif model_type == 'xgboost':
                params = {
                    'n_estimators': trial.suggest_int('n_estimators', 50, 300),
                    'max_depth': trial.suggest_int('max_depth', 3, 10),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
                    'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
                    'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
                    'gamma': trial.suggest_float('gamma', 0, 5),
                    'reg_alpha': trial.suggest_float('reg_alpha', 1e-4, 10, log=True),
                    'reg_lambda': trial.suggest_float('reg_lambda', 1e-4, 10, log=True),
                    'random_state': self.config.ml.random_seed,
                    'use_label_encoder': False,
                    'eval_metric': 'logloss'
                }
                import xgboost as xgb
                model = xgb.XGBClassifier(**params)

            elif model_type == 'lightgbm':
                params = {
                    'n_estimators': trial.suggest_int('n_estimators', 50, 300),
                    'max_depth': trial.suggest_int('max_depth', 3, 10),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.3, log=True),
                    'subsample': trial.suggest_float('subsample', 0.6, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.6, 1.0),
                    'min_child_samples': trial.suggest_int('min_child_samples', 5, 100),
                    'reg_alpha': trial.suggest_float('reg_alpha', 1e-4, 10, log=True),
                    'reg_lambda': trial.suggest_float('reg_lambda', 1e-4, 10, log=True),
                    'random_state': self.config.ml.random_seed,
                    'verbose': -1
                }
                import lightgbm as lgb
                model = lgb.LGBMClassifier(**params)

            elif model_type == 'lstm':
                # LSTM hyperparameters (these will be used to build the model)
                params = {
                    'lstm_units_1': trial.suggest_int('lstm_units_1', 32, 256),
                    'lstm_units_2': trial.suggest_int('lstm_units_2', 16, 128),
                    'dropout_rate': trial.suggest_float('dropout_rate', 0.1, 0.5),
                    'learning_rate': trial.suggest_float('learning_rate', 1e-4, 1e-2, log=True),
                    'batch_size': trial.suggest_categorical('batch_size', [16, 32, 64]),
                    'sequence_length': trial.suggest_int('sequence_length', 10, 30)
                }

                # For LSTM, we do a simple train/val split instead of CV
                split_idx = int(0.8 * len(X))
                X_train, X_val = X[:split_idx], X[split_idx:]
                y_train, y_val = y[:split_idx], y[split_idx:]

                lstm_agent = LSTMAgent(
                    config=self.config,
                    sequence_length=params['sequence_length'],
                    lstm_units=[params['lstm_units_1'], params['lstm_units_2']],
                    dropout_rate=params['dropout_rate'],
                    learning_rate=params['learning_rate']
                )

                lstm_agent.fit(
                    pd.DataFrame(X_train), pd.Series(y_train),
                    pd.DataFrame(X_val), pd.Series(y_val),
                    epochs=20,
                    batch_size=params['batch_size'],
                    verbose=0
                )

                val_probs = lstm_agent.predict_proba(pd.DataFrame(X_val))
                y_val_aligned = y_val[params['sequence_length']:]

                min_len = min(len(val_probs), len(y_val_aligned))
                score = roc_auc_score(y_val_aligned[:min_len], val_probs[:min_len])

                return score

            else:
                raise ValueError(f"Unknown model type: {model_type}")

            # Cross-validation for non-LSTM models
            try:
                scores = cross_val_score(
                    model, X, y,
                    cv=cv,
                    scoring=self.scoring,
                    n_jobs=-1
                )
                return scores.mean()
            except Exception as e:
                self.logger.warning(f"Trial failed: {e}")
                return 0.0

        return objective

    def optimize(
        self,
        model_type: str,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        n_trials: Optional[int] = None,
        timeout: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Optimize hyperparameters for a model.

        Args:
            model_type: Type of model to optimize
            X: Feature matrix
            y: Target variable
            n_trials: Number of trials (overrides default)
            timeout: Timeout in seconds (overrides default)

        Returns:
            Best hyperparameters
        """
        n_trials = n_trials or self.n_trials
        timeout = timeout or self.timeout

        self.logger.info(f"Optimizing {model_type} hyperparameters...")
        self.logger.info(f"  Trials: {n_trials}, Timeout: {timeout}s")

        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(y, pd.Series):
            y = y.values

        # Create study
        sampler = TPESampler(seed=self.config.ml.random_seed)
        pruner = MedianPruner(n_startup_trials=5, n_warmup_steps=10)

        self.study = optuna.create_study(
            direction='maximize',
            sampler=sampler,
            pruner=pruner
        )

        # Create objective
        objective = self._create_objective(model_type, X, y)

        # Optimize
        self.study.optimize(
            objective,
            n_trials=n_trials,
            timeout=timeout,
            show_progress_bar=True
        )

        # Store results
        self.best_params = self.study.best_params
        self.best_score = self.study.best_value

        self.logger.info(f"Best score: {self.best_score:.4f}")
        self.logger.info(f"Best params: {self.best_params}")

        return self.best_params

    def optimize_all_models(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        model_types: List[str] = None,
        n_trials_per_model: int = 20
    ) -> Dict[str, Dict[str, Any]]:
        """
        Optimize hyperparameters for multiple models.

        Args:
            X: Feature matrix
            y: Target variable
            model_types: List of model types to optimize
            n_trials_per_model: Trials per model

        Returns:
            Dictionary of best params per model
        """
        model_types = model_types or ['logistic_regression', 'random_forest', 'xgboost']

        all_params = {}

        for model_type in model_types:
            try:
                params = self.optimize(X, y, model_type, n_trials=n_trials_per_model)
                all_params[model_type] = {
                    'params': params,
                    'score': self.best_score
                }
            except Exception as e:
                self.logger.error(f"Failed to optimize {model_type}: {e}")
                all_params[model_type] = {'params': {}, 'score': 0.0}

        return all_params

    def get_optimization_history(self) -> pd.DataFrame:
        """Get optimization history as DataFrame."""
        if self.study is None:
            return pd.DataFrame()

        trials_data = []
        for trial in self.study.trials:
            trial_data = {
                'number': trial.number,
                'value': trial.value,
                'state': trial.state.name,
                **trial.params
            }
            trials_data.append(trial_data)

        return pd.DataFrame(trials_data)

    def run(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        model_type: str = 'xgboost',
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            X: Feature matrix
            y: Target variable
            model_type: Model type to optimize

        Returns:
            AgentResult with optimization results
        """
        def execute():
            best_params = self.optimize(model_type, X, y, **kwargs)

            return {
                'model_type': model_type,
                'best_params': best_params,
                'best_score': self.best_score,
                'n_trials': len(self.study.trials),
                'optimization_history': self.get_optimization_history()
            }

        return self._execute_with_timing(execute)


# Test Hyperparameter Agent
print("=" * 70)
print("🧪 TESTING HYPERPARAMETER OPTIMIZATION")
print("=" * 70)

if OPTUNA_AVAILABLE and 'X_train' in dir():
    hp_agent = HyperparameterAgent(
        config=config,
        n_trials=10,  # Reduced for demo
        cv_folds=3
    )

    print("\n⚡ Optimizing Random Forest hyperparameters...")
    hp_result = hp_agent.run(X_train, y_train, model_type='random_forest', n_trials=10)

    if hp_result.success:
        print(f"\n✅ Optimization completed!")
        print(f"   Best score: {hp_result.data['best_score']:.4f}")
        print(f"   Best params:")
        for param, value in hp_result.data['best_params'].items():
            print(f"      {param}: {value}")
    else:
        print(f"❌ Error: {hp_result.errors}")
else:
    print("⚠️ Optuna not available or sample data missing")

print("\n" + "=" * 70)
print("✅ Hyperparameter Agent ready!")