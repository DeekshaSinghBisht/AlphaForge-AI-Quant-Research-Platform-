"""
base.py
=======
Abstract base classes used by every agent:
  BaseAgent, MLAgent, DataAgent, AnalysisAgent
Type definitions and system-wide constants.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, List, Union
from dataclasses import dataclass, field
from datetime import datetime
import pandas as pd
import numpy as np
from enum import Enum

class AgentStatus(Enum):
    """Status of an agent."""
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING = "waiting"

@dataclass
class AgentResult:
    """
    Standard result container for agent operations.
    Ensures consistent output format across all agents.
    """
    success: bool
    data: Any = None
    message: str = ""
    errors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    execution_time: float = 0.0

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
        if self.errors is None:
            self.errors = []

class BaseAgent(ABC):
    """
    Abstract base class for all agents in the quantitative research system.

    All agents must inherit from this class and implement the required methods.
    This ensures consistent interfaces and behavior across the system.

    Attributes:
        name: Agent name for identification and logging
        config: System configuration
        logger: Logger instance
        status: Current agent status
    """

    def __init__(
        self,
        name: str,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        """
        Initialize base agent.

        Args:
            name: Agent name
            config: System configuration (uses global config if not provided)
            logger: Logger instance (creates new one if not provided)
        """
        self.name = name
        self.config = config or SystemConfig()
        self.logger = logger or QuantLogger(name)
        self.status = AgentStatus.IDLE
        self._results_cache: Dict[str, AgentResult] = {}
        self._initialized = False

        self.logger.info(f"Agent '{self.name}' created")

    @abstractmethod
    def run(self, *args, **kwargs) -> AgentResult:
        """
        Main execution method. Must be implemented by all agents.

        Returns:
            AgentResult containing the operation results
        """
        pass

    def initialize(self) -> bool:
        """
        Initialize the agent. Override in subclasses for setup logic.

        Returns:
            True if initialization successful
        """
        self._initialized = True
        self.logger.info(f"Agent '{self.name}' initialized")
        return True

    def validate_inputs(self, *args, **kwargs) -> Tuple[bool, List[str]]:
        """
        Validate input arguments. Override in subclasses.

        Returns:
            Tuple of (is_valid, list of error messages)
        """
        return True, []

    def _execute_with_timing(
        self,
        func: callable,
        *args,
        **kwargs
    ) -> AgentResult:
        """
        Execute a function with timing and error handling.

        Args:
            func: Function to execute
            *args: Positional arguments
            **kwargs: Keyword arguments

        Returns:
            AgentResult with execution details
        """
        start_time = datetime.now()
        self.status = AgentStatus.RUNNING

        try:
            result = func(*args, **kwargs)
            execution_time = (datetime.now() - start_time).total_seconds()

            self.status = AgentStatus.COMPLETED

            if isinstance(result, AgentResult):
                result.execution_time = execution_time
                return result

            return AgentResult(
                success=True,
                data=result,
                execution_time=execution_time,
                message=f"{self.name} completed successfully"
            )

        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            self.status = AgentStatus.FAILED
            self.logger.exception(f"Error in {self.name}: {str(e)}")

            return AgentResult(
                success=False,
                errors=[str(e)],
                execution_time=execution_time,
                message=f"{self.name} failed: {str(e)}"
            )

    def get_status(self) -> Dict[str, Any]:
        """Get current agent status."""
        return {
            'name': self.name,
            'status': self.status.value,
            'initialized': self._initialized,
            'cached_results': len(self._results_cache)
        }

    def reset(self) -> None:
        """Reset agent to initial state."""
        self._results_cache.clear()
        self.status = AgentStatus.IDLE
        self.logger.info(f"Agent '{self.name}' reset")

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name='{self.name}', status={self.status.value})"


class MLAgent(BaseAgent):
    """
    Base class for machine learning agents.
    Extends BaseAgent with ML-specific methods.
    """

    def __init__(
        self,
        name: str,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        super().__init__(name, config, logger)
        self.model = None
        self.is_fitted = False
        self.feature_names: List[str] = []

    @abstractmethod
    def fit(
        self,
        X: Union[pd.DataFrame, np.ndarray],
        y: Union[pd.Series, np.ndarray],
        **kwargs
    ) -> 'MLAgent':
        """
        Fit the model to training data.

        Args:
            X: Feature matrix
            y: Target variable
            **kwargs: Additional fitting parameters

        Returns:
            Self for method chaining
        """
        pass

    @abstractmethod
    def predict(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate predictions.

        Args:
            X: Feature matrix

        Returns:
            Predictions array
        """
        pass

    def predict_proba(
        self,
        X: Union[pd.DataFrame, np.ndarray]
    ) -> np.ndarray:
        """
        Generate probability predictions.

        Args:
            X: Feature matrix

        Returns:
            Probability array (default: call predict)
        """
        return self.predict(X)

    def save_model(self, path: Path) -> None:
        """Save model to file."""
        import joblib
        if self.model is not None:
            joblib.dump(self.model, path)
            self.logger.info(f"Model saved to {path}")

    def load_model(self, path: Path) -> None:
        """Load model from file."""
        import joblib
        if path.exists():
            self.model = joblib.load(path)
            self.is_fitted = True
            self.logger.info(f"Model loaded from {path}")

    def get_feature_importance(self) -> Optional[pd.Series]:
        """Get feature importance if available."""
        if not self.is_fitted or not hasattr(self.model, 'feature_importances_'):
            return None

        return pd.Series(
            self.model.feature_importances_,
            index=self.feature_names
        ).sort_values(ascending=False)


class DataAgent(BaseAgent):
    """
    Base class for data handling agents.
    Extends BaseAgent with data-specific methods.
    """

    def __init__(
        self,
        name: str,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        super().__init__(name, config, logger)
        self.data: Optional[pd.DataFrame] = None

    @abstractmethod
    def fetch(self, *args, **kwargs) -> pd.DataFrame:
        """
        Fetch data from source.

        Returns:
            DataFrame with fetched data
        """
        pass

    def validate_data(
        self,
        data: pd.DataFrame,
        required_columns: Optional[List[str]] = None
    ) -> Tuple[bool, List[str]]:
        """
        Validate fetched data.

        Args:
            data: DataFrame to validate
            required_columns: Required column names

        Returns:
            Tuple of (is_valid, error messages)
        """
        return validate_dataframe(data, required_columns)

    def preprocess(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Preprocess data. Override in subclasses.

        Args:
            data: Raw data

        Returns:
            Preprocessed data
        """
        return clean_dataframe(data)


class AnalysisAgent(BaseAgent):
    """
    Base class for analysis agents.
    Extends BaseAgent with analysis-specific methods.
    """

    def __init__(
        self,
        name: str,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        super().__init__(name, config, logger)
        self.analysis_results: Dict[str, Any] = {}

    @abstractmethod
    def analyze(self, data: pd.DataFrame, **kwargs) -> Dict[str, Any]:
        """
        Perform analysis on data.

        Args:
            data: Data to analyze
            **kwargs: Additional parameters

        Returns:
            Dictionary of analysis results
        """
        pass

    def generate_summary(self) -> str:
        """Generate text summary of analysis."""
        if not self.analysis_results:
            return "No analysis results available."

        summary_lines = [f"Analysis Summary for {self.name}:"]
        for key, value in self.analysis_results.items():
            summary_lines.append(f"  - {key}: {value}")

        return "\n".join(summary_lines)


# Test the base classes
print("Testing base agent classes...")

class TestAgent(BaseAgent):
    """Test implementation of BaseAgent."""

    def run(self, data: str = "test") -> AgentResult:
        return self._execute_with_timing(
            lambda: f"Processed: {data}"
        )

test_agent = TestAgent("TestAgent", config)
result = test_agent.run("hello")

print(f"✅ Test agent result: {result.data}")
print(f"✅ Agent status: {test_agent.get_status()}")

print("\n✅ Base agent classes ready!")


from typing import (
    TypeVar, Generic, Union, List, Dict, Tuple, Optional,
    Any, Callable, Iterator, Sequence
)
from typing_extensions import TypedDict, Literal
import numpy as np
import pandas as pd
from enum import Enum, auto
from dataclasses import dataclass

# ============================================================================
# TYPE ALIASES
# ============================================================================

# Data types
ArrayLike = Union[np.ndarray, pd.Series, List[float]]
DataFrameLike = Union[pd.DataFrame, np.ndarray]
DateLike = Union[str, pd.Timestamp, datetime]

# ML types
Features = Union[pd.DataFrame, np.ndarray]
Target = Union[pd.Series, np.ndarray]
Predictions = np.ndarray
Probabilities = np.ndarray

# Trading types
Signal = Literal[-1, 0, 1]
Signals = Union[pd.Series, np.ndarray]
Price = float
Volume = int
Position = float
Weight = float

# ============================================================================
# TYPED DICTIONARIES
# ============================================================================

class OHLCVData(TypedDict):
    """Type definition for OHLCV data."""
    Open: pd.Series
    High: pd.Series
    Low: pd.Series
    Close: pd.Series
    Volume: pd.Series
    Date: pd.DatetimeIndex

class TradeRecord(TypedDict):
    """Type definition for a trade record."""
    timestamp: pd.Timestamp
    ticker: str
    action: Literal['BUY', 'SELL', 'HOLD']
    price: float
    shares: int
    value: float
    commission: float
    slippage: float

class PerformanceMetrics(TypedDict):
    """Type definition for performance metrics."""
    total_return: float
    cagr: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    max_drawdown: float
    volatility: float
    win_rate: float

class RiskMetrics(TypedDict):
    """Type definition for risk metrics."""
    var_95: float
    var_99: float
    cvar_95: float
    cvar_99: float
    max_drawdown: float
    max_drawdown_duration: int
    beta: float

# ============================================================================
# ENUMERATIONS
# ============================================================================

class TimeFrame(Enum):
    """Trading timeframes."""
    MINUTE_1 = "1m"
    MINUTE_5 = "5m"
    MINUTE_15 = "15m"
    MINUTE_30 = "30m"
    HOUR_1 = "1h"
    HOUR_4 = "4h"
    DAILY = "1d"
    WEEKLY = "1wk"
    MONTHLY = "1mo"

class OrderType(Enum):
    """Order types."""
    MARKET = auto()
    LIMIT = auto()
    STOP = auto()
    STOP_LIMIT = auto()

class PositionSide(Enum):
    """Position sides."""
    LONG = 1
    SHORT = -1
    FLAT = 0

class OptimizationObjective(Enum):
    """Portfolio optimization objectives."""
    MAX_SHARPE = "max_sharpe"
    MIN_VARIANCE = "min_variance"
    MAX_RETURN = "max_return"
    RISK_PARITY = "risk_parity"
    MIN_CVAR = "min_cvar"

# ============================================================================
# CONSTANTS
# ============================================================================

class TradingConstants:
    """Constants related to trading and markets."""

    # Trading days
    TRADING_DAYS_PER_YEAR: int = 252
    TRADING_DAYS_PER_MONTH: int = 21
    TRADING_DAYS_PER_WEEK: int = 5

    # Time periods
    SECONDS_PER_DAY: int = 86400
    MINUTES_PER_DAY: int = 1440
    HOURS_PER_DAY: int = 24

    # Market hours (US Eastern)
    MARKET_OPEN_HOUR: int = 9
    MARKET_OPEN_MINUTE: int = 30
    MARKET_CLOSE_HOUR: int = 16
    MARKET_CLOSE_MINUTE: int = 0

class FeatureConstants:
    """Constants for feature engineering."""

    # Default periods
    DEFAULT_MA_PERIODS: List[int] = [5, 10, 20, 50, 100, 200]
    DEFAULT_RSI_PERIOD: int = 14
    DEFAULT_MACD_FAST: int = 12
    DEFAULT_MACD_SLOW: int = 26
    DEFAULT_MACD_SIGNAL: int = 9
    DEFAULT_BB_PERIOD: int = 20
    DEFAULT_BB_STD: float = 2.0
    DEFAULT_ATR_PERIOD: int = 14

    # RSI thresholds
    RSI_OVERBOUGHT: float = 70.0
    RSI_OVERSOLD: float = 30.0

class MLConstants:
    """Constants for machine learning."""

    # Default splits
    DEFAULT_TRAIN_RATIO: float = 0.7
    DEFAULT_VAL_RATIO: float = 0.15
    DEFAULT_TEST_RATIO: float = 0.15

    # LSTM defaults
    DEFAULT_SEQUENCE_LENGTH: int = 20
    DEFAULT_LSTM_UNITS: List[int] = [128, 64]
    DEFAULT_DROPOUT: float = 0.3

    # Training defaults
    DEFAULT_EPOCHS: int = 100
    DEFAULT_BATCH_SIZE: int = 32
    DEFAULT_LEARNING_RATE: float = 0.001
    DEFAULT_EARLY_STOPPING_PATIENCE: int = 10

class RiskConstants:
    """Constants for risk management."""

    # VaR/CVaR
    DEFAULT_VAR_CONFIDENCE: float = 0.95
    DEFAULT_VAR_CONFIDENCE_HIGH: float = 0.99

    # Position limits
    DEFAULT_MAX_POSITION_PCT: float = 0.20
    DEFAULT_MIN_POSITION_PCT: float = 0.02

    # Risk limits
    DEFAULT_MAX_DRAWDOWN: float = 0.15
    DEFAULT_STOP_LOSS: float = 0.05
    DEFAULT_TAKE_PROFIT: float = 0.10

    # Transaction costs
    DEFAULT_COMMISSION: float = 0.001
    DEFAULT_SLIPPAGE: float = 0.0005
    DEFAULT_MARKET_IMPACT_K: float = 0.1

class StatisticalConstants:
    """Constants for statistical analysis."""

    # Confidence levels
    CONFIDENCE_90: float = 0.90
    CONFIDENCE_95: float = 0.95
    CONFIDENCE_99: float = 0.99

    # P-value thresholds
    PVALUE_THRESHOLD: float = 0.05
    PVALUE_THRESHOLD_STRICT: float = 0.01

    # Bootstrap
    DEFAULT_BOOTSTRAP_SAMPLES: int = 10000

    # Monte Carlo
    DEFAULT_MC_SIMULATIONS: int = 10000

# ============================================================================
# TICKER UNIVERSES
# ============================================================================

class TickerUniverse:
    """Predefined ticker universes."""

    # Default research universe
    DEFAULT: List[str] = ["AAPL", "MSFT", "TSLA", "NVDA", "GOOGL", "AMZN"]

    # Tech stocks
    TECH: List[str] = [
        "AAPL", "MSFT", "GOOGL", "AMZN", "META", "NVDA",
        "TSLA", "AMD", "INTC", "CRM"
    ]

    # Financial stocks
    FINANCIALS: List[str] = [
        "JPM", "BAC", "WFC", "GS", "MS", "C",
        "BLK", "SCHW", "AXP", "V"
    ]

    # Healthcare stocks
    HEALTHCARE: List[str] = [
        "JNJ", "UNH", "PFE", "ABBV", "MRK", "TMO",
        "ABT", "DHR", "BMY", "LLY"
    ]

    # ETF benchmarks
    ETF_BENCHMARKS: List[str] = [
        "SPY", "QQQ", "IWM", "DIA", "VTI", "VOO"
    ]

    # Sector ETFs
    SECTOR_ETFS: List[str] = [
        "XLK", "XLF", "XLV", "XLE", "XLI", "XLP",
        "XLY", "XLU", "XLB", "XLRE"
    ]

# ============================================================================
# VALIDATION
# ============================================================================

@dataclass
class ValidationResult:
    """Result of a validation check."""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return self.is_valid


def validate_ticker(ticker: str) -> ValidationResult:
    """Validate a ticker symbol."""
    errors = []
    warnings = []

    if not ticker:
        errors.append("Ticker cannot be empty")
    elif not ticker.isalpha():
        errors.append(f"Invalid ticker format: {ticker}")
    elif len(ticker) > 5:
        warnings.append(f"Unusual ticker length: {ticker}")

    return ValidationResult(
        is_valid=len(errors) == 0,
        errors=errors,
        warnings=warnings
    )


def validate_date_range(
    start_date: str,
    end_date: str
) -> ValidationResult:
    """Validate a date range."""
    errors = []

    try:
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)

        if start >= end:
            errors.append("Start date must be before end date")

        if end > pd.Timestamp.now():
            errors.append("End date cannot be in the future")

    except Exception as e:
        errors.append(f"Invalid date format: {e}")

    return ValidationResult(
        is_valid=len(errors) == 0,
        errors=errors
    )


# Print summary
print("=" * 70)
print("📋 TYPE DEFINITIONS & CONSTANTS LOADED")
print("=" * 70)
print(f"Trading days per year: {TradingConstants.TRADING_DAYS_PER_YEAR}")
print(f"Default tickers: {TickerUniverse.DEFAULT}")
print(f"Default MA periods: {FeatureConstants.DEFAULT_MA_PERIODS}")
print(f"Default VaR confidence: {RiskConstants.DEFAULT_VAR_CONFIDENCE}")
print("=" * 70)

print("\n✅ Type definitions and constants ready!")