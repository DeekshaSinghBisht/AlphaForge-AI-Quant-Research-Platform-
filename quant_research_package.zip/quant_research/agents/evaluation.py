"""
evaluation.py
=============
StrategyEvaluationAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import Dict, Optional, Any, List, Tuple, Union
from scipy import stats
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class StatisticalTestResult:
    """Data class for statistical test results."""
    test_name: str
    statistic: float
    p_value: float
    significant: bool
    interpretation: str


class StrategyEvaluationAgent(AnalysisAgent):
    """
    Agent for rigorous statistical evaluation of trading strategies.

    Features:
    - Statistical significance tests
    - Bootstrap confidence intervals
    - Multiple hypothesis correction
    - Deflated Sharpe Ratio
    - Robustness testing

    Attributes:
        test_results: List of statistical test results
        confidence_intervals: Confidence intervals for metrics
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        significance_level: float = 0.05
    ):
        """
        Initialize Strategy Evaluation Agent.

        Args:
            config: System configuration
            logger: Logger instance
            significance_level: Significance level for tests
        """
        super().__init__("StrategyEvaluationAgent", config, logger)

        self.significance_level = significance_level
        self.test_results: List[StatisticalTestResult] = []
        self.confidence_intervals: Dict[str, Tuple[float, float]] = {}

    def t_test_returns(
        self,
        returns: pd.Series,
        null_mean: float = 0.0
    ) -> StatisticalTestResult:
        """
        T-test for mean returns.

        H0: mean return = null_mean

        Args:
            returns: Strategy returns
            null_mean: Null hypothesis mean

        Returns:
            StatisticalTestResult
        """
        returns = returns.dropna()
        t_stat, p_value = stats.ttest_1samp(returns, null_mean)

        significant = p_value < self.significance_level

        interpretation = (
            f"Mean return is {'significantly' if significant else 'not significantly'} "
            f"different from {null_mean} (p={p_value:.4f})"
        )

        return StatisticalTestResult(
            test_name="One-Sample T-Test",
            statistic=t_stat,
            p_value=p_value,
            significant=significant,
            interpretation=interpretation
        )

    def mann_whitney_test(
        self,
        strategy_returns: pd.Series,
        benchmark_returns: pd.Series
    ) -> StatisticalTestResult:
        """
        Mann-Whitney U test comparing strategy to benchmark.

        Non-parametric test for comparing distributions.

        Args:
            strategy_returns: Strategy returns
            benchmark_returns: Benchmark returns

        Returns:
            StatisticalTestResult
        """
        # Align returns
        aligned_strategy, aligned_benchmark = strategy_returns.align(benchmark_returns, join='inner')
        aligned_strategy = aligned_strategy.dropna()
        aligned_benchmark = aligned_benchmark.dropna()

        u_stat, p_value = stats.mannwhitneyu(
            aligned_strategy, aligned_benchmark, alternative='two-sided'
        )

        significant = p_value < self.significance_level

        interpretation = (
            f"Strategy returns are {'significantly' if significant else 'not significantly'} "
            f"different from benchmark (p={p_value:.4f})"
        )

        return StatisticalTestResult(
            test_name="Mann-Whitney U Test",
            statistic=u_stat,
            p_value=p_value,
            significant=significant,
            interpretation=interpretation
        )

    def wilcoxon_test(
        self,
        strategy_returns: pd.Series,
        benchmark_returns: pd.Series
    ) -> StatisticalTestResult:
        """
        Wilcoxon signed-rank test for paired samples.

        Args:
            strategy_returns: Strategy returns
            benchmark_returns: Benchmark returns

        Returns:
            StatisticalTestResult
        """
        aligned_strategy, aligned_benchmark = strategy_returns.align(benchmark_returns, join='inner')
        aligned_strategy = aligned_strategy.dropna()
        aligned_benchmark = aligned_benchmark.dropna()

        differences = aligned_strategy - aligned_benchmark
        differences = differences[differences != 0]  # Remove zeros

        if len(differences) < 10:
            return StatisticalTestResult(
                test_name="Wilcoxon Signed-Rank Test",
                statistic=0,
                p_value=1.0,
                significant=False,
                interpretation="Insufficient non-zero differences for test"
            )

        w_stat, p_value = stats.wilcoxon(differences)

        significant = p_value < self.significance_level

        interpretation = (
            f"Strategy {'significantly' if significant else 'does not significantly'} "
            f"outperform benchmark (p={p_value:.4f})"
        )

        return StatisticalTestResult(
            test_name="Wilcoxon Signed-Rank Test",
            statistic=w_stat,
            p_value=p_value,
            significant=significant,
            interpretation=interpretation
        )

    def bootstrap_sharpe_ci(
        self,
        returns: pd.Series,
        n_bootstrap: int = 10000,
        confidence: float = 0.95
    ) -> Tuple[float, float, float]:
        """
        Bootstrap confidence interval for Sharpe ratio.

        Args:
            returns: Strategy returns
            n_bootstrap: Number of bootstrap samples
            confidence: Confidence level

        Returns:
            Tuple of (sharpe, lower_ci, upper_ci)
        """
        returns = returns.dropna().values
        n = len(returns)

        bootstrap_sharpes = np.zeros(n_bootstrap)

        for i in range(n_bootstrap):
            sample = np.random.choice(returns, size=n, replace=True)
            if sample.std() > 0:
                bootstrap_sharpes[i] = np.sqrt(252) * sample.mean() / sample.std()
            else:
                bootstrap_sharpes[i] = 0

        # Original Sharpe
        sharpe = np.sqrt(252) * returns.mean() / returns.std() if returns.std() > 0 else 0

        # Confidence interval
        alpha = 1 - confidence
        lower = np.percentile(bootstrap_sharpes, alpha / 2 * 100)
        upper = np.percentile(bootstrap_sharpes, (1 - alpha / 2) * 100)

        self.confidence_intervals['sharpe_ratio'] = (lower, upper)

        return sharpe, lower, upper

    def bootstrap_max_drawdown_ci(
        self,
        returns: pd.Series,
        n_bootstrap: int = 10000,
        confidence: float = 0.95
    ) -> Tuple[float, float, float]:
        """
        Bootstrap confidence interval for maximum drawdown.

        Args:
            returns: Strategy returns
            n_bootstrap: Number of bootstrap samples
            confidence: Confidence level

        Returns:
            Tuple of (max_dd, lower_ci, upper_ci)
        """
        returns = returns.dropna().values
        n = len(returns)

        def calc_max_dd(rets):
            equity = np.cumprod(1 + rets)
            running_max = np.maximum.accumulate(equity)
            drawdown = (equity - running_max) / running_max
            return abs(drawdown.min())

        bootstrap_mdd = np.zeros(n_bootstrap)

        for i in range(n_bootstrap):
            sample = np.random.choice(returns, size=n, replace=True)
            bootstrap_mdd[i] = calc_max_dd(sample)

        # Original max drawdown
        max_dd = calc_max_dd(returns)

        # Confidence interval
        alpha = 1 - confidence
        lower = np.percentile(bootstrap_mdd, alpha / 2 * 100)
        upper = np.percentile(bootstrap_mdd, (1 - alpha / 2) * 100)

        self.confidence_intervals['max_drawdown'] = (lower, upper)

        return max_dd, lower, upper

    def bonferroni_correction(
        self,
        p_values: List[float]
    ) -> List[Tuple[float, bool]]:
        """
        Apply Bonferroni correction for multiple testing.

        Args:
            p_values: List of p-values

        Returns:
            List of (adjusted_p_value, significant) tuples
        """
        n_tests = len(p_values)
        adjusted_alpha = self.significance_level / n_tests

        results = []
        for p in p_values:
            adjusted_p = min(p * n_tests, 1.0)
            significant = adjusted_p < self.significance_level
            results.append((adjusted_p, significant))

        return results

    def benjamini_hochberg_correction(
        self,
        p_values: List[float]
    ) -> List[Tuple[float, bool]]:
        """
        Apply Benjamini-Hochberg FDR correction.

        Args:
            p_values: List of p-values

        Returns:
            List of (adjusted_p_value, significant) tuples
        """
        n_tests = len(p_values)
        sorted_indices = np.argsort(p_values)
        sorted_p_values = np.array(p_values)[sorted_indices]

        # Benjamini-Hochberg procedure
        adjusted_p = np.zeros(n_tests)
        for i in range(n_tests):
            adjusted_p[i] = sorted_p_values[i] * n_tests / (i + 1)

        # Ensure monotonicity
        for i in range(n_tests - 2, -1, -1):
            adjusted_p[i] = min(adjusted_p[i], adjusted_p[i + 1])

        # Map back to original order
        results = [(0.0, False)] * n_tests
        for i, orig_idx in enumerate(sorted_indices):
            adj_p = min(adjusted_p[i], 1.0)
            results[orig_idx] = (adj_p, adj_p < self.significance_level)

        return results

    def calculate_deflated_sharpe_ratio(
        self,
        sharpe_ratio: float,
        n_trials: int,
        variance_sharpe: float = 1.0,
        skewness: float = 0.0,
        kurtosis: float = 3.0
    ) -> Tuple[float, float]:
        """
        Calculate Deflated Sharpe Ratio (DSR).

        Accounts for multiple testing and non-normality.

        Args:
            sharpe_ratio: Observed Sharpe ratio
            n_trials: Number of trials/strategies tested
            variance_sharpe: Variance of Sharpe ratio
            skewness: Skewness of returns
            kurtosis: Kurtosis of returns

        Returns:
            Tuple of (deflated_sharpe, p_value)
        """
        # Expected maximum Sharpe under null (Bailey & Lopez de Prado)
        if n_trials > 1:
            euler_gamma = 0.5772156649
            expected_max_sharpe = (
                (1 - euler_gamma) * stats.norm.ppf(1 - 1/n_trials) +
                euler_gamma * stats.norm.ppf(1 - 1/(n_trials * np.e))
            )
        else:
            expected_max_sharpe = 0

        # Variance adjustment for non-normality
        var_adjustment = 1 + (skewness * sharpe_ratio) / 6 + ((kurtosis - 3) * sharpe_ratio**2) / 24
        adjusted_variance = variance_sharpe * var_adjustment

        # Deflated Sharpe Ratio
        dsr = (sharpe_ratio - expected_max_sharpe) / np.sqrt(adjusted_variance)

        # P-value
        p_value = 1 - stats.norm.cdf(dsr)

        return dsr, p_value

    def parameter_perturbation_test(
        self,
        returns: pd.Series,
        signals: pd.Series,
        perturbation_pct: float = 0.1,
        n_perturbations: int = 100
    ) -> Dict[str, Any]:
        """
        Test strategy robustness to parameter perturbation.

        Args:
            returns: Price returns
            signals: Original signals
            perturbation_pct: Perturbation percentage
            n_perturbations: Number of perturbations

        Returns:
            Perturbation analysis results
        """
        self.logger.info(f"Running parameter perturbation test ({n_perturbations} trials)...")

        # Calculate original Sharpe
        strategy_returns = signals.shift(1) * returns
        strategy_returns = strategy_returns.dropna()
        original_sharpe = calculate_sharpe_ratio(strategy_returns)

        perturbed_sharpes = []

        for _ in range(n_perturbations):
            # Perturb signals
            noise = np.random.uniform(-perturbation_pct, perturbation_pct, len(signals))
            perturbed_signals = signals * (1 + noise)
            perturbed_signals = perturbed_signals.clip(-1, 1)

            # Calculate perturbed Sharpe
            perturbed_returns = perturbed_signals.shift(1) * returns
            perturbed_returns = perturbed_returns.dropna()

            if len(perturbed_returns) > 10 and perturbed_returns.std() > 0:
                sharpe = calculate_sharpe_ratio(perturbed_returns)
                perturbed_sharpes.append(sharpe)

        perturbed_sharpes = np.array(perturbed_sharpes)

        return {
            'original_sharpe': original_sharpe,
            'mean_perturbed_sharpe': np.mean(perturbed_sharpes),
            'std_perturbed_sharpe': np.std(perturbed_sharpes),
            'min_perturbed_sharpe': np.min(perturbed_sharpes),
            'max_perturbed_sharpe': np.max(perturbed_sharpes),
            'degradation_pct': (original_sharpe - np.mean(perturbed_sharpes)) / abs(original_sharpe) * 100 if original_sharpe != 0 else 0,
            'robustness_score': np.mean(perturbed_sharpes > 0)  # % of positive Sharpes
        }

    def slippage_sensitivity_analysis(
        self,
        returns: pd.Series,
        signals: pd.Series,
        slippage_levels: List[float] = None
    ) -> pd.DataFrame:
        """
        Analyze sensitivity to slippage.

        Args:
            returns: Price returns
            signals: Trading signals
            slippage_levels: Slippage levels to test

        Returns:
            DataFrame with sensitivity analysis
        """
        slippage_levels = slippage_levels or [0, 0.0005, 0.001, 0.002, 0.005, 0.01]

        results = []

        for slippage in slippage_levels:
            # Calculate returns with slippage
            position_changes = signals.diff().abs()
            slippage_cost = position_changes * slippage

            strategy_returns = signals.shift(1) * returns - slippage_cost.shift(1)
            strategy_returns = strategy_returns.dropna()

            if len(strategy_returns) > 10 and strategy_returns.std() > 0:
                sharpe = calculate_sharpe_ratio(strategy_returns)
                total_return = (1 + strategy_returns).prod() - 1
            else:
                sharpe = 0
                total_return = 0

            results.append({
                'slippage': slippage,
                'slippage_bps': slippage * 10000,
                'sharpe_ratio': sharpe,
                'total_return': total_return
            })

        df = pd.DataFrame(results)

        # Find breakeven slippage
        positive_sharpe = df[df['sharpe_ratio'] > 0]
        breakeven = positive_sharpe['slippage'].max() if len(positive_sharpe) > 0 else 0

        return df

    def run_all_tests(
        self,
        strategy_returns: pd.Series,
        benchmark_returns: Optional[pd.Series] = None
    ) -> List[StatisticalTestResult]:
        """
        Run all statistical tests.

        Args:
            strategy_returns: Strategy returns
            benchmark_returns: Benchmark returns

        Returns:
            List of test results
        """
        results = []

        # T-test for mean returns
        results.append(self.t_test_returns(strategy_returns))

        # Tests against benchmark
        if benchmark_returns is not None:
            results.append(self.mann_whitney_test(strategy_returns, benchmark_returns))
            results.append(self.wilcoxon_test(strategy_returns, benchmark_returns))

        self.test_results = results
        return results

    def analyze(
        self,
        data: pd.DataFrame,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Perform comprehensive statistical analysis.

        Args:
            data: DataFrame with returns

        Returns:
            Analysis results
        """
        if 'returns' in data.columns:
            returns = data['returns']
        else:
            returns = data.iloc[:, 0]

        # Run tests
        self.run_all_tests(returns, kwargs.get('benchmark_returns'))

        # Bootstrap CIs
        sharpe, sharpe_lower, sharpe_upper = self.bootstrap_sharpe_ci(returns)

        self.analysis_results = {
            'n_tests': len(self.test_results),
            'significant_tests': sum(1 for t in self.test_results if t.significant),
            'sharpe_ci': (sharpe_lower, sharpe_upper)
        }

        return self.analysis_results

    def run(
        self,
        strategy_returns: pd.Series,
        benchmark_returns: Optional[pd.Series] = None,
        signals: Optional[pd.Series] = None,
        price_returns: Optional[pd.Series] = None,
        n_trials: int = 1,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            strategy_returns: Strategy returns
            benchmark_returns: Benchmark returns
            signals: Trading signals (for robustness tests)
            price_returns: Underlying price returns
            n_trials: Number of strategy variants tested

        Returns:
            AgentResult with evaluation results
        """
        def execute():
            # Statistical tests
            test_results = self.run_all_tests(strategy_returns, benchmark_returns)

            # Bootstrap confidence intervals
            sharpe, sharpe_lower, sharpe_upper = self.bootstrap_sharpe_ci(strategy_returns)
            max_dd, dd_lower, dd_upper = self.bootstrap_max_drawdown_ci(strategy_returns)

            # Deflated Sharpe Ratio
            skew = strategy_returns.skew()
            kurt = strategy_returns.kurtosis()
            dsr, dsr_pvalue = self.calculate_deflated_sharpe_ratio(
                sharpe, n_trials,
                variance_sharpe=1.0,
                skewness=skew,
                kurtosis=kurt
            )

            # Robustness tests
            robustness_results = None
            slippage_results = None

            if signals is not None and price_returns is not None:
                robustness_results = self.parameter_perturbation_test(
                    price_returns, signals
                )
                slippage_results = self.slippage_sensitivity_analysis(
                    price_returns, signals
                )

            # Multiple testing correction
            p_values = [t.p_value for t in test_results]
            bonferroni = self.bonferroni_correction(p_values)
            bh = self.benjamini_hochberg_correction(p_values)

            return {
                'test_results': test_results,
                'sharpe_ratio': sharpe,
                'sharpe_ci_95': (sharpe_lower, sharpe_upper),
                'max_drawdown': max_dd,
                'max_dd_ci_95': (dd_lower, dd_upper),
                'deflated_sharpe': dsr,
                'dsr_pvalue': dsr_pvalue,
                'robustness_results': robustness_results,
                'slippage_analysis': slippage_results,
                'bonferroni_correction': bonferroni,
                'benjamini_hochberg_correction': bh,
                'skewness': skew,
                'kurtosis': kurt
            }

        return self._execute_with_timing(execute)


# Test Strategy Evaluation Agent
print("=" * 70)
print("🧪 TESTING STRATEGY EVALUATION")
print("=" * 70)

# Generate sample strategy and benchmark returns
np.random.seed(42)
n = 500
dates = pd.date_range(start='2021-01-01', periods=n, freq='D')

# Strategy returns (slightly positive mean)
strategy_rets = pd.Series(
    np.random.randn(n) * 0.015 + 0.0003,
    index=dates
)

# Benchmark returns
benchmark_rets = pd.Series(
    np.random.randn(n) * 0.012 + 0.0002,
    index=dates
)

# Sample signals for robustness tests
sample_signals = pd.Series(
    np.random.choice([-1, 0, 1], n, p=[0.2, 0.5, 0.3]),
    index=dates
)

# Test Strategy Evaluation
eval_agent = StrategyEvaluationAgent(config=config)
eval_result = eval_agent.run(
    strategy_rets,
    benchmark_returns=benchmark_rets,
    signals=sample_signals,
    price_returns=benchmark_rets,
    n_trials=10
)

if eval_result.success:
    print(f"\n✅ Strategy evaluation completed!")

    print(f"\n📊 Sharpe Ratio Analysis:")
    print(f"   Sharpe Ratio: {eval_result.data['sharpe_ratio']:.4f}")
    print(f"   95% CI: [{eval_result.data['sharpe_ci_95'][0]:.4f}, {eval_result.data['sharpe_ci_95'][1]:.4f}]")
    print(f"   Deflated Sharpe: {eval_result.data['deflated_sharpe']:.4f}")
    print(f"   DSR p-value: {eval_result.data['dsr_pvalue']:.4f}")

    print(f"\n📈 Statistical Tests:")
    for test in eval_result.data['test_results']:
        sig = "✅" if test.significant else "❌"
        print(f"   {sig} {test.test_name}: p={test.p_value:.4f}")

    if eval_result.data['robustness_results']:
        rob = eval_result.data['robustness_results']
        print(f"\n🔧 Robustness Analysis:")
        print(f"   Original Sharpe: {rob['original_sharpe']:.4f}")
        print(f"   Mean Perturbed: {rob['mean_perturbed_sharpe']:.4f}")
        print(f"   Robustness Score: {rob['robustness_score']*100:.1f}%")

    if eval_result.data['slippage_analysis'] is not None:
        slip = eval_result.data['slippage_analysis']
        print(f"\n💰 Slippage Sensitivity:")
        for _, row in slip.iterrows():
            print(f"   {row['slippage_bps']:.0f} bps: Sharpe={row['sharpe_ratio']:.4f}")
else:
    print(f"❌ Error: {eval_result.errors}")

print("\n" + "=" * 70)
print("✅ Strategy Evaluation Agent ready!")