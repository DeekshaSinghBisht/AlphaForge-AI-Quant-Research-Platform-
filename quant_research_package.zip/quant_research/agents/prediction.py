"""
prediction.py
=============
WalkForwardValidator + PredictionAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import numpy as np
import pandas as pd
from typing import List, Dict, Optional, Tuple, Generator, Any
from dataclasses import dataclass
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


@dataclass
class WalkForwardSplit:
    """Data class for a single walk-forward split."""
    fold: int
    train_start: datetime
    train_end: datetime
    val_start: datetime
    val_end: datetime
    test_start: datetime
    test_end: datetime
    train_idx: np.ndarray
    val_idx: np.ndarray
    test_idx: np.ndarray


class WalkForwardValidator:
    """
    Walk-forward validation for time series data.

    Implements expanding window and rolling window approaches
    with proper gaps to prevent look-ahead bias.

    Attributes:
        n_splits: Number of walk-forward splits
        train_size: Minimum training window size
        val_size: Validation window size
        test_size: Test window size
        gap: Gap between train and test to prevent leakage
    """

    def __init__(
        self,
        n_splits: int = 5,
        min_train_size: int = 252,
        val_size: int = 63,
        test_size: int = 21,
        gap: int = 1,
        expanding: bool = True
    ):
        """
        Initialize Walk-Forward Validator.

        Args:
            n_splits: Number of walk-forward splits
            min_train_size: Minimum training window (days)
            val_size: Validation window (days)
            test_size: Test window (days)
            gap: Gap between windows (days)
            expanding: Whether to use expanding (True) or rolling (False) window
        """
        self.n_splits = n_splits
        self.min_train_size = min_train_size
        self.val_size = val_size
        self.test_size = test_size
        self.gap = gap
        self.expanding = expanding

    def split(
        self,
        X: pd.DataFrame,
        y: Optional[pd.Series] = None
    ) -> Generator[WalkForwardSplit, None, None]:
        """
        Generate walk-forward splits.

        Args:
            X: Feature DataFrame with DatetimeIndex
            y: Target Series (optional)

        Yields:
            WalkForwardSplit objects
        """
        n_samples = len(X)
        indices = np.arange(n_samples)

        # Calculate total size needed per split
        split_size = self.val_size + self.test_size + self.gap

        # Calculate available space for splits after minimum training
        available = n_samples - self.min_train_size - split_size

        if available < split_size * (self.n_splits - 1):
            # Adjust number of splits if not enough data
            self.n_splits = max(1, available // split_size + 1)

        # Calculate step size between splits
        step = available // self.n_splits if self.n_splits > 1 else available

        for fold in range(self.n_splits):
            # Calculate split boundaries
            if self.expanding:
                train_start = 0
            else:
                train_start = fold * step

            train_end = self.min_train_size + fold * step
            val_start = train_end + self.gap
            val_end = val_start + self.val_size
            test_start = val_end + self.gap
            test_end = min(test_start + self.test_size, n_samples)

            # Skip if not enough data
            if test_end > n_samples or val_end > n_samples:
                continue

            # Create index arrays
            train_idx = indices[train_start:train_end]
            val_idx = indices[val_start:val_end]
            test_idx = indices[test_start:test_end]

            # Get dates if available
            if isinstance(X.index, pd.DatetimeIndex):
                dates = X.index
                split = WalkForwardSplit(
                    fold=fold,
                    train_start=dates[train_start],
                    train_end=dates[train_end - 1],
                    val_start=dates[val_start],
                    val_end=dates[val_end - 1],
                    test_start=dates[test_start],
                    test_end=dates[test_end - 1],
                    train_idx=train_idx,
                    val_idx=val_idx,
                    test_idx=test_idx
                )
            else:
                split = WalkForwardSplit(
                    fold=fold,
                    train_start=train_start,
                    train_end=train_end,
                    val_start=val_start,
                    val_end=val_end,
                    test_start=test_start,
                    test_end=test_end,
                    train_idx=train_idx,
                    val_idx=val_idx,
                    test_idx=test_idx
                )

            yield split

    def get_n_splits(self) -> int:
        """Get number of splits."""
        return self.n_splits


class PredictionAgent(BaseAgent):
    """
    Agent responsible for training ML models using walk-forward validation.

    Coordinates training of multiple models with proper time-series
    cross-validation and generates predictions for each fold.

    Attributes:
        models: Dictionary of trained models
        predictions: Dictionary of out-of-sample predictions
        metrics: Performance metrics per fold
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        """Initialize Prediction Agent."""
        super().__init__("PredictionAgent", config, logger)

        self.validator = WalkForwardValidator(
            n_splits=self.config.ml.n_splits,
            min_train_size=self.config.ml.min_train_size,
            val_size=63,  # ~3 months
            test_size=21,  # ~1 month
            gap=self.config.ml.gap_days,
            expanding=True
        )

        self.models: Dict[str, List[Any]] = {}
        self.predictions: Dict[str, pd.Series] = {}
        self.metrics: List[Dict[str, Any]] = []
        self.fold_results: List[Dict[str, Any]] = []

    def train_walk_forward(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        model_configs: Dict[str, Dict[str, Any]] = None
    ) -> Dict[str, pd.Series]:
        """
        Train models using walk-forward validation.

        Args:
            X: Feature DataFrame
            y: Target Series
            model_configs: Model configurations

        Returns:
            Dictionary of out-of-sample predictions per model
        """
        self.logger.info("Starting walk-forward training...")

        # Default model configurations
        if model_configs is None:
            model_configs = {
                'logistic_regression': {},
                'random_forest': {'n_estimators': 100},
                'xgboost': {'n_estimators': 100}
            }

        # Initialize prediction storage
        all_predictions = {name: pd.Series(dtype=float) for name in model_configs}
        all_probabilities = {name: pd.Series(dtype=float) for name in model_configs}

        # Walk-forward loop
        for split in self.validator.split(X, y):
            self.logger.info(f"\nFold {split.fold + 1}/{self.validator.n_splits}")
            self.logger.info(f"  Train: {len(split.train_idx)} samples")
            self.logger.info(f"  Val: {len(split.val_idx)} samples")
            self.logger.info(f"  Test: {len(split.test_idx)} samples")

            # Extract data for this fold
            X_train = X.iloc[split.train_idx]
            y_train = y.iloc[split.train_idx]
            X_val = X.iloc[split.val_idx]
            y_val = y.iloc[split.val_idx]
            X_test = X.iloc[split.test_idx]
            y_test = y.iloc[split.test_idx]

            fold_metrics = {'fold': split.fold}

            # Train each model
            for model_name, model_params in model_configs.items():
                try:
                    # Create model
                    if model_name == 'logistic_regression':
                        model = LogisticRegressionAgent(config=self.config, **model_params)
                    elif model_name == 'random_forest':
                        model = RandomForestAgent(config=self.config, **model_params)
                    elif model_name == 'xgboost' and XGBOOST_AVAILABLE:
                        model = XGBoostAgent(config=self.config, **model_params)
                    else:
                        continue

                    # Train model
                    model.fit(X_train, y_train)

                    # Predict on test set
                    test_probs = model.predict_proba(X_test)
                    test_preds = model.predict(X_test)

                    # Store predictions
                    test_index = X.index[split.test_idx]
                    all_probabilities[model_name] = pd.concat([
                        all_probabilities[model_name],
                        pd.Series(test_probs, index=test_index)
                    ])
                    all_predictions[model_name] = pd.concat([
                        all_predictions[model_name],
                        pd.Series(test_preds, index=test_index)
                    ])

                    # Calculate metrics
                    accuracy = accuracy_score(y_test, test_preds)
                    try:
                        auc = roc_auc_score(y_test, test_probs)
                    except:
                        auc = 0.5

                    fold_metrics[f'{model_name}_accuracy'] = accuracy
                    fold_metrics[f'{model_name}_auc'] = auc

                    self.logger.info(f"  {model_name}: Acc={accuracy:.4f}, AUC={auc:.4f}")

                except Exception as e:
                    self.logger.error(f"  Error training {model_name}: {e}")

            self.metrics.append(fold_metrics)
            self.fold_results.append({
                'split': split,
                'metrics': fold_metrics
            })

        self.predictions = all_predictions
        self.probabilities = all_probabilities

        return all_probabilities

    def get_combined_predictions(
        self,
        method: str = 'mean'
    ) -> pd.Series:
        """
        Combine predictions from all models.

        Args:
            method: Combination method ('mean', 'median', 'vote')

        Returns:
            Combined predictions
        """
        if not self.probabilities:
            raise ValueError("No predictions available. Run train_walk_forward first.")

        # Align all predictions
        probs_df = pd.DataFrame(self.probabilities)
        probs_df = probs_df.dropna()

        if method == 'mean':
            combined = probs_df.mean(axis=1)
        elif method == 'median':
            combined = probs_df.median(axis=1)
        elif method == 'vote':
            combined = (probs_df > 0.5).astype(int).mean(axis=1)
        else:
            combined = probs_df.mean(axis=1)

        return combined

    def get_metrics_summary(self) -> pd.DataFrame:
        """Get summary of metrics across folds."""
        if not self.metrics:
            return pd.DataFrame()

        metrics_df = pd.DataFrame(self.metrics)

        summary = metrics_df.describe().loc[['mean', 'std']]

        return summary

    def run(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        model_configs: Optional[Dict] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            X: Feature DataFrame
            y: Target Series
            model_configs: Model configurations

        Returns:
            AgentResult with training results
        """
        def execute():
            # Train models
            probabilities = self.train_walk_forward(X, y, model_configs)

            # Combine predictions
            combined_probs = self.get_combined_predictions()
            combined_preds = (combined_probs > 0.5).astype(int)

            # Calculate overall metrics
            y_aligned = y.loc[combined_probs.index]

            overall_accuracy = accuracy_score(y_aligned, combined_preds)
            try:
                overall_auc = roc_auc_score(y_aligned, combined_probs)
            except:
                overall_auc = 0.5

            return {
                'predictions': self.predictions,
                'probabilities': probabilities,
                'combined_probabilities': combined_probs,
                'combined_predictions': combined_preds,
                'metrics': self.metrics,
                'metrics_summary': self.get_metrics_summary(),
                'overall_accuracy': overall_accuracy,
                'overall_auc': overall_auc,
                'n_folds': len(self.metrics)
            }

        return self._execute_with_timing(execute)


# Test Walk-Forward Validation
print("=" * 70)
print("🧪 TESTING WALK-FORWARD VALIDATION")
print("=" * 70)

# Create sample time-series data
np.random.seed(42)
n_samples = 500
dates = pd.date_range(start='2020-01-01', periods=n_samples, freq='D')

X_wf = pd.DataFrame(
    np.random.randn(n_samples, 10),
    index=dates,
    columns=[f'feature_{i}' for i in range(10)]
)
y_wf = pd.Series(
    (X_wf.sum(axis=1) > 0).astype(int).values,
    index=dates
)

print(f"\nData shape: {X_wf.shape}")
print(f"Date range: {dates[0]} to {dates[-1]}")

# Test validator
validator = WalkForwardValidator(n_splits=3, min_train_size=200)
print(f"\n📊 Walk-Forward Splits:")
for split in validator.split(X_wf, y_wf):
    print(f"  Fold {split.fold}: Train={len(split.train_idx)}, Val={len(split.val_idx)}, Test={len(split.test_idx)}")

# Test Prediction Agent
print("\n🎯 Training with Walk-Forward Validation...")
pred_agent = PredictionAgent(config=config)
pred_result = pred_agent.run(
    X_wf, y_wf,
    model_configs={
        'logistic_regression': {},
        'random_forest': {'n_estimators': 50}
    }
)

if pred_result.success:
    print(f"\n✅ Walk-forward training completed!")
    print(f"   Folds completed: {pred_result.data['n_folds']}")
    print(f"   Overall Accuracy: {pred_result.data['overall_accuracy']:.4f}")
    print(f"   Overall AUC: {pred_result.data['overall_auc']:.4f}")
    print(f"\n   Metrics Summary:")
    print(pred_result.data['metrics_summary'])
else:
    print(f"❌ Error: {pred_result.errors}")

print("\n" + "=" * 70)
print("✅ Walk-Forward Validation ready!")