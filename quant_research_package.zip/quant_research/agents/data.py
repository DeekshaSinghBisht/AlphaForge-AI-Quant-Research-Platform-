"""
data.py
=======
MarketDataAgent + NewsAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import yfinance as yf
import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Union, Tuple
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

class MarketDataAgent(DataAgent):
    """
    Agent responsible for fetching and processing market data.

    Uses yfinance to fetch historical OHLCV data for multiple tickers.
    Implements caching, validation, and preprocessing.

    Attributes:
        data: Dictionary mapping tickers to their DataFrames
        benchmark_data: DataFrame for benchmark ticker
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        """
        Initialize Market Data Agent.

        Args:
            config: System configuration
            logger: Logger instance
        """
        super().__init__("MarketDataAgent", config, logger)
        self.data: Dict[str, pd.DataFrame] = {}
        self.benchmark_data: Optional[pd.DataFrame] = None
        self.combined_data: Optional[pd.DataFrame] = None
        self._download_errors: List[str] = []

    def fetch(
        self,
        tickers: Optional[List[str]] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        include_benchmark: bool = True
    ) -> Dict[str, pd.DataFrame]:
        """
        Fetch market data for specified tickers.

        Args:
            tickers: List of ticker symbols (uses config default if None)
            start_date: Start date (uses config default if None)
            end_date: End date (uses today if None)
            include_benchmark: Whether to fetch benchmark data

        Returns:
            Dictionary mapping tickers to DataFrames
        """
        tickers = tickers or self.config.data.tickers
        start_date = start_date or self.config.data.start_date
        end_date = end_date or datetime.today().strftime('%Y-%m-%d')

        self.logger.info(f"Fetching data for {len(tickers)} tickers")
        self.logger.info(f"Date range: {start_date} to {end_date}")

        # Check cache first
        if self.config.data.use_cache:
            cached_data = self._load_from_cache(tickers, start_date, end_date)
            if cached_data:
                self.logger.info("Loaded data from cache")
                self.data = cached_data
                if include_benchmark:
                    self._fetch_benchmark(start_date, end_date)
                return self.data

        # Fetch data
        self._download_errors = []

        for ticker in tickers:
            try:
                df = self._fetch_single_ticker(ticker, start_date, end_date)
                if df is not None and len(df) > 0:
                    self.data[ticker] = df
                    self.logger.info(f"  ✅ {ticker}: {len(df)} rows")
                else:
                    self._download_errors.append(ticker)
                    self.logger.warning(f"  ⚠️ {ticker}: No data returned")
            except Exception as e:
                self._download_errors.append(ticker)
                self.logger.error(f"  ❌ {ticker}: {str(e)}")

        # Fetch benchmark
        if include_benchmark:
            self._fetch_benchmark(start_date, end_date)

        # Cache the data
        if self.config.data.use_cache and self.data:
            self._save_to_cache(tickers, start_date, end_date)

        self.logger.info(f"Successfully fetched {len(self.data)}/{len(tickers)} tickers")

        return self.data

    def _fetch_single_ticker(
        self,
        ticker: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """
        Fetch data for a single ticker.

        Args:
            ticker: Ticker symbol
            start_date: Start date
            end_date: End date

        Returns:
            DataFrame with OHLCV data
        """
        try:
            # Download data
            df = yf.download(
                ticker,
                start=start_date,
                end=end_date,
                progress=False,
                auto_adjust=True  # Adjust for splits/dividends
            )

            if df.empty:
                return None

            # Clean column names (handle multi-level columns)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)

            # Ensure index is datetime
            df.index = pd.to_datetime(df.index)
            df.index.name = 'Date'

            # Add ticker column
            df['Ticker'] = ticker

            # Calculate additional columns
            df['Returns'] = df['Close'].pct_change()
            df['Log_Returns'] = np.log(df['Close'] / df['Close'].shift(1))

            # Validate data
            valid, errors = self.validate_data(
                df,
                required_columns=['Open', 'High', 'Low', 'Close', 'Volume']
            )

            if not valid:
                self.logger.warning(f"Validation errors for {ticker}: {errors}")

            return df

        except Exception as e:
            self.logger.error(f"Error fetching {ticker}: {e}")
            return None

    def _fetch_benchmark(self, start_date: str, end_date: str) -> None:
        """Fetch benchmark data."""
        benchmark = self.config.data.benchmark_ticker
        self.logger.info(f"Fetching benchmark: {benchmark}")

        try:
            self.benchmark_data = self._fetch_single_ticker(
                benchmark, start_date, end_date
            )
            if self.benchmark_data is not None:
                self.logger.info(f"  ✅ {benchmark}: {len(self.benchmark_data)} rows")
            else:
                self.logger.warning(f"  ⚠️ {benchmark}: No data")
        except Exception as e:
            self.logger.error(f"  ❌ {benchmark}: {str(e)}")

    def run(
        self,
        tickers: Optional[List[str]] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            tickers: List of tickers to fetch
            **kwargs: Additional arguments passed to fetch()

        Returns:
            AgentResult with fetched data
        """
        def execute():
            data = self.fetch(tickers=tickers, **kwargs)

            if not data:
                raise ValueError("No data fetched successfully")

            # Create combined DataFrame
            self.combined_data = self._combine_data()

            return {
                'data': self.data,
                'benchmark': self.benchmark_data,
                'combined': self.combined_data,
                'tickers': list(self.data.keys()),
                'date_range': {
                    'start': min(df.index.min() for df in self.data.values()),
                    'end': max(df.index.max() for df in self.data.values())
                },
                'errors': self._download_errors
            }

        return self._execute_with_timing(execute)

    def _combine_data(self) -> pd.DataFrame:
        """
        Combine all ticker data into a single DataFrame.

        Returns:
            Combined DataFrame with multi-level columns
        """
        if not self.data:
            return pd.DataFrame()

        # Get common date range
        all_dates = None
        for ticker, df in self.data.items():
            if all_dates is None:
                all_dates = set(df.index)
            else:
                all_dates &= set(df.index)

        all_dates = sorted(all_dates)

        # Combine into multi-level DataFrame
        combined = {}
        for ticker, df in self.data.items():
            df_aligned = df.loc[all_dates]
            for col in ['Open', 'High', 'Low', 'Close', 'Volume', 'Returns']:
                if col in df_aligned.columns:
                    combined[(ticker, col)] = df_aligned[col]

        result = pd.DataFrame(combined)
        result.columns = pd.MultiIndex.from_tuples(result.columns)

        self.logger.info(f"Combined data: {result.shape}")

        return result

    def get_returns(
        self,
        tickers: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        Get returns DataFrame for specified tickers.

        Args:
            tickers: List of tickers (uses all if None)

        Returns:
            DataFrame with returns for each ticker
        """
        tickers = tickers or list(self.data.keys())

        returns_dict = {}
        for ticker in tickers:
            if ticker in self.data:
                returns_dict[ticker] = self.data[ticker]['Returns']

        return pd.DataFrame(returns_dict).dropna()

    def get_prices(
        self,
        tickers: Optional[List[str]] = None,
        price_col: str = 'Close'
    ) -> pd.DataFrame:
        """
        Get price DataFrame for specified tickers.

        Args:
            tickers: List of tickers (uses all if None)
            price_col: Price column to use

        Returns:
            DataFrame with prices for each ticker
        """
        tickers = tickers or list(self.data.keys())

        prices_dict = {}
        for ticker in tickers:
            if ticker in self.data and price_col in self.data[ticker].columns:
                prices_dict[ticker] = self.data[ticker][price_col]

        return pd.DataFrame(prices_dict).dropna()

    def get_summary_stats(self) -> pd.DataFrame:
        """Get summary statistics for all tickers."""
        stats = []

        for ticker, df in self.data.items():
            returns = df['Returns'].dropna()
            stats.append({
                'Ticker': ticker,
                'Start': df.index.min().strftime('%Y-%m-%d'),
                'End': df.index.max().strftime('%Y-%m-%d'),
                'Days': len(df),
                'Mean_Return': returns.mean() * 252,  # Annualized
                'Volatility': returns.std() * np.sqrt(252),  # Annualized
                'Sharpe': calculate_sharpe_ratio(returns),
                'Max_DD': calculate_max_drawdown((1 + returns).cumprod())[0],
                'Total_Return': (df['Close'].iloc[-1] / df['Close'].iloc[0]) - 1
            })

        return pd.DataFrame(stats).set_index('Ticker')

    def _save_to_cache(
        self,
        tickers: List[str],
        start_date: str,
        end_date: str
    ) -> None:
        """Save data to cache."""
        cache_key = f"market_data_{'-'.join(sorted(tickers))}_{start_date}_{end_date}"
        save_to_cache(
            {'data': self.data, 'benchmark': self.benchmark_data},
            cache_key,
            CACHE_PATH
        )
        self.logger.debug(f"Data cached: {cache_key}")

    def _load_from_cache(
        self,
        tickers: List[str],
        start_date: str,
        end_date: str
    ) -> Optional[Dict[str, pd.DataFrame]]:
        """Load data from cache."""
        cache_key = f"market_data_{'-'.join(sorted(tickers))}_{start_date}_{end_date}"
        cached = load_from_cache(
            cache_key,
            CACHE_PATH,
            max_age_hours=self.config.data.cache_expiry_hours
        )

        if cached:
            self.benchmark_data = cached.get('benchmark')
            return cached.get('data')

        return None


# Test the Market Data Agent
print("=" * 70)
print("🧪 TESTING MARKET DATA AGENT")
print("=" * 70)

# Create agent
data_agent = MarketDataAgent(config=config)

# Fetch data for a subset of tickers for testing
test_tickers = ["AAPL", "MSFT"]
result = data_agent.run(tickers=test_tickers)

if result.success:
    print(f"\n✅ Data fetched successfully!")
    print(f"   Tickers: {result.data['tickers']}")
    print(f"   Date range: {result.data['date_range']}")

    # Display summary statistics
    print("\n📊 Summary Statistics:")
    print(data_agent.get_summary_stats().to_string())

    # Display sample data
    print("\n📈 Sample Data (AAPL, last 5 rows):")
    print(data_agent.data['AAPL'].tail().to_string())
else:
    print(f"❌ Error: {result.errors}")

print("\n" + "=" * 70)
print("✅ Market Data Agent ready!")


import requests
import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Any
from datetime import datetime, timedelta
import time
from dataclasses import dataclass

@dataclass
class NewsArticle:
    """Data class for a news article."""
    id: str
    headline: str
    summary: str
    source: str
    url: str
    datetime: datetime
    related_tickers: List[str]
    category: str
    sentiment: Optional[float] = None

class NewsAgent(DataAgent):
    """
    Agent responsible for fetching financial news data.

    Uses Finnhub API to fetch company-specific and general market news.
    Implements rate limiting and caching.

    Attributes:
        news_data: Dictionary mapping tickers to their news articles
        general_news: List of general market news
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        api_key: Optional[str] = None
    ):
        """
        Initialize News Agent.

        Args:
            config: System configuration
            logger: Logger instance
            api_key: Finnhub API key (uses environment variable if not provided)
        """
        super().__init__("NewsAgent", config, logger)
        self.api_key = api_key or os.environ.get('FINNHUB_API_KEY', '')
        self.base_url = "https://finnhub.io/api/v1"
        self.news_data: Dict[str, List[NewsArticle]] = {}
        self.general_news: List[NewsArticle] = []
        self.rate_limit_delay = 1.0  # Seconds between API calls
        self._last_call_time = 0

        if not self.api_key:
            self.logger.warning("No Finnhub API key provided. News fetching will be limited.")

    def _rate_limit(self) -> None:
        """Implement rate limiting for API calls."""
        elapsed = time.time() - self._last_call_time
        if elapsed < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - elapsed)
        self._last_call_time = time.time()

    def _make_request(
        self,
        endpoint: str,
        params: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Make API request with error handling.

        Args:
            endpoint: API endpoint
            params: Request parameters

        Returns:
            JSON response or None if error
        """
        if not self.api_key:
            return None

        self._rate_limit()

        url = f"{self.base_url}/{endpoint}"
        params['token'] = self.api_key

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API request failed: {e}")
            return None

    def fetch_company_news(
        self,
        ticker: str,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None
    ) -> List[NewsArticle]:
        """
        Fetch news for a specific company.

        Args:
            ticker: Company ticker symbol
            from_date: Start date (YYYY-MM-DD)
            to_date: End date (YYYY-MM-DD)

        Returns:
            List of NewsArticle objects
        """
        if not self.api_key:
            self.logger.warning("No API key - generating synthetic news data")
            return self._generate_synthetic_news(ticker, from_date, to_date)

        to_date = to_date or datetime.today().strftime('%Y-%m-%d')
        from_date = from_date or (datetime.today() - timedelta(days=30)).strftime('%Y-%m-%d')

        params = {
            'symbol': ticker,
            'from': from_date,
            'to': to_date
        }

        response = self._make_request('company-news', params)

        if response is None:
            return self._generate_synthetic_news(ticker, from_date, to_date)

        articles = []
        for item in response:
            try:
                article = NewsArticle(
                    id=str(item.get('id', '')),
                    headline=item.get('headline', ''),
                    summary=item.get('summary', ''),
                    source=item.get('source', ''),
                    url=item.get('url', ''),
                    datetime=datetime.fromtimestamp(item.get('datetime', 0)),
                    related_tickers=[ticker],
                    category=item.get('category', 'company news')
                )
                articles.append(article)
            except Exception as e:
                self.logger.warning(f"Error parsing article: {e}")

        self.logger.info(f"Fetched {len(articles)} articles for {ticker}")
        return articles

    def fetch_general_news(
        self,
        category: str = 'general'
    ) -> List[NewsArticle]:
        """
        Fetch general market news.

        Args:
            category: News category ('general', 'forex', 'crypto', 'merger')

        Returns:
            List of NewsArticle objects
        """
        if not self.api_key:
            return self._generate_synthetic_general_news()

        params = {'category': category}
        response = self._make_request('news', params)

        if response is None:
            return self._generate_synthetic_general_news()

        articles = []
        for item in response:
            try:
                article = NewsArticle(
                    id=str(item.get('id', '')),
                    headline=item.get('headline', ''),
                    summary=item.get('summary', ''),
                    source=item.get('source', ''),
                    url=item.get('url', ''),
                    datetime=datetime.fromtimestamp(item.get('datetime', 0)),
                    related_tickers=item.get('related', '').split(',') if item.get('related') else [],
                    category=category
                )
                articles.append(article)
            except Exception as e:
                self.logger.warning(f"Error parsing article: {e}")

        self.logger.info(f"Fetched {len(articles)} general news articles")
        return articles

    def _generate_synthetic_news(
        self,
        ticker: str,
        from_date: str,
        to_date: str
    ) -> List[NewsArticle]:
        """
        Generate synthetic news data for testing when API is unavailable.

        Args:
            ticker: Ticker symbol
            from_date: Start date
            to_date: End date

        Returns:
            List of synthetic NewsArticle objects
        """
        np.random.seed(hash(ticker) % 2**32)

        templates = [
            (f"{ticker} reports strong quarterly earnings, beats expectations", 0.8),
            (f"{ticker} announces new product launch", 0.6),
            (f"{ticker} expands into new markets", 0.5),
            (f"{ticker} faces regulatory scrutiny", -0.4),
            (f"{ticker} CEO discusses growth strategy", 0.3),
            (f"{ticker} stock upgraded by analysts", 0.7),
            (f"{ticker} reports supply chain challenges", -0.3),
            (f"{ticker} partners with major tech company", 0.6),
            (f"{ticker} announces share buyback program", 0.5),
            (f"{ticker} misses revenue expectations", -0.6),
            (f"Analysts bullish on {ticker} outlook", 0.5),
            (f"{ticker} innovation drives competitive advantage", 0.4),
        ]

        start = pd.to_datetime(from_date)
        end = pd.to_datetime(to_date)
        date_range = pd.date_range(start, end, freq='D')

        articles = []
        for i, date in enumerate(date_range):
            # Random number of articles per day (0-3)
            num_articles = np.random.choice([0, 0, 1, 1, 1, 2, 2, 3])

            for j in range(num_articles):
                template, sentiment = templates[np.random.randint(0, len(templates))]

                article = NewsArticle(
                    id=f"synthetic_{ticker}_{i}_{j}",
                    headline=template,
                    summary=f"Detailed coverage of {template.lower()}. Market analysts are closely watching developments.",
                    source="Synthetic News",
                    url=f"https://example.com/news/{ticker}/{i}_{j}",
                    datetime=date.to_pydatetime(),
                    related_tickers=[ticker],
                    category="company news",
                    sentiment=sentiment + np.random.normal(0, 0.1)
                )
                articles.append(article)

        return articles

    def _generate_synthetic_general_news(self) -> List[NewsArticle]:
        """Generate synthetic general market news."""
        templates = [
            ("Markets rally on positive economic data", 0.6),
            ("Fed signals potential rate changes", -0.2),
            ("Tech sector leads market gains", 0.5),
            ("Global markets face uncertainty", -0.3),
            ("Investors eye upcoming earnings season", 0.1),
            ("Market volatility increases amid concerns", -0.4),
            ("Strong jobs report boosts market sentiment", 0.7),
            ("Trade tensions impact global markets", -0.5),
        ]

        articles = []
        for i, (headline, sentiment) in enumerate(templates):
            article = NewsArticle(
                id=f"synthetic_general_{i}",
                headline=headline,
                summary=f"Market update: {headline}. Analysts provide insights on implications.",
                source="Synthetic News",
                url=f"https://example.com/market/{i}",
                datetime=datetime.now() - timedelta(days=i),
                related_tickers=[],
                category="general",
                sentiment=sentiment
            )
            articles.append(article)

        return articles

    def fetch(
        self,
        tickers: Optional[List[str]] = None,
        days_back: int = 30
    ) -> Dict[str, List[NewsArticle]]:
        """
        Fetch news for all specified tickers.

        Args:
            tickers: List of tickers (uses config default if None)
            days_back: Number of days of news to fetch

        Returns:
            Dictionary mapping tickers to news lists
        """
        tickers = tickers or self.config.data.tickers

        to_date = datetime.today().strftime('%Y-%m-%d')
        from_date = (datetime.today() - timedelta(days=days_back)).strftime('%Y-%m-%d')

        self.logger.info(f"Fetching news for {len(tickers)} tickers ({days_back} days)")

        for ticker in tickers:
            articles = self.fetch_company_news(ticker, from_date, to_date)
            self.news_data[ticker] = articles
            self.logger.info(f"  {ticker}: {len(articles)} articles")

        # Fetch general news
        self.general_news = self.fetch_general_news()

        return self.news_data

    def run(
        self,
        tickers: Optional[List[str]] = None,
        days_back: int = 30,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            tickers: List of tickers
            days_back: Days of news to fetch

        Returns:
            AgentResult with news data
        """
        def execute():
            news = self.fetch(tickers=tickers, days_back=days_back)

            # Convert to DataFrame for analysis
            news_df = self.to_dataframe()

            return {
                'news_by_ticker': self.news_data,
                'general_news': self.general_news,
                'news_df': news_df,
                'total_articles': sum(len(v) for v in self.news_data.values()),
                'tickers_covered': list(self.news_data.keys())
            }

        return self._execute_with_timing(execute)

    def to_dataframe(self) -> pd.DataFrame:
        """
        Convert news data to DataFrame.

        Returns:
            DataFrame with all news articles
        """
        records = []

        for ticker, articles in self.news_data.items():
            for article in articles:
                records.append({
                    'ticker': ticker,
                    'datetime': article.datetime,
                    'headline': article.headline,
                    'summary': article.summary,
                    'source': article.source,
                    'category': article.category,
                    'sentiment': article.sentiment
                })

        for article in self.general_news:
            records.append({
                'ticker': 'GENERAL',
                'datetime': article.datetime,
                'headline': article.headline,
                'summary': article.summary,
                'source': article.source,
                'category': article.category,
                'sentiment': article.sentiment
            })

        df = pd.DataFrame(records)
        if not df.empty:
            df['date'] = pd.to_datetime(df['datetime']).dt.date
            df = df.sort_values('datetime', ascending=False)

        return df

    def get_news_count_by_date(
        self,
        ticker: Optional[str] = None
    ) -> pd.Series:
        """Get daily news count."""
        df = self.to_dataframe()

        if ticker and ticker in df['ticker'].values:
            df = df[df['ticker'] == ticker]

        return df.groupby('date').size()


# Test the News Agent
print("=" * 70)
print("🧪 TESTING NEWS AGENT")
print("=" * 70)

news_agent = NewsAgent(config=config)
result = news_agent.run(tickers=["AAPL", "MSFT"], days_back=7)

if result.success:
    print(f"\n✅ News fetched successfully!")
    print(f"   Total articles: {result.data['total_articles']}")
    print(f"   Tickers covered: {result.data['tickers_covered']}")

    # Display sample news
    news_df = result.data['news_df']
    if not news_df.empty:
        print("\n📰 Sample Headlines:")
        for _, row in news_df.head(5).iterrows():
            print(f"   [{row['ticker']}] {row['headline'][:70]}...")
else:
    print(f"❌ Error: {result.errors}")

print("\n" + "=" * 70)
print("✅ News Agent ready!")