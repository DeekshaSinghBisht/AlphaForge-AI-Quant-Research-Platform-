"""
features.py
===========
TechnicalIndicators + FeatureEngineeringAgent + FeatureSelectionAgent
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import pandas as pd
import numpy as np
from typing import Union, Optional, List, Dict, Tuple
import warnings
warnings.filterwarnings('ignore')

# Try to import TA-Lib, fall back to ta library
try:
    import talib
    USE_TALIB = True
    print("✅ Using TA-Lib for technical indicators")
except ImportError:
    import ta
    USE_TALIB = False
    print("⚠️ TA-Lib not available, using 'ta' library")


class TechnicalIndicators:
    """
    Collection of technical indicator calculations.

    Supports both TA-Lib and ta library implementations.
    All methods are static and operate on pandas Series/DataFrames.
    """

    # ========================================================================
    # MOVING AVERAGES
    # ========================================================================

    @staticmethod
    def sma(series: pd.Series, period: int) -> pd.Series:
        """Simple Moving Average."""
        return series.rolling(window=period, min_periods=1).mean()

    @staticmethod
    def ema(series: pd.Series, period: int) -> pd.Series:
        """Exponential Moving Average."""
        return series.ewm(span=period, adjust=False, min_periods=1).mean()

    @staticmethod
    def wma(series: pd.Series, period: int) -> pd.Series:
        """Weighted Moving Average."""
        weights = np.arange(1, period + 1)
        return series.rolling(window=period).apply(
            lambda x: np.dot(x, weights) / weights.sum(), raw=True
        )

    @staticmethod
    def dema(series: pd.Series, period: int) -> pd.Series:
        """Double Exponential Moving Average."""
        ema1 = TechnicalIndicators.ema(series, period)
        ema2 = TechnicalIndicators.ema(ema1, period)
        return 2 * ema1 - ema2

    @staticmethod
    def tema(series: pd.Series, period: int) -> pd.Series:
        """Triple Exponential Moving Average."""
        ema1 = TechnicalIndicators.ema(series, period)
        ema2 = TechnicalIndicators.ema(ema1, period)
        ema3 = TechnicalIndicators.ema(ema2, period)
        return 3 * ema1 - 3 * ema2 + ema3

    # ========================================================================
    # MOMENTUM INDICATORS
    # ========================================================================

    @staticmethod
    def rsi(series: pd.Series, period: int = 14) -> pd.Series:
        """Relative Strength Index."""
        delta = series.diff()
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)

        avg_gain = gain.rolling(window=period, min_periods=1).mean()
        avg_loss = loss.rolling(window=period, min_periods=1).mean()

        rs = avg_gain / avg_loss.replace(0, np.inf)
        rsi = 100 - (100 / (1 + rs))

        return rsi.fillna(50)

    @staticmethod
    def macd(
        series: pd.Series,
        fast: int = 12,
        slow: int = 26,
        signal: int = 9
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Moving Average Convergence Divergence.

        Returns:
            Tuple of (MACD line, Signal line, Histogram)
        """
        ema_fast = TechnicalIndicators.ema(series, fast)
        ema_slow = TechnicalIndicators.ema(series, slow)

        macd_line = ema_fast - ema_slow
        signal_line = TechnicalIndicators.ema(macd_line, signal)
        histogram = macd_line - signal_line

        return macd_line, signal_line, histogram

    @staticmethod
    def stochastic(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        k_period: int = 14,
        d_period: int = 3
    ) -> Tuple[pd.Series, pd.Series]:
        """
        Stochastic Oscillator.

        Returns:
            Tuple of (%K, %D)
        """
        lowest_low = low.rolling(window=k_period, min_periods=1).min()
        highest_high = high.rolling(window=k_period, min_periods=1).max()

        k = 100 * (close - lowest_low) / (highest_high - lowest_low).replace(0, np.inf)
        d = k.rolling(window=d_period, min_periods=1).mean()

        return k.fillna(50), d.fillna(50)

    @staticmethod
    def williams_r(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        period: int = 14
    ) -> pd.Series:
        """Williams %R."""
        highest_high = high.rolling(window=period, min_periods=1).max()
        lowest_low = low.rolling(window=period, min_periods=1).min()

        wr = -100 * (highest_high - close) / (highest_high - lowest_low).replace(0, np.inf)
        return wr.fillna(-50)

    @staticmethod
    def cci(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        period: int = 20
    ) -> pd.Series:
        """Commodity Channel Index."""
        tp = (high + low + close) / 3
        sma_tp = tp.rolling(window=period, min_periods=1).mean()
        mad = tp.rolling(window=period, min_periods=1).apply(
            lambda x: np.abs(x - x.mean()).mean(), raw=True
        )

        cci = (tp - sma_tp) / (0.015 * mad).replace(0, np.inf)
        return cci.fillna(0)

    @staticmethod
    def roc(series: pd.Series, period: int = 10) -> pd.Series:
        """Rate of Change."""
        return ((series - series.shift(period)) / series.shift(period).replace(0, np.inf)) * 100

    @staticmethod
    def momentum(series: pd.Series, period: int = 10) -> pd.Series:
        """Momentum indicator."""
        return series - series.shift(period)

    # ========================================================================
    # VOLATILITY INDICATORS
    # ========================================================================

    @staticmethod
    def atr(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        period: int = 14
    ) -> pd.Series:
        """Average True Range."""
        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))

        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period, min_periods=1).mean()

        return atr

    @staticmethod
    def bollinger_bands(
        series: pd.Series,
        period: int = 20,
        std_dev: float = 2.0
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Bollinger Bands.

        Returns:
            Tuple of (Upper band, Middle band, Lower band)
        """
        middle = TechnicalIndicators.sma(series, period)
        std = series.rolling(window=period, min_periods=1).std()

        upper = middle + std_dev * std
        lower = middle - std_dev * std

        return upper, middle, lower

    @staticmethod
    def keltner_channels(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        period: int = 20,
        atr_mult: float = 2.0
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Keltner Channels.

        Returns:
            Tuple of (Upper, Middle, Lower)
        """
        middle = TechnicalIndicators.ema(close, period)
        atr = TechnicalIndicators.atr(high, low, close, period)

        upper = middle + atr_mult * atr
        lower = middle - atr_mult * atr

        return upper, middle, lower

    @staticmethod
    def donchian_channels(
        high: pd.Series,
        low: pd.Series,
        period: int = 20
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Donchian Channels.

        Returns:
            Tuple of (Upper, Middle, Lower)
        """
        upper = high.rolling(window=period, min_periods=1).max()
        lower = low.rolling(window=period, min_periods=1).min()
        middle = (upper + lower) / 2

        return upper, middle, lower

    # ========================================================================
    # VOLUME INDICATORS
    # ========================================================================

    @staticmethod
    def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
        """On-Balance Volume."""
        direction = np.sign(close.diff())
        direction.iloc[0] = 0

        obv = (direction * volume).cumsum()
        return obv

    @staticmethod
    def vwap(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        volume: pd.Series
    ) -> pd.Series:
        """Volume Weighted Average Price (cumulative)."""
        tp = (high + low + close) / 3
        return (tp * volume).cumsum() / volume.cumsum()

    @staticmethod
    def mfi(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        volume: pd.Series,
        period: int = 14
    ) -> pd.Series:
        """Money Flow Index."""
        tp = (high + low + close) / 3
        mf = tp * volume

        positive_mf = mf.where(tp > tp.shift(1), 0)
        negative_mf = mf.where(tp < tp.shift(1), 0)

        positive_mf_sum = positive_mf.rolling(window=period, min_periods=1).sum()
        negative_mf_sum = negative_mf.rolling(window=period, min_periods=1).sum()

        mfr = positive_mf_sum / negative_mf_sum.replace(0, np.inf)
        mfi = 100 - (100 / (1 + mfr))

        return mfi.fillna(50)

    @staticmethod
    def cmf(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        volume: pd.Series,
        period: int = 20
    ) -> pd.Series:
        """Chaikin Money Flow."""
        mfm = ((close - low) - (high - close)) / (high - low).replace(0, np.inf)
        mfv = mfm * volume

        cmf = mfv.rolling(window=period, min_periods=1).sum() / \
              volume.rolling(window=period, min_periods=1).sum()

        return cmf.fillna(0)

    @staticmethod
    def volume_ratio(volume: pd.Series, period: int = 20) -> pd.Series:
        """Volume ratio vs moving average."""
        vol_ma = volume.rolling(window=period, min_periods=1).mean()
        return volume / vol_ma.replace(0, np.inf)

    # ========================================================================
    # TREND INDICATORS
    # ========================================================================

    @staticmethod
    def adx(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        period: int = 14
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Average Directional Index.

        Returns:
            Tuple of (ADX, +DI, -DI)
        """
        # True Range
        tr = pd.concat([
            high - low,
            abs(high - close.shift(1)),
            abs(low - close.shift(1))
        ], axis=1).max(axis=1)

        # Directional Movement
        up_move = high - high.shift(1)
        down_move = low.shift(1) - low

        plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0)
        minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0)

        # Smoothed averages
        atr = tr.rolling(window=period, min_periods=1).mean()
        plus_di = 100 * plus_dm.rolling(window=period, min_periods=1).mean() / atr.replace(0, np.inf)
        minus_di = 100 * minus_dm.rolling(window=period, min_periods=1).mean() / atr.replace(0, np.inf)

        # ADX
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di).replace(0, np.inf)
        adx = dx.rolling(window=period, min_periods=1).mean()

        return adx.fillna(0), plus_di.fillna(0), minus_di.fillna(0)

    @staticmethod
    def aroon(
        high: pd.Series,
        low: pd.Series,
        period: int = 25
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Aroon Indicator.

        Returns:
            Tuple of (Aroon Up, Aroon Down, Aroon Oscillator)
        """
        aroon_up = high.rolling(window=period + 1, min_periods=1).apply(
            lambda x: 100 * (period - (len(x) - 1 - np.argmax(x))) / period, raw=True
        )
        aroon_down = low.rolling(window=period + 1, min_periods=1).apply(
            lambda x: 100 * (period - (len(x) - 1 - np.argmin(x))) / period, raw=True
        )

        aroon_osc = aroon_up - aroon_down

        return aroon_up.fillna(50), aroon_down.fillna(50), aroon_osc.fillna(0)

    @staticmethod
    def psar(
        high: pd.Series,
        low: pd.Series,
        close: pd.Series,
        af_start: float = 0.02,
        af_increment: float = 0.02,
        af_max: float = 0.2
    ) -> pd.Series:
        """Parabolic SAR (simplified implementation)."""
        length = len(close)
        psar = close.copy()
        af = af_start
        trend = 1  # 1 for uptrend, -1 for downtrend
        ep = low.iloc[0]  # Extreme point

        for i in range(1, length):
            if trend == 1:
                psar.iloc[i] = psar.iloc[i-1] + af * (ep - psar.iloc[i-1])
                if low.iloc[i] < psar.iloc[i]:
                    trend = -1
                    psar.iloc[i] = ep
                    ep = low.iloc[i]
                    af = af_start
                else:
                    if high.iloc[i] > ep:
                        ep = high.iloc[i]
                        af = min(af + af_increment, af_max)
            else:
                psar.iloc[i] = psar.iloc[i-1] - af * (psar.iloc[i-1] - ep)
                if high.iloc[i] > psar.iloc[i]:
                    trend = 1
                    psar.iloc[i] = ep
                    ep = high.iloc[i]
                    af = af_start
                else:
                    if low.iloc[i] < ep:
                        ep = low.iloc[i]
                        af = min(af + af_increment, af_max)

        return psar


# Test technical indicators
print("=" * 70)
print("🧪 TESTING TECHNICAL INDICATORS")
print("=" * 70)

# Use data from MarketDataAgent
if 'data_agent' in dir() and data_agent.data:
    test_df = data_agent.data.get('AAPL', list(data_agent.data.values())[0])

    # Test indicators
    print("\nTesting indicators on sample data...")

    rsi = TechnicalIndicators.rsi(test_df['Close'], 14)
    print(f"✅ RSI: {rsi.tail().values}")

    macd_line, signal, hist = TechnicalIndicators.macd(test_df['Close'])
    print(f"✅ MACD: {macd_line.tail().values}")

    upper, middle, lower = TechnicalIndicators.bollinger_bands(test_df['Close'])
    print(f"✅ Bollinger Bands: Upper={upper.iloc[-1]:.2f}, Middle={middle.iloc[-1]:.2f}, Lower={lower.iloc[-1]:.2f}")

    atr = TechnicalIndicators.atr(test_df['High'], test_df['Low'], test_df['Close'])
    print(f"✅ ATR: {atr.tail().values}")

    obv = TechnicalIndicators.obv(test_df['Close'], test_df['Volume'])
    print(f"✅ OBV: {obv.tail().values}")

print("\n✅ Technical Indicators module ready!")


import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Union, Any
from datetime import datetime

class FeatureEngineeringAgent(BaseAgent):
    """
    Agent responsible for generating features from market data.

    Generates:
    - Technical indicators (momentum, volatility, volume, trend)
    - Price-derived features (returns, ratios, spreads)
    - Rolling statistics
    - Lag features
    - Time-based features
    - Target variable

    Attributes:
        feature_names: List of generated feature names
        features: DataFrame with all features
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None
    ):
        """Initialize Feature Engineering Agent."""
        super().__init__("FeatureEngineeringAgent", config, logger)
        self.feature_names: List[str] = []
        self.features: Optional[pd.DataFrame] = None
        self.target: Optional[pd.Series] = None

    def generate_features(
        self,
        df: pd.DataFrame,
        include_target: bool = True
    ) -> pd.DataFrame:
        """
        Generate all features from OHLCV data.

        Args:
            df: DataFrame with OHLCV columns
            include_target: Whether to generate target variable

        Returns:
            DataFrame with all features
        """
        self.logger.info("Generating features...")

        features = pd.DataFrame(index=df.index)

        # Extract OHLCV
        open_p = df['Open']
        high = df['High']
        low = df['Low']
        close = df['Close']
        volume = df['Volume']

        # ====================================================================
        # PRICE FEATURES
        # ====================================================================
        self.logger.info("  → Price features")

        features['returns'] = close.pct_change()
        features['log_returns'] = np.log(close / close.shift(1))
        features['high_low_ratio'] = high / low
        features['close_open_ratio'] = close / open_p
        features['price_range'] = (high - low) / close
        features['gap'] = open_p / close.shift(1) - 1

        # ====================================================================
        # MOVING AVERAGES
        # ====================================================================
        self.logger.info("  → Moving averages")

        for period in self.config.features.ma_periods:
            features[f'sma_{period}'] = TechnicalIndicators.sma(close, period)
            features[f'ema_{period}'] = TechnicalIndicators.ema(close, period)
            features[f'price_to_sma_{period}'] = close / features[f'sma_{period}']

        # Moving average crossovers
        features['sma_5_20_cross'] = (features['sma_5'] > features['sma_20']).astype(int)
        features['sma_20_50_cross'] = (features['sma_20'] > features['sma_50']).astype(int)
        features['sma_50_200_cross'] = (features['sma_50'] > features['sma_200']).astype(int)

        # ====================================================================
        # MOMENTUM INDICATORS
        # ====================================================================
        self.logger.info("  → Momentum indicators")

        features['rsi'] = TechnicalIndicators.rsi(close, self.config.features.rsi_period)
        features['rsi_overbought'] = (features['rsi'] > 70).astype(int)
        features['rsi_oversold'] = (features['rsi'] < 30).astype(int)

        macd_line, signal_line, histogram = TechnicalIndicators.macd(
            close,
            self.config.features.macd_fast,
            self.config.features.macd_slow,
            self.config.features.macd_signal
        )
        features['macd'] = macd_line
        features['macd_signal'] = signal_line
        features['macd_histogram'] = histogram
        features['macd_cross'] = (macd_line > signal_line).astype(int)

        stoch_k, stoch_d = TechnicalIndicators.stochastic(high, low, close)
        features['stoch_k'] = stoch_k
        features['stoch_d'] = stoch_d
        features['stoch_cross'] = (stoch_k > stoch_d).astype(int)

        features['williams_r'] = TechnicalIndicators.williams_r(high, low, close)
        features['cci'] = TechnicalIndicators.cci(high, low, close)
        features['roc_10'] = TechnicalIndicators.roc(close, 10)
        features['momentum_10'] = TechnicalIndicators.momentum(close, 10)

        # ====================================================================
        # VOLATILITY INDICATORS
        # ====================================================================
        self.logger.info("  → Volatility indicators")

        features['atr'] = TechnicalIndicators.atr(high, low, close, self.config.features.atr_period)
        features['atr_pct'] = features['atr'] / close

        upper, middle, lower = TechnicalIndicators.bollinger_bands(
            close, self.config.features.bb_period, self.config.features.bb_std
        )
        features['bb_upper'] = upper
        features['bb_middle'] = middle
        features['bb_lower'] = lower
        features['bb_width'] = (upper - lower) / middle
        features['bb_position'] = (close - lower) / (upper - lower)

        kc_upper, kc_middle, kc_lower = TechnicalIndicators.keltner_channels(high, low, close)
        features['kc_upper'] = kc_upper
        features['kc_lower'] = kc_lower
        features['squeeze'] = ((upper < kc_upper) & (lower > kc_lower)).astype(int)

        # ====================================================================
        # VOLUME INDICATORS
        # ====================================================================
        self.logger.info("  → Volume indicators")

        features['obv'] = TechnicalIndicators.obv(close, volume)
        features['obv_change'] = features['obv'].pct_change()
        features['mfi'] = TechnicalIndicators.mfi(high, low, close, volume)
        features['cmf'] = TechnicalIndicators.cmf(high, low, close, volume)
        features['volume_ratio'] = TechnicalIndicators.volume_ratio(volume)
        features['volume_ma_20'] = volume.rolling(20).mean()
        features['volume_std_20'] = volume.rolling(20).std()

        # ====================================================================
        # TREND INDICATORS
        # ====================================================================
        self.logger.info("  → Trend indicators")

        adx, plus_di, minus_di = TechnicalIndicators.adx(high, low, close)
        features['adx'] = adx
        features['plus_di'] = plus_di
        features['minus_di'] = minus_di
        features['di_diff'] = plus_di - minus_di

        aroon_up, aroon_down, aroon_osc = TechnicalIndicators.aroon(high, low)
        features['aroon_up'] = aroon_up
        features['aroon_down'] = aroon_down
        features['aroon_osc'] = aroon_osc

        # ====================================================================
        # ROLLING STATISTICS
        # ====================================================================
        self.logger.info("  → Rolling statistics")

        for window in self.config.features.rolling_windows:
            features[f'return_mean_{window}'] = features['returns'].rolling(window).mean()
            features[f'return_std_{window}'] = features['returns'].rolling(window).std()
            features[f'return_skew_{window}'] = features['returns'].rolling(window).skew()
            features[f'return_kurt_{window}'] = features['returns'].rolling(window).kurt()
            features[f'return_min_{window}'] = features['returns'].rolling(window).min()
            features[f'return_max_{window}'] = features['returns'].rolling(window).max()
            features[f'sharpe_{window}'] = (
                features[f'return_mean_{window}'] /
                features[f'return_std_{window}'].replace(0, np.inf)
            ) * np.sqrt(252)

        # ====================================================================
        # LAG FEATURES
        # ====================================================================
        self.logger.info("  → Lag features")

        for lag in self.config.features.lag_periods:
            features[f'return_lag_{lag}'] = features['returns'].shift(lag)
            features[f'volume_ratio_lag_{lag}'] = features['volume_ratio'].shift(lag)
            features[f'rsi_lag_{lag}'] = features['rsi'].shift(lag)

        # ====================================================================
        # TIME FEATURES
        # ====================================================================
        self.logger.info("  → Time features")

        if isinstance(df.index, pd.DatetimeIndex):
            features['day_of_week'] = df.index.dayofweek
            features['day_of_month'] = df.index.day
            features['month'] = df.index.month
            features['quarter'] = df.index.quarter
            features['is_month_start'] = df.index.is_month_start.astype(int)
            features['is_month_end'] = df.index.is_month_end.astype(int)
            features['is_quarter_start'] = df.index.is_quarter_start.astype(int)
            features['is_quarter_end'] = df.index.is_quarter_end.astype(int)

        # ====================================================================
        # TARGET VARIABLE
        # ====================================================================
        if include_target:
            self.logger.info("  → Target variable")

            horizon = self.config.features.target_horizon
            future_return = close.shift(-horizon) / close - 1

            if self.config.features.target_type == 'binary':
                features['target'] = (future_return > 0).astype(int)
            else:
                features['target'] = future_return

            self.target = features['target']

        # Store feature names (excluding target)
        self.feature_names = [col for col in features.columns if col != 'target']
        self.logger.info(f"Generated {len(self.feature_names)} features")

        return features

    def prepare_ml_data(
        self,
        features: pd.DataFrame,
        dropna: bool = True
    ) -> tuple:
        """
        Prepare data for ML training.

        Args:
            features: DataFrame with features and target
            dropna: Whether to drop rows with NaN values

        Returns:
            Tuple of (X, y, feature_names)
        """
        if dropna:
            features = features.dropna()

        feature_cols = [col for col in features.columns if col != 'target']

        X = features[feature_cols]
        y = features['target'] if 'target' in features.columns else None

        return X, y, feature_cols

    def run(
        self,
        data: Union[pd.DataFrame, Dict[str, pd.DataFrame]],
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            data: Single DataFrame or dict of DataFrames by ticker

        Returns:
            AgentResult with generated features
        """
        def execute():
            if isinstance(data, dict):
                # Process multiple tickers
                all_features = {}
                for ticker, df in data.items():
                    self.logger.info(f"Processing {ticker}...")
                    features = self.generate_features(df, **kwargs)
                    all_features[ticker] = features

                return {
                    'features_by_ticker': all_features,
                    'feature_names': self.feature_names,
                    'n_features': len(self.feature_names)
                }
            else:
                # Process single DataFrame
                features = self.generate_features(data, **kwargs)
                X, y, feature_names = self.prepare_ml_data(features)

                return {
                    'features': features,
                    'X': X,
                    'y': y,
                    'feature_names': feature_names,
                    'n_features': len(feature_names),
                    'n_samples': len(X)
                }

        return self._execute_with_timing(execute)


# Test Feature Engineering Agent
print("=" * 70)
print("🧪 TESTING FEATURE ENGINEERING AGENT")
print("=" * 70)

feature_agent = FeatureEngineeringAgent(config=config)

if 'data_agent' in dir() and data_agent.data:
    # Test on single ticker
    test_df = data_agent.data.get('AAPL', list(data_agent.data.values())[0])
    result = feature_agent.run(test_df)

    if result.success:
        print(f"\n✅ Features generated successfully!")
        print(f"   Number of features: {result.data['n_features']}")
        print(f"   Number of samples: {result.data['n_samples']}")
        print(f"\n   Sample features: {result.data['feature_names'][:10]}")

        # Display feature statistics
        X = result.data['X']
        print(f"\n📊 Feature Statistics:")
        print(X.describe().T[['mean', 'std', 'min', 'max']].head(10))
    else:
        print(f"❌ Error: {result.errors}")
else:
    print("⚠️ No market data available. Run Cell 10 first.")

print("\n" + "=" * 70)
print("✅ Feature Engineering Agent ready!")


import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple, Any, Union
from sklearn.feature_selection import (
    mutual_info_classif,
    mutual_info_regression,
    RFE,
    SelectKBest,
    f_classif,
    f_regression
)
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

try:
    import shap
    SHAP_AVAILABLE = True
    print("✅ SHAP library available")
except ImportError:
    SHAP_AVAILABLE = False
    print("⚠️ SHAP not available, using alternative methods")


class FeatureSelectionAgent(BaseAgent):
    """
    Agent responsible for automatic feature selection.

    Uses multiple methods to select the most predictive features:
    - Mutual Information ranking
    - Recursive Feature Elimination (RFE)
    - SHAP-based importance
    - Correlation-based redundancy removal

    Attributes:
        selected_features: List of selected feature names
        feature_scores: Dictionary of feature importance scores
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        max_features: Optional[int] = None
    ):
        """
        Initialize Feature Selection Agent.

        Args:
            config: System configuration
            logger: Logger instance
            max_features: Maximum features to select
        """
        super().__init__("FeatureSelectionAgent", config, logger)

        self.max_features = max_features or self.config.features.max_features
        self.selected_features: List[str] = []
        self.feature_scores: Dict[str, Dict[str, float]] = {}
        self.scaler = StandardScaler()

    def _remove_correlated_features(
        self,
        X: pd.DataFrame,
        threshold: float = 0.95
    ) -> List[str]:
        """
        Remove highly correlated features.

        Args:
            X: Feature matrix
            threshold: Correlation threshold

        Returns:
            List of features to keep
        """
        # Compute correlation matrix
        corr_matrix = X.corr().abs()

        # Select upper triangle
        upper = corr_matrix.where(
            np.triu(np.ones(corr_matrix.shape), k=1).astype(bool)
        )

        # Find features with correlation > threshold
        to_drop = [col for col in upper.columns if any(upper[col] > threshold)]

        features_to_keep = [col for col in X.columns if col not in to_drop]

        self.logger.info(f"Removed {len(to_drop)} correlated features")

        return features_to_keep

    def select_by_mutual_info(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        n_features: Optional[int] = None,
        classification: bool = True
    ) -> Tuple[List[str], pd.Series]:
        """
        Select features using mutual information.

        Args:
            X: Feature matrix
            y: Target variable
            n_features: Number of features to select
            classification: Whether this is classification

        Returns:
            Tuple of (selected features, importance scores)
        """
        n_features = n_features or self.max_features

        self.logger.info(f"Selecting features using mutual information...")

        # Scale features
        X_scaled = self.scaler.fit_transform(X)

        # Calculate mutual information
        if classification:
            mi_scores = mutual_info_classif(
                X_scaled, y,
                random_state=self.config.ml.random_seed,
                n_neighbors=5
            )
        else:
            mi_scores = mutual_info_regression(
                X_scaled, y,
                random_state=self.config.ml.random_seed,
                n_neighbors=5
            )

        # Create scores series
        mi_series = pd.Series(mi_scores, index=X.columns)
        mi_series = mi_series.sort_values(ascending=False)

        # Select top features
        selected = mi_series.head(n_features).index.tolist()

        self.feature_scores['mutual_info'] = mi_series.to_dict()

        self.logger.info(f"Selected {len(selected)} features using MI")

        return selected, mi_series

    def select_by_rfe(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        n_features: Optional[int] = None,
        classification: bool = True
    ) -> Tuple[List[str], pd.Series]:
        """
        Select features using Recursive Feature Elimination.

        Args:
            X: Feature matrix
            y: Target variable
            n_features: Number of features to select
            classification: Whether this is classification

        Returns:
            Tuple of (selected features, ranking scores)
        """
        n_features = n_features or self.max_features

        self.logger.info(f"Selecting features using RFE...")

        # Use RandomForest as estimator
        if classification:
            estimator = RandomForestClassifier(
                n_estimators=50,
                max_depth=5,
                random_state=self.config.ml.random_seed,
                n_jobs=-1
            )
        else:
            estimator = RandomForestRegressor(
                n_estimators=50,
                max_depth=5,
                random_state=self.config.ml.random_seed,
                n_jobs=-1
            )

        # Run RFE
        rfe = RFE(
            estimator=estimator,
            n_features_to_select=n_features,
            step=0.1
        )

        rfe.fit(X, y)

        # Get rankings (lower is better)
        rankings = pd.Series(rfe.ranking_, index=X.columns)

        # Get selected features
        selected = X.columns[rfe.support_].tolist()

        # Convert rankings to scores (inverse)
        scores = 1 / rankings
        scores = scores.sort_values(ascending=False)

        self.feature_scores['rfe'] = scores.to_dict()

        self.logger.info(f"Selected {len(selected)} features using RFE")

        return selected, scores

    def select_by_importance(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        n_features: Optional[int] = None,
        classification: bool = True
    ) -> Tuple[List[str], pd.Series]:
        """
        Select features using tree-based importance.

        Args:
            X: Feature matrix
            y: Target variable
            n_features: Number of features to select
            classification: Whether this is classification

        Returns:
            Tuple of (selected features, importance scores)
        """
        n_features = n_features or self.max_features

        self.logger.info(f"Selecting features using RF importance...")

        # Train Random Forest
        if classification:
            model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=self.config.ml.random_seed,
                n_jobs=-1
            )
        else:
            model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=self.config.ml.random_seed,
                n_jobs=-1
            )

        model.fit(X, y)

        # Get feature importance
        importance = pd.Series(model.feature_importances_, index=X.columns)
        importance = importance.sort_values(ascending=False)

        # Select top features
        selected = importance.head(n_features).index.tolist()

        self.feature_scores['rf_importance'] = importance.to_dict()

        self.logger.info(f"Selected {len(selected)} features using RF importance")

        return selected, importance

    def select_by_shap(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        n_features: Optional[int] = None,
        classification: bool = True
    ) -> Tuple[List[str], pd.Series]:
        """
        Select features using SHAP values.

        Args:
            X: Feature matrix
            y: Target variable
            n_features: Number of features to select
            classification: Whether this is classification

        Returns:
            Tuple of (selected features, SHAP importance)
        """
        if not SHAP_AVAILABLE:
            self.logger.warning("SHAP not available, using RF importance instead")
            return self.select_by_importance(X, y, n_features, classification)

        n_features = n_features or self.max_features

        self.logger.info(f"Selecting features using SHAP...")

        # Train model
        if classification:
            model = RandomForestClassifier(
                n_estimators=50,
                max_depth=8,
                random_state=self.config.ml.random_seed,
                n_jobs=-1
            )
        else:
            model = RandomForestRegressor(
                n_estimators=50,
                max_depth=8,
                random_state=self.config.ml.random_seed,
                n_jobs=-1
            )

        model.fit(X, y)

        # Calculate SHAP values (use sample for speed)
        sample_size = min(500, len(X))
        X_sample = X.sample(n=sample_size, random_state=self.config.ml.random_seed)

        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_sample)

        # Handle multi-class output
        if isinstance(shap_values, list):
            shap_values = np.abs(shap_values[1])  # Use positive class

        # Calculate mean absolute SHAP value per feature
        shap_importance = pd.Series(
            np.abs(shap_values).mean(axis=0),
            index=X.columns
        )
        shap_importance = shap_importance.sort_values(ascending=False)

        # Select top features
        selected = shap_importance.head(n_features).index.tolist()

        self.feature_scores['shap'] = shap_importance.to_dict()

        self.logger.info(f"Selected {len(selected)} features using SHAP")

        return selected, shap_importance

    def select_features(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        method: str = 'ensemble',
        n_features: Optional[int] = None,
        classification: bool = True,
        remove_correlated: bool = True,
        correlation_threshold: float = 0.95
    ) -> Tuple[List[str], Dict[str, pd.Series]]:
        """
        Select features using specified method or ensemble of methods.

        Args:
            X: Feature matrix
            y: Target variable
            method: Selection method ('mi', 'rfe', 'importance', 'shap', 'ensemble')
            n_features: Number of features to select
            classification: Whether this is classification
            remove_correlated: Whether to remove correlated features first
            correlation_threshold: Correlation threshold

        Returns:
            Tuple of (selected features, all scores dict)
        """
        n_features = n_features or self.max_features

        # Remove correlated features first
        if remove_correlated:
            features_to_keep = self._remove_correlated_features(X, correlation_threshold)
            X = X[features_to_keep]
            self.logger.info(f"Features after correlation filtering: {len(X.columns)}")

        all_scores = {}

        if method == 'mi':
            selected, scores = self.select_by_mutual_info(X, y, n_features, classification)
            all_scores['mutual_info'] = scores

        elif method == 'rfe':
            selected, scores = self.select_by_rfe(X, y, n_features, classification)
            all_scores['rfe'] = scores

        elif method == 'importance':
            selected, scores = self.select_by_importance(X, y, n_features, classification)
            all_scores['rf_importance'] = scores

        elif method == 'shap':
            selected, scores = self.select_by_shap(X, y, n_features, classification)
            all_scores['shap'] = scores

        elif method == 'ensemble':
            # Run all methods and combine
            mi_selected, mi_scores = self.select_by_mutual_info(X, y, n_features * 2, classification)
            imp_selected, imp_scores = self.select_by_importance(X, y, n_features * 2, classification)

            all_scores['mutual_info'] = mi_scores
            all_scores['rf_importance'] = imp_scores

            # Normalize and combine scores
            mi_norm = (mi_scores - mi_scores.min()) / (mi_scores.max() - mi_scores.min() + 1e-10)
            imp_norm = (imp_scores - imp_scores.min()) / (imp_scores.max() - imp_scores.min() + 1e-10)

            combined_scores = (mi_norm + imp_norm) / 2
            combined_scores = combined_scores.sort_values(ascending=False)

            all_scores['combined'] = combined_scores

            selected = combined_scores.head(n_features).index.tolist()

        else:
            raise ValueError(f"Unknown method: {method}")

        self.selected_features = selected

        return selected, all_scores

    def run(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        method: str = 'ensemble',
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            X: Feature matrix
            y: Target variable
            method: Selection method

        Returns:
            AgentResult with selected features
        """
        def execute():
            # Determine if classification or regression
            classification = len(np.unique(y)) <= 10

            # Select features
            selected, scores = self.select_features(
                X, y, method=method,
                classification=classification,
                **kwargs
            )

            return {
                'selected_features': selected,
                'n_selected': len(selected),
                'n_original': len(X.columns),
                'scores': scores,
                'reduction_pct': 1 - len(selected) / len(X.columns),
                'X_selected': X[selected]
            }

        return self._execute_with_timing(execute)


# Test Feature Selection Agent
print("=" * 70)
print("🧪 TESTING FEATURE SELECTION AGENT")
print("=" * 70)

selection_agent = FeatureSelectionAgent(config=config, max_features=30)

if 'feature_agent' in dir() and feature_agent.features is not None:
    X = result.data['X'] if 'result' in dir() and result.success else None
    y = result.data['y'] if 'result' in dir() and result.success else None

    if X is not None and y is not None:
        sel_result = selection_agent.run(X, y, method='ensemble')

        if sel_result.success:
            print(f"\n✅ Feature selection completed!")
            print(f"   Original features: {sel_result.data['n_original']}")
            print(f"   Selected features: {sel_result.data['n_selected']}")
            print(f"   Reduction: {sel_result.data['reduction_pct']*100:.1f}%")
            print(f"\n   Top 10 selected features:")
            for feat in sel_result.data['selected_features'][:10]:
                print(f"      • {feat}")
        else:
            print(f"❌ Error: {sel_result.errors}")
    else:
        print("⚠️ Feature data not available. Run Cell 13 first.")
else:
    print("⚠️ Feature agent not initialized. Run Cell 13 first.")

print("\n" + "=" * 70)
print("✅ Feature Selection Agent ready!")