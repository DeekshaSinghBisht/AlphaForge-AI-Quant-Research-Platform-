"""
regime.py
=========
RegimeDetectionAgent (HMM/GMM)
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture
import warnings
warnings.filterwarnings('ignore')

try:
    from hmmlearn import hmm
    HMM_AVAILABLE = True
    print("✅ hmmlearn available for HMM regime detection")
except ImportError:
    HMM_AVAILABLE = False
    print("⚠️ hmmlearn not available, using GMM for regime detection")


class RegimeDetectionAgent(AnalysisAgent):
    """
    Agent responsible for detecting market regimes.

    Uses Hidden Markov Models (HMM) or Gaussian Mixture Models (GMM)
    to classify market conditions into distinct regimes:
    - Bull market (trending up)
    - Bear market (trending down)
    - Sideways market (low volatility, no trend)
    - High volatility regime

    Attributes:
        model: HMM or GMM model
        n_regimes: Number of regimes to detect
        regime_labels: Mapping of regime numbers to names
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        n_regimes: int = 4
    ):
        """
        Initialize Regime Detection Agent.

        Args:
            config: System configuration
            logger: Logger instance
            n_regimes: Number of regimes to detect
        """
        super().__init__("RegimeDetectionAgent", config, logger)

        self.n_regimes = n_regimes
        self.model = None
        self.scaler = StandardScaler()
        self.is_fitted = False
        self.regime_labels = {}
        self.feature_names = ['returns', 'volatility', 'trend']

    def _prepare_features(
        self,
        returns: pd.Series,
        window: int = 20
    ) -> np.ndarray:
        """
        Prepare features for regime detection.

        Args:
            returns: Returns series
            window: Rolling window for statistics

        Returns:
            Feature matrix
        """
        df = pd.DataFrame()

        # Returns
        df['returns'] = returns

        # Volatility (rolling std)
        df['volatility'] = returns.rolling(window).std()

        # Trend (rolling mean)
        df['trend'] = returns.rolling(window).mean()

        # Momentum
        df['momentum'] = returns.rolling(window).sum()

        # Clean data
        df = df.dropna()

        return df.values, df.index

    def fit(
        self,
        returns: pd.Series,
        method: str = 'hmm'
    ) -> 'RegimeDetectionAgent':
        """
        Fit regime detection model.

        Args:
            returns: Returns series
            method: 'hmm' or 'gmm'

        Returns:
            Self for chaining
        """
        self.logger.info(f"Fitting regime detection model ({method})...")

        # Prepare features
        features, idx = self._prepare_features(returns)

        # Scale features
        features_scaled = self.scaler.fit_transform(features)

        # Fit model
        if method == 'hmm' and HMM_AVAILABLE:
            self.model = hmm.GaussianHMM(
                n_components=self.n_regimes,
                covariance_type='full',
                n_iter=100,
                random_state=self.config.ml.random_seed
            )
            self.model.fit(features_scaled)
        else:
            self.model = GaussianMixture(
                n_components=self.n_regimes,
                covariance_type='full',
                n_init=5,
                random_state=self.config.ml.random_seed
            )
            self.model.fit(features_scaled)

        self.is_fitted = True

        # Label regimes based on characteristics
        self._label_regimes(features, idx, returns)

        self.logger.info(f"Regime detection model fitted with {self.n_regimes} regimes")

        return self

    def _label_regimes(
        self,
        features: np.ndarray,
        idx: pd.DatetimeIndex,
        returns: pd.Series
    ) -> None:
        """
        Assign meaningful labels to detected regimes.

        Args:
            features: Feature matrix
            idx: Index
            returns: Original returns
        """
        # Get regime predictions
        features_scaled = self.scaler.transform(features)

        if HMM_AVAILABLE and hasattr(self.model, 'predict'):
            regimes = self.model.predict(features_scaled)
        else:
            regimes = self.model.predict(features_scaled)

        # Compute regime characteristics
        regime_stats = {}
        for regime in range(self.n_regimes):
            mask = regimes == regime
            if mask.sum() > 0:
                regime_returns = features[mask, 0]  # Returns column
                regime_vol = features[mask, 1]      # Volatility column

                regime_stats[regime] = {
                    'mean_return': np.mean(regime_returns),
                    'mean_volatility': np.mean(regime_vol),
                    'count': mask.sum()
                }

        # Sort regimes by characteristics and assign labels
        sorted_regimes = sorted(
            regime_stats.items(),
            key=lambda x: (x[1]['mean_return'], -x[1]['mean_volatility']),
            reverse=True
        )

        labels = ['bull', 'sideways_up', 'sideways_down', 'bear']
        if self.n_regimes <= 4:
            labels = labels[:self.n_regimes]
        else:
            labels = [f'regime_{i}' for i in range(self.n_regimes)]

        self.regime_labels = {}
        for i, (regime, stats) in enumerate(sorted_regimes):
            if i < len(labels):
                self.regime_labels[regime] = labels[i]
            else:
                self.regime_labels[regime] = f'regime_{regime}'

        self.logger.info(f"Regime labels: {self.regime_labels}")

    def predict(
        self,
        returns: pd.Series
    ) -> pd.Series:
        """
        Predict market regimes.

        Args:
            returns: Returns series

        Returns:
            Series of regime predictions
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")

        # Prepare features
        features, idx = self._prepare_features(returns)

        # Scale features
        features_scaled = self.scaler.transform(features)

        # Predict regimes
        if HMM_AVAILABLE and hasattr(self.model, 'predict'):
            regimes = self.model.predict(features_scaled)
        else:
            regimes = self.model.predict(features_scaled)

        # Create series with regime labels
        regime_series = pd.Series(regimes, index=idx)

        return regime_series

    def predict_proba(
        self,
        returns: pd.Series
    ) -> pd.DataFrame:
        """
        Predict regime probabilities.

        Args:
            returns: Returns series

        Returns:
            DataFrame with regime probabilities
        """
        if not self.is_fitted:
            raise ValueError("Model not fitted. Call fit() first.")

        # Prepare features
        features, idx = self._prepare_features(returns)
        features_scaled = self.scaler.transform(features)

        # Get probabilities
        if HMM_AVAILABLE and hasattr(self.model, 'predict_proba'):
            probs = self.model.predict_proba(features_scaled)
        elif hasattr(self.model, 'predict_proba'):
            probs = self.model.predict_proba(features_scaled)
        else:
            # Use posterior probabilities
            probs = np.zeros((len(features_scaled), self.n_regimes))
            predictions = self.model.predict(features_scaled)
            for i, pred in enumerate(predictions):
                probs[i, pred] = 1.0

        # Create DataFrame
        columns = [self.regime_labels.get(i, f'regime_{i}') for i in range(self.n_regimes)]
        proba_df = pd.DataFrame(probs, index=idx, columns=columns)

        return proba_df

    def get_current_regime(
        self,
        returns: pd.Series
    ) -> Tuple[str, Dict[str, float]]:
        """
        Get current market regime with probabilities.

        Args:
            returns: Returns series

        Returns:
            Tuple of (regime_name, probability_dict)
        """
        regimes = self.predict(returns)
        probs = self.predict_proba(returns)

        current_regime = regimes.iloc[-1]
        current_probs = probs.iloc[-1].to_dict()
        regime_name = self.regime_labels.get(current_regime, f'regime_{current_regime}')

        return regime_name, current_probs

    def generate_regime_features(
        self,
        returns: pd.Series,
        price_df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Generate regime-based features for ML models.

        Args:
            returns: Returns series
            price_df: Price DataFrame

        Returns:
            DataFrame with regime features
        """
        features = pd.DataFrame(index=price_df.index)

        # Get regime predictions
        regimes = self.predict(returns)
        probs = self.predict_proba(returns)

        # Align with price index
        features['regime'] = regimes.reindex(features.index, method='ffill')

        # One-hot encode regimes
        for regime_num, regime_name in self.regime_labels.items():
            features[f'regime_{regime_name}'] = (features['regime'] == regime_num).astype(int)

        # Add regime probabilities
        for col in probs.columns:
            features[f'regime_prob_{col}'] = probs[col].reindex(features.index, method='ffill')

        # Regime duration
        regime_changes = features['regime'].diff().fillna(0) != 0
        features['regime_duration'] = (~regime_changes).cumsum()
        features['regime_duration'] = features.groupby(
            (regime_changes).cumsum()
        )['regime_duration'].transform(lambda x: range(len(x)))

        return features.fillna(0)

    def analyze(
        self,
        data: pd.DataFrame,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Analyze regime distribution.

        Args:
            data: Price/returns data

        Returns:
            Analysis results
        """
        if 'Returns' in data.columns:
            returns = data['Returns'].dropna()
        elif 'returns' in data.columns:
            returns = data['returns'].dropna()
        else:
            returns = data['Close'].pct_change().dropna()

        # Fit model
        self.fit(returns)

        # Get predictions
        regimes = self.predict(returns)

        # Compute statistics
        regime_counts = regimes.value_counts()
        regime_pcts = regime_counts / len(regimes)

        self.analysis_results = {
            'regime_counts': regime_counts.to_dict(),
            'regime_percentages': regime_pcts.to_dict(),
            'regime_labels': self.regime_labels,
            'n_regimes': self.n_regimes,
            'current_regime': self.regime_labels.get(regimes.iloc[-1], 'unknown')
        }

        return self.analysis_results

    def run(
        self,
        data: pd.DataFrame,
        fit_model: bool = True,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            data: Price/returns DataFrame
            fit_model: Whether to fit the model

        Returns:
            AgentResult with regime analysis
        """
        def execute():
            # Extract returns
            if 'Returns' in data.columns:
                returns = data['Returns'].dropna()
            elif 'returns' in data.columns:
                returns = data['returns'].dropna()
            else:
                returns = data['Close'].pct_change().dropna()

            # Fit model if needed
            if fit_model or not self.is_fitted:
                self.fit(returns)

            # Generate predictions
            regimes = self.predict(returns)
            probs = self.predict_proba(returns)

            # Generate features
            regime_features = self.generate_regime_features(returns, data)

            # Current regime
            current_regime, current_probs = self.get_current_regime(returns)

            # Analysis
            analysis = self.analyze(data)

            return {
                'regimes': regimes,
                'probabilities': probs,
                'regime_features': regime_features,
                'current_regime': current_regime,
                'current_probabilities': current_probs,
                'analysis': analysis,
                'regime_labels': self.regime_labels
            }

        return self._execute_with_timing(execute)


# Test Regime Detection Agent
print("=" * 70)
print("🧪 TESTING REGIME DETECTION AGENT")
print("=" * 70)

regime_agent = RegimeDetectionAgent(config=config, n_regimes=4)

if 'data_agent' in dir() and data_agent.data:
    test_df = data_agent.data.get('AAPL', list(data_agent.data.values())[0])
    result = regime_agent.run(test_df)

    if result.success:
        print(f"\n✅ Regime detection completed!")
        print(f"   Current regime: {result.data['current_regime']}")
        print(f"   Regime probabilities: {result.data['current_probabilities']}")
        print(f"\n   Regime distribution:")
        for regime, pct in result.data['analysis']['regime_percentages'].items():
            label = result.data['regime_labels'].get(regime, f'regime_{regime}')
            print(f"      {label}: {pct*100:.1f}%")
    else:
        print(f"❌ Error: {result.errors}")
else:
    print("⚠️ No market data available. Run Cell 10 first.")

print("\n" + "=" * 70)
print("✅ Regime Detection Agent ready!")