"""
sentiment.py
============
SentimentAgent (VADER + FinBERT)
"""
from __future__ import annotations
from quant_research.config import SystemConfig
from quant_research.base import BaseAgent, MLAgent, DataAgent, AnalysisAgent, AgentResult
from quant_research.utils import (save_to_cache, load_from_cache,
    calculate_returns, calculate_sharpe_ratio, calculate_max_drawdown)


import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Union, Tuple
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Import sentiment analysis libraries
try:
    from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline
    import torch
    TRANSFORMERS_AVAILABLE = True
    print("✅ Transformers library available for FinBERT")
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    print("⚠️ Transformers not available, using VADER only")

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


class SentimentAgent(AnalysisAgent):
    """
    Agent responsible for sentiment analysis of financial text.

    Uses:
    - FinBERT for financial domain-specific sentiment
    - VADER for general sentiment analysis

    Combines both approaches for robust sentiment scoring.

    Attributes:
        vader: VADER sentiment analyzer
        finbert: FinBERT pipeline (if available)
    """

    def __init__(
        self,
        config: Optional[SystemConfig] = None,
        logger: Optional[QuantLogger] = None,
        use_finbert: bool = True,
        use_vader: bool = True
    ):
        """
        Initialize Sentiment Agent.

        Args:
            config: System configuration
            logger: Logger instance
            use_finbert: Whether to use FinBERT
            use_vader: Whether to use VADER
        """
        super().__init__("SentimentAgent", config, logger)

        self.use_finbert = use_finbert and TRANSFORMERS_AVAILABLE
        self.use_vader = use_vader

        # Initialize VADER
        if self.use_vader:
            self.vader = SentimentIntensityAnalyzer()
            self.logger.info("VADER sentiment analyzer initialized")

        # Initialize FinBERT
        self.finbert = None
        if self.use_finbert:
            self._initialize_finbert()

    def _initialize_finbert(self) -> None:
        """Initialize FinBERT model."""
        try:
            model_name = self.config.sentiment.finbert_model
            self.logger.info(f"Loading FinBERT model: {model_name}")

            self.finbert = pipeline(
                "sentiment-analysis",
                model=model_name,
                tokenizer=model_name,
                device=-1  # CPU
            )

            self.logger.info("FinBERT model loaded successfully")
        except Exception as e:
            self.logger.warning(f"Failed to load FinBERT: {e}")
            self.use_finbert = False
            self.finbert = None

    def analyze_text_vader(self, text: str) -> Dict[str, float]:
        """
        Analyze text sentiment using VADER.

        Args:
            text: Text to analyze

        Returns:
            Dictionary with sentiment scores
        """
        if not self.use_vader or not text:
            return {'compound': 0.0, 'positive': 0.0, 'negative': 0.0, 'neutral': 1.0}

        scores = self.vader.polarity_scores(text)
        return {
            'compound': scores['compound'],
            'positive': scores['pos'],
            'negative': scores['neg'],
            'neutral': scores['neu']
        }

    def analyze_text_finbert(self, text: str) -> Dict[str, float]:
        """
        Analyze text sentiment using FinBERT.

        Args:
            text: Text to analyze

        Returns:
            Dictionary with sentiment scores
        """
        if not self.use_finbert or self.finbert is None or not text:
            return {'label': 'neutral', 'score': 0.0}

        try:
            # Truncate text if too long
            max_length = self.config.sentiment.finbert_max_length
            text = text[:max_length]

            result = self.finbert(text)[0]

            # Map FinBERT labels to scores
            label = result['label'].lower()
            score = result['score']

            if label == 'positive':
                sentiment_score = score
            elif label == 'negative':
                sentiment_score = -score
            else:
                sentiment_score = 0.0

            return {
                'label': label,
                'score': sentiment_score,
                'confidence': score
            }
        except Exception as e:
            self.logger.warning(f"FinBERT analysis failed: {e}")
            return {'label': 'neutral', 'score': 0.0, 'confidence': 0.0}

    def analyze_text(self, text: str) -> Dict[str, float]:
        """
        Analyze text using all available methods.

        Args:
            text: Text to analyze

        Returns:
            Combined sentiment scores
        """
        result = {}

        # VADER analysis
        if self.use_vader:
            vader_result = self.analyze_text_vader(text)
            result['vader_compound'] = vader_result['compound']
            result['vader_positive'] = vader_result['positive']
            result['vader_negative'] = vader_result['negative']

        # FinBERT analysis
        if self.use_finbert:
            finbert_result = self.analyze_text_finbert(text)
            result['finbert_score'] = finbert_result['score']
            result['finbert_label'] = finbert_result.get('label', 'neutral')

        # Combined score (weighted average)
        if self.use_vader and self.use_finbert:
            result['combined_score'] = (
                0.4 * result['vader_compound'] +
                0.6 * result.get('finbert_score', 0)
            )
        elif self.use_vader:
            result['combined_score'] = result['vader_compound']
        elif self.use_finbert:
            result['combined_score'] = result.get('finbert_score', 0)
        else:
            result['combined_score'] = 0.0

        return result

    def analyze_news(
        self,
        news_data: Union[List[Dict], pd.DataFrame]
    ) -> pd.DataFrame:
        """
        Analyze sentiment for a collection of news articles.

        Args:
            news_data: List of news dicts or DataFrame

        Returns:
            DataFrame with sentiment scores
        """
        if isinstance(news_data, pd.DataFrame):
            df = news_data.copy()
        else:
            df = pd.DataFrame(news_data)

        if df.empty:
            self.logger.warning("No news data to analyze")
            return df

        self.logger.info(f"Analyzing sentiment for {len(df)} articles...")

        # Analyze each article
        sentiment_results = []
        for idx, row in df.iterrows():
            # Combine headline and summary
            text = str(row.get('headline', ''))
            if 'summary' in row and pd.notna(row['summary']):
                text += " " + str(row['summary'])

            sentiment = self.analyze_text(text)
            sentiment_results.append(sentiment)

        # Add sentiment columns
        sentiment_df = pd.DataFrame(sentiment_results)
        for col in sentiment_df.columns:
            df[col] = sentiment_df[col].values

        self.logger.info("Sentiment analysis completed")

        return df

    def aggregate_sentiment_by_date(
        self,
        sentiment_df: pd.DataFrame,
        date_col: str = 'date',
        ticker_col: str = 'ticker'
    ) -> pd.DataFrame:
        """
        Aggregate daily sentiment scores.

        Args:
            sentiment_df: DataFrame with sentiment scores
            date_col: Date column name
            ticker_col: Ticker column name

        Returns:
            Daily aggregated sentiment
        """
        if sentiment_df.empty:
            return pd.DataFrame()

        # Ensure date column exists
        if date_col not in sentiment_df.columns:
            if 'datetime' in sentiment_df.columns:
                sentiment_df[date_col] = pd.to_datetime(sentiment_df['datetime']).dt.date

        # Group by date and ticker
        agg_cols = ['combined_score']
        if 'vader_compound' in sentiment_df.columns:
            agg_cols.append('vader_compound')
        if 'finbert_score' in sentiment_df.columns:
            agg_cols.append('finbert_score')

        agg_dict = {col: ['mean', 'std', 'count'] for col in agg_cols if col in sentiment_df.columns}

        if ticker_col in sentiment_df.columns:
            aggregated = sentiment_df.groupby([ticker_col, date_col]).agg(agg_dict)
        else:
            aggregated = sentiment_df.groupby(date_col).agg(agg_dict)

        # Flatten column names
        aggregated.columns = ['_'.join(col).strip() for col in aggregated.columns.values]

        return aggregated.reset_index()

    def compute_sentiment_features(
        self,
        sentiment_df: pd.DataFrame,
        price_df: pd.DataFrame,
        ticker: str
    ) -> pd.DataFrame:
        """
        Compute sentiment-derived features aligned with price data.

        Args:
            sentiment_df: Aggregated sentiment data
            price_df: Price data with datetime index
            ticker: Ticker symbol

        Returns:
            DataFrame with sentiment features
        """
        features = pd.DataFrame(index=price_df.index)

        # Filter sentiment for this ticker
        if 'ticker' in sentiment_df.columns:
            ticker_sentiment = sentiment_df[sentiment_df['ticker'] == ticker].copy()
        else:
            ticker_sentiment = sentiment_df.copy()

        if ticker_sentiment.empty:
            # Return zeros if no sentiment data
            features['sentiment_score'] = 0.0
            features['sentiment_momentum'] = 0.0
            features['news_volume'] = 0.0
            return features

        # Set date as index
        if 'date' in ticker_sentiment.columns:
            ticker_sentiment['date'] = pd.to_datetime(ticker_sentiment['date'])
            ticker_sentiment = ticker_sentiment.set_index('date')

        # Reindex to match price data
        sentiment_cols = ['combined_score_mean']
        for col in sentiment_cols:
            if col in ticker_sentiment.columns:
                # Forward fill sentiment to trading days
                features['sentiment_score'] = ticker_sentiment[col].reindex(
                    features.index, method='ffill'
                ).fillna(0)

        # Sentiment momentum
        if 'sentiment_score' in features.columns:
            features['sentiment_momentum'] = features['sentiment_score'].diff(5)
            features['sentiment_ma_5'] = features['sentiment_score'].rolling(5).mean()
            features['sentiment_ma_20'] = features['sentiment_score'].rolling(20).mean()

        # News volume
        if 'combined_score_count' in ticker_sentiment.columns:
            features['news_volume'] = ticker_sentiment['combined_score_count'].reindex(
                features.index, method='ffill'
            ).fillna(0)

        return features.fillna(0)

    def analyze(
        self,
        data: pd.DataFrame,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Perform complete sentiment analysis.

        Args:
            data: News DataFrame

        Returns:
            Analysis results
        """
        # Analyze sentiment
        sentiment_df = self.analyze_news(data)

        # Aggregate by date
        aggregated = self.aggregate_sentiment_by_date(sentiment_df)

        # Compute summary statistics
        self.analysis_results = {
            'total_articles': len(sentiment_df),
            'avg_sentiment': sentiment_df['combined_score'].mean() if 'combined_score' in sentiment_df else 0,
            'sentiment_std': sentiment_df['combined_score'].std() if 'combined_score' in sentiment_df else 0,
            'positive_ratio': (sentiment_df['combined_score'] > 0.1).mean() if 'combined_score' in sentiment_df else 0,
            'negative_ratio': (sentiment_df['combined_score'] < -0.1).mean() if 'combined_score' in sentiment_df else 0,
        }

        return self.analysis_results

    def run(
        self,
        news_data: Union[pd.DataFrame, Dict[str, List]],
        price_data: Optional[Dict[str, pd.DataFrame]] = None,
        **kwargs
    ) -> AgentResult:
        """
        Main execution method.

        Args:
            news_data: News DataFrame or dict
            price_data: Optional price data for feature alignment

        Returns:
            AgentResult with sentiment analysis
        """
        def execute():
            # Convert to DataFrame if needed
            if isinstance(news_data, dict):
                # Flatten news by ticker
                all_news = []
                for ticker, articles in news_data.items():
                    for article in articles:
                        if isinstance(article, dict):
                            article['ticker'] = ticker
                            all_news.append(article)
                        else:
                            all_news.append({
                                'ticker': ticker,
                                'headline': article.headline,
                                'summary': article.summary,
                                'datetime': article.datetime
                            })
                df = pd.DataFrame(all_news)
            else:
                df = news_data

            # Analyze sentiment
            sentiment_df = self.analyze_news(df)
            aggregated = self.aggregate_sentiment_by_date(sentiment_df)

            # Compute features if price data available
            sentiment_features = {}
            if price_data:
                for ticker, price_df in price_data.items():
                    features = self.compute_sentiment_features(
                        aggregated, price_df, ticker
                    )
                    sentiment_features[ticker] = features

            # Analysis summary
            analysis = self.analyze(sentiment_df)

            return {
                'sentiment_df': sentiment_df,
                'aggregated': aggregated,
                'sentiment_features': sentiment_features,
                'analysis': analysis
            }

        return self._execute_with_timing(execute)


# Test Sentiment Agent
print("=" * 70)
print("🧪 TESTING SENTIMENT AGENT")
print("=" * 70)

sentiment_agent = SentimentAgent(config=config, use_finbert=False)  # Use VADER only for speed

# Test with sample text
sample_texts = [
    "Apple reports record quarterly earnings, stock surges 5%",
    "Tech company faces major lawsuit, shares plummet",
    "Market remains stable amid uncertainty",
    "Strong growth outlook drives investor confidence",
    "Company announces layoffs amid restructuring concerns"
]

print("\n📊 Sample Sentiment Analysis:")
for text in sample_texts:
    sentiment = sentiment_agent.analyze_text(text)
    score = sentiment.get('combined_score', sentiment.get('vader_compound', 0))
    emoji = "📈" if score > 0.1 else "📉" if score < -0.1 else "➡️"
    print(f"  {emoji} {score:+.3f}: {text[:50]}...")

# Test with news data if available
if 'news_agent' in dir() and news_agent.news_data:
    news_df = news_agent.to_dataframe()
    if not news_df.empty:
        result = sentiment_agent.run(news_df)
        if result.success:
            print(f"\n✅ Sentiment analysis completed!")
            print(f"   Analysis: {result.data['analysis']}")

print("\n" + "=" * 70)
print("✅ Sentiment Agent ready!")