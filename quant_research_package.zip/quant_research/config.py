"""
config.py
=========
PathManager  – storage paths (Colab / local)
APIConfig    – API keys and endpoints
SystemConfig + all sub-dataclasses (DataConfig, MLConfig, …)
"""

import os
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional

# Detect environment
IN_COLAB = 'google.colab' in sys.modules

class PathManager:
    """
    Manages all paths for the quantitative research system.
    Handles both Colab and local environments.
    """

    def __init__(self, project_name: str = "quant_research_system"):
        """
        Initialize path manager.

        Args:
            project_name: Name of the project folder
        """
        self.project_name = project_name
        self.in_colab = IN_COLAB
        self._setup_paths()

    def _setup_paths(self) -> None:
        """Setup all necessary paths based on environment."""

        if self.in_colab:
            # Mount Google Drive
            from google.colab import drive
            drive.mount('/content/drive', force_remount=False)
            self.base_path = Path(f'/content/drive/MyDrive/{self.project_name}')
        else:
            # Local environment
            self.base_path = Path.cwd() / self.project_name

        # Define subdirectories
        self.paths = {
            'base': self.base_path,
            'data': self.base_path / 'data',
            'raw_data': self.base_path / 'data' / 'raw',
            'processed_data': self.base_path / 'data' / 'processed',
            'features': self.base_path / 'data' / 'features',
            'models': self.base_path / 'models',
            'checkpoints': self.base_path / 'models' / 'checkpoints',
            'results': self.base_path / 'results',
            'backtests': self.base_path / 'results' / 'backtests',
            'reports': self.base_path / 'results' / 'reports',
            'logs': self.base_path / 'logs',
            'cache': self.base_path / 'cache',
            'config': self.base_path / 'config',
        }

        # Create all directories
        for path_name, path in self.paths.items():
            path.mkdir(parents=True, exist_ok=True)

        print(f"{'=' * 70}")
        print(f"📁 PATH CONFIGURATION")
        print(f"{'=' * 70}")
        print(f"Environment: {'Google Colab' if self.in_colab else 'Local'}")
        print(f"Base Path: {self.base_path}")
        print(f"{'=' * 70}")
        print("📂 Directory Structure Created:")
        for name, path in self.paths.items():
            exists = "✅" if path.exists() else "❌"
            print(f"  {exists} {name}: {path}")
        print(f"{'=' * 70}")

    def get_path(self, path_name: str) -> Path:
        """Get path by name."""
        return self.paths.get(path_name, self.base_path)

    def get_timestamped_path(self, path_name: str, filename: str,
                             extension: str = "") -> Path:
        """Get a timestamped file path."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if extension and not extension.startswith('.'):
            extension = f".{extension}"
        return self.paths[path_name] / f"{filename}_{timestamp}{extension}"

    def list_files(self, path_name: str, pattern: str = "*") -> list:
        """List files in a directory matching pattern."""
        path = self.paths.get(path_name)
        if path and path.exists():
            return list(path.glob(pattern))
        return []

    def get_latest_file(self, path_name: str, pattern: str = "*") -> Optional[Path]:
        """Get the most recent file matching pattern."""
        files = self.list_files(path_name, pattern)
        if files:
            return max(files, key=lambda x: x.stat().st_mtime)
        return None

    def clear_cache(self) -> None:
        """Clear the cache directory."""
        import shutil
        cache_path = self.paths['cache']
        if cache_path.exists():
            shutil.rmtree(cache_path)
            cache_path.mkdir(parents=True, exist_ok=True)
            print("🗑️ Cache cleared successfully")

# Initialize path manager
path_manager = PathManager()

# Create convenience variables
BASE_PATH = path_manager.paths['base']
DATA_PATH = path_manager.paths['data']
RAW_DATA_PATH = path_manager.paths['raw_data']
PROCESSED_DATA_PATH = path_manager.paths['processed_data']
FEATURES_PATH = path_manager.paths['features']
MODELS_PATH = path_manager.paths['models']
CHECKPOINTS_PATH = path_manager.paths['checkpoints']
RESULTS_PATH = path_manager.paths['results']
BACKTESTS_PATH = path_manager.paths['backtests']
REPORTS_PATH = path_manager.paths['reports']
LOGS_PATH = path_manager.paths['logs']
CACHE_PATH = path_manager.paths['cache']
CONFIG_PATH = path_manager.paths['config']

print("\n✅ Path manager initialized and ready!")


import os
import json
from dataclasses import dataclass, asdict
from typing import Optional
from pathlib import Path

FINNHUB_API_KEY = "d6qomthr01qgdhqbpbi0d6qomthr01qgdhqbpbig"  #@param {type:"string"}

FRED_API_KEY = "a7cd1fb86359a640a68b7314c8dc6c48"  #@param {type:"string"}

ALPHA_VANTAGE_API_KEY = "XW8DZSK6V24ZTAGE"  #@param {type:"string"}

@dataclass
class APIConfig:
    """Configuration for all API keys and endpoints."""

    finnhub_api_key: str = ""
    fred_api_key: str = ""
    alpha_vantage_api_key: str = ""

    # API Endpoints
    finnhub_base_url: str = "https://finnhub.io/api/v1"
    fred_base_url: str = "https://api.stlouisfed.org/fred"
    alpha_vantage_base_url: str = "https://www.alphavantage.co/query"

    # Rate Limits (calls per minute)
    finnhub_rate_limit: int = 60
    fred_rate_limit: int = 120
    alpha_vantage_rate_limit: int = 5

    def save(self, path: Path) -> None:
        """Save API config to JSON file."""
        config_file = path / "api_config.json"
        # Don't save actual keys, just a template
        safe_config = asdict(self)
        for key in ['finnhub_api_key', 'fred_api_key', 'alpha_vantage_api_key']:
            if safe_config[key]:
                safe_config[key] = "***CONFIGURED***"
        with open(config_file, 'w') as f:
            json.dump(safe_config, f, indent=2)
        print(f"✅ API config template saved to {config_file}")

    def validate(self) -> dict:
        """Validate API keys and return status."""
        status = {}

        # Check Finnhub
        if self.finnhub_api_key:
            try:
                import finnhub
                client = finnhub.Client(api_key=self.finnhub_api_key)
                # Test with a simple call
                client.company_profile2(symbol='AAPL')
                status['finnhub'] = {'status': 'valid', 'message': 'API key validated'}
            except Exception as e:
                status['finnhub'] = {'status': 'invalid', 'message': str(e)}
        else:
            status['finnhub'] = {'status': 'not_configured', 'message': 'No API key provided'}

        # Check FRED
        if self.fred_api_key:
            try:
                from fredapi import Fred
                fred = Fred(api_key=self.fred_api_key)
                # Test with a simple call
                fred.get_series('GDP', limit=1)
                status['fred'] = {'status': 'valid', 'message': 'API key validated'}
            except Exception as e:
                status['fred'] = {'status': 'invalid', 'message': str(e)}
        else:
            status['fred'] = {'status': 'not_configured', 'message': 'No API key provided'}

        return status

# Initialize API config
api_config = APIConfig(
    finnhub_api_key=FINNHUB_API_KEY,
    fred_api_key=FRED_API_KEY,
    alpha_vantage_api_key=ALPHA_VANTAGE_API_KEY
)

# Store in environment variables for security
os.environ['FINNHUB_API_KEY'] = FINNHUB_API_KEY
os.environ['FRED_API_KEY'] = FRED_API_KEY
os.environ['ALPHA_VANTAGE_API_KEY'] = ALPHA_VANTAGE_API_KEY

# Display configuration status
print("=" * 70)
print("🔑 API CONFIGURATION STATUS")
print("=" * 70)

api_status = {
    'Finnhub': '✅ Configured' if FINNHUB_API_KEY else '⚠️ Not configured (news data unavailable)',
    'FRED': '✅ Configured' if FRED_API_KEY else '⚠️ Not configured (macro data unavailable)',
    'Alpha Vantage': '✅ Configured' if ALPHA_VANTAGE_API_KEY else '⚠️ Not configured (optional)',
}

for api, status in api_status.items():
    print(f"  {api}: {status}")

print("=" * 70)

# Validate if keys are provided
if FINNHUB_API_KEY or FRED_API_KEY:
    print("\n🔍 Validating API keys...")
    validation_results = api_config.validate()
    for api, result in validation_results.items():
        status_icon = "✅" if result['status'] == 'valid' else "❌" if result['status'] == 'invalid' else "⚠️"
        print(f"  {status_icon} {api.upper()}: {result['message']}")

# Save config template
api_config.save(CONFIG_PATH)

print("\n✅ API configuration complete!")


from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, date
from enum import Enum
import json

class ModelType(Enum):
    """Enumeration of available model types."""
    LOGISTIC_REGRESSION = "logistic_regression"
    RANDOM_FOREST = "random_forest"
    XGBOOST = "xgboost"
    LIGHTGBM = "lightgbm"
    LSTM = "lstm"
    TRANSFORMER = "transformer"

class RegimeType(Enum):
    """Market regime types."""
    BULL = "bull"
    BEAR = "bear"
    SIDEWAYS = "sideways"
    HIGH_VOLATILITY = "high_volatility"

class SignalType(Enum):
    """Trading signal types."""
    BUY = 1
    HOLD = 0
    SELL = -1

@dataclass
class DataConfig:
    """Configuration for data fetching and processing."""

    # Tickers to analyze
    tickers: List[str] = field(default_factory=lambda: [
        "AAPL", "MSFT", "TSLA", "NVDA", "GOOGL", "AMZN"
    ])

    # Benchmark for comparison
    benchmark_ticker: str = "SPY"

    # Date range
    start_date: str = "2010-01-01"
    end_date: Optional[str] = None  # None means today

    # Data quality
    min_data_points: int = 252  # Minimum 1 year of data
    max_missing_pct: float = 0.05  # Maximum 5% missing data

    # Caching
    cache_expiry_hours: int = 24
    use_cache: bool = True

    def get_end_date(self) -> str:
        """Get end date, defaulting to today if not specified."""
        if self.end_date is None:
            return datetime.today().strftime('%Y-%m-%d')
        return self.end_date

@dataclass
class FeatureConfig:
    """Configuration for feature engineering."""

    # Moving Average periods
    ma_periods: List[int] = field(default_factory=lambda: [5, 10, 20, 50, 100, 200])

    # RSI configuration
    rsi_period: int = 14
    rsi_overbought: float = 70.0
    rsi_oversold: float = 30.0

    # MACD configuration
    macd_fast: int = 12
    macd_slow: int = 26
    macd_signal: int = 9

    # Bollinger Bands
    bb_period: int = 20
    bb_std: float = 2.0

    # ATR
    atr_period: int = 14

    # Volume indicators
    volume_ma_period: int = 20

    # Lag features
    lag_periods: List[int] = field(default_factory=lambda: [1, 5, 10, 20])

    # Rolling statistics windows
    rolling_windows: List[int] = field(default_factory=lambda: [5, 10, 20, 60])

    # Target definition
    target_horizon: int = 1  # Days ahead to predict
    target_type: str = "binary"  # "binary" or "regression"

    # Feature selection
    max_features: int = 50
    feature_selection_method: str = "mutual_info"  # "mutual_info", "rfe", "shap"

@dataclass
class MLConfig:
    """Configuration for machine learning models."""

    # Random seed for reproducibility
    random_seed: int = 42

    # Validation strategy
    validation_method: str = "walk_forward"  # "walk_forward", "expanding", "kfold"
    n_splits: int = 5
    train_ratio: float = 0.7
    val_ratio: float = 0.15
    test_ratio: float = 0.15
    gap_days: int = 1  # Gap between train and test to prevent leakage

    # Walk-forward specific
    min_train_size: int = 252  # Minimum training window (1 year)
    step_size: int = 21  # Step forward (1 month)

    # LSTM specific
    sequence_length: int = 20
    lstm_units: List[int] = field(default_factory=lambda: [128, 64])
    lstm_dropout: float = 0.3
    use_attention: bool = True

    # Training parameters
    epochs: int = 100
    batch_size: int = 32
    early_stopping_patience: int = 10
    learning_rate: float = 0.001

    # Ensemble configuration
    ensemble_method: str = "stacking"  # "stacking", "voting", "weighted"
    base_models: List[str] = field(default_factory=lambda: [
        "logistic_regression", "random_forest", "xgboost", "lstm"
    ])

    # Hyperparameter optimization
    use_optuna: bool = True
    optuna_trials: int = 50
    optuna_timeout: int = 3600  # seconds

@dataclass
class BacktestConfig:
    """Configuration for backtesting."""

    # Capital
    initial_capital: float = 100000.0

    # Transaction costs
    commission_pct: float = 0.001  # 0.1% commission
    slippage_pct: float = 0.0005  # 0.05% slippage

    # Market impact model: impact = k * sqrt(order_size / ADV)
    market_impact_k: float = 0.1

    # Position sizing
    max_position_pct: float = 0.20  # Maximum 20% in single position
    min_position_pct: float = 0.02  # Minimum 2% if entering

    # Liquidity constraints
    max_adv_pct: float = 0.05  # Maximum 5% of average daily volume

    # Risk controls
    stop_loss_pct: float = 0.05  # 5% stop loss
    take_profit_pct: float = 0.10  # 10% take profit
    max_drawdown_pct: float = 0.15  # Circuit breaker at 15% drawdown

    # Execution
    execution_delay: int = 1  # Execute next day at open

@dataclass
class RiskConfig:
    """Configuration for risk analysis."""

    # VaR/CVaR
    var_confidence_levels: List[float] = field(default_factory=lambda: [0.95, 0.99])

    # Monte Carlo
    monte_carlo_simulations: int = 10000
    monte_carlo_horizon: int = 252  # 1 year

    # Rolling windows
    rolling_volatility_window: int = 21
    rolling_sharpe_window: int = 63

    # Risk-free rate
    risk_free_rate: float = 0.05  # 5% annual

    # Stress test periods
    stress_periods: Dict[str, Tuple[str, str]] = field(default_factory=lambda: {
        "2008_financial_crisis": ("2008-09-01", "2009-03-31"),
        "2011_eu_debt_crisis": ("2011-08-01", "2011-11-30"),
        "2015_china_crash": ("2015-08-01", "2015-09-30"),
        "2018_q4_selloff": ("2018-10-01", "2018-12-31"),
        "2020_covid_crash": ("2020-02-15", "2020-04-15"),
        "2022_inflation_bear": ("2022-01-01", "2022-10-31"),
    })

@dataclass
class PortfolioConfig:
    """Configuration for portfolio optimization."""

    # Optimization methods
    optimization_method: str = "max_sharpe"  # "max_sharpe", "min_variance", "risk_parity", "hrp"

    # Constraints
    max_weight: float = 0.25  # Maximum 25% in single asset
    min_weight: float = 0.02  # Minimum 2% if included

    # Rebalancing
    rebalance_frequency: str = "monthly"  # "daily", "weekly", "monthly", "quarterly"
    turnover_constraint: float = 0.20  # Maximum 20% turnover per rebalance

@dataclass
class SentimentConfig:
    """Configuration for sentiment analysis."""

    # Models to use
    use_finbert: bool = True
    use_vader: bool = True

    # Aggregation
    sentiment_window: int = 5  # Days to aggregate sentiment
    min_news_count: int = 3  # Minimum news items for valid sentiment

    # FinBERT model
    finbert_model: str = "ProsusAI/finbert"
    finbert_max_length: int = 512

print("✅ Configuration data classes defined!")


from dataclasses import dataclass, field, asdict
from typing import Dict, Any
import json
from pathlib import Path

@dataclass
class SystemConfig:
    """
    Master configuration class that aggregates all sub-configurations.
    This is the single source of truth for all system parameters.
    """

    # Sub-configurations
    data: DataConfig = field(default_factory=DataConfig)
    features: FeatureConfig = field(default_factory=FeatureConfig)
    ml: MLConfig = field(default_factory=MLConfig)
    backtest: BacktestConfig = field(default_factory=BacktestConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    portfolio: PortfolioConfig = field(default_factory=PortfolioConfig)
    sentiment: SentimentConfig = field(default_factory=SentimentConfig)

    # System settings
    debug_mode: bool = False
    verbose: bool = True
    log_level: str = "INFO"

    # Reproducibility
    global_seed: int = 42

    def to_dict(self) -> Dict[str, Any]:
        """Convert entire configuration to dictionary."""
        return {
            'data': asdict(self.data),
            'features': asdict(self.features),
            'ml': asdict(self.ml),
            'backtest': asdict(self.backtest),
            'risk': asdict(self.risk),
            'portfolio': asdict(self.portfolio),
            'sentiment': asdict(self.sentiment),
            'debug_mode': self.debug_mode,
            'verbose': self.verbose,
            'log_level': self.log_level,
            'global_seed': self.global_seed,
        }

    def save(self, filepath: Path) -> None:
        """Save configuration to JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2, default=str)
        print(f"✅ Configuration saved to {filepath}")

    @classmethod
    def load(cls, filepath: Path) -> 'SystemConfig':
        """Load configuration from JSON file."""
        with open(filepath, 'r') as f:
            config_dict = json.load(f)

        # Reconstruct dataclasses
        config = cls(
            data=DataConfig(**config_dict.get('data', {})),
            features=FeatureConfig(**config_dict.get('features', {})),
            ml=MLConfig(**config_dict.get('ml', {})),
            backtest=BacktestConfig(**config_dict.get('backtest', {})),
            risk=RiskConfig(**{k: v for k, v in config_dict.get('risk', {}).items()
                              if k != 'stress_periods'}),
            portfolio=PortfolioConfig(**config_dict.get('portfolio', {})),
            sentiment=SentimentConfig(**config_dict.get('sentiment', {})),
            debug_mode=config_dict.get('debug_mode', False),
            verbose=config_dict.get('verbose', True),
            log_level=config_dict.get('log_level', 'INFO'),
            global_seed=config_dict.get('global_seed', 42),
        )
        return config

    def display(self) -> None:
        """Display configuration summary."""
        print("=" * 70)
        print("📋 SYSTEM CONFIGURATION SUMMARY")
        print("=" * 70)

        print("\n📊 DATA CONFIGURATION:")
        print(f"  • Tickers: {', '.join(self.data.tickers)}")
        print(f"  • Benchmark: {self.data.benchmark_ticker}")
        print(f"  • Date Range: {self.data.start_date} to {self.data.get_end_date()}")

        print("\n🔧 FEATURE CONFIGURATION:")
        print(f"  • MA Periods: {self.features.ma_periods}")
        print(f"  • Target Horizon: {self.features.target_horizon} days")
        print(f"  • Max Features: {self.features.max_features}")

        print("\n🤖 ML CONFIGURATION:")
        print(f"  • Validation: {self.ml.validation_method}")
        print(f"  • Splits: {self.ml.n_splits}")
        print(f"  • Ensemble: {self.ml.ensemble_method}")
        print(f"  • Base Models: {', '.join(self.ml.base_models)}")

        print("\n📈 BACKTEST CONFIGURATION:")
        print(f"  • Initial Capital: ${self.backtest.initial_capital:,.2f}")
        print(f"  • Commission: {self.backtest.commission_pct*100:.2f}%")
        print(f"  • Slippage: {self.backtest.slippage_pct*100:.3f}%")
        print(f"  • Max Position: {self.backtest.max_position_pct*100:.0f}%")

        print("\n⚠️ RISK CONFIGURATION:")
        print(f"  • VaR Levels: {self.risk.var_confidence_levels}")
        print(f"  • Monte Carlo Sims: {self.risk.monte_carlo_simulations:,}")
        print(f"  • Risk-free Rate: {self.risk.risk_free_rate*100:.1f}%")

        print("\n" + "=" * 70)


# Initialize global configuration
config = SystemConfig()

# Save default configuration
config.save(CONFIG_PATH / "system_config.json")

# Display configuration
config.display()

# Set random seeds for reproducibility
import numpy as np
import random

def set_seeds(seed: int = 42) -> None:
    """Set all random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)

    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except ImportError:
        pass

    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass

    print(f"🎲 Random seeds set to {seed}")

set_seeds(config.global_seed)

print("\n✅ Configuration system initialized!")