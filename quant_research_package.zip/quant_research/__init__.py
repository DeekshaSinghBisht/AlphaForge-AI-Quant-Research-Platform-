"""
AI Quantitative Research System
================================
A multi-agent ML framework for stock price direction prediction.

Package layout
--------------
quant_research/
├── config.py          – PathManager, APIConfig, SystemConfig, all dataclasses
├── utils.py           – Shared helper functions, caching, metrics
├── base.py            – BaseAgent, MLAgent, DataAgent, AnalysisAgent, types
├── agents/
│   ├── data.py        – MarketDataAgent, NewsAgent
│   ├── features.py    – TechnicalIndicators, FeatureEngineeringAgent, FeatureSelectionAgent
│   ├── sentiment.py   – SentimentAgent
│   ├── regime.py      – RegimeDetectionAgent
│   ├── prediction.py  – WalkForwardValidator, PredictionAgent
│   └── evaluation.py  – StrategyEvaluationAgent
├── models/
│   ├── classical.py   – LogisticRegressionAgent, RandomForestAgent, XGBoostAgent
│   ├── deep.py        – AttentionLayer, build_lstm_model, LSTMAgent
│   ├── ensemble.py    – EnsembleAgent
│   └── tuning.py      – HyperparameterAgent (Optuna)
├── trading/
│   ├── signals.py     – SignalGenerationAgent
│   ├── backtest.py    – BacktraderEngine, BacktestingAgent
│   ├── risk.py        – RiskManagementAgent
│   ├── montecarlo.py  – MonteCarloAgent
│   └── portfolio.py   – PortfolioOptimizationAgent
├── reporting/
│   ├── charts.py      – ReportGenerator (chart helpers)
│   ├── report.py      – ReportGenerationAgent
│   └── dashboard.py   – VisualizationDashboard, QuantVisualizer
├── api/
│   └── server.py      – FastAPI app, QuantAPIService
├── tests/
│   ├── unit_tests.py  – All unittest.TestCase classes
│   └── integration_tests.py – IntegrationTestSuite
├── pipeline.py        – PipelineOrchestrator, run_complete_pipeline
└── setup.py           – install script
"""

__version__ = "2.0.0"
__author__  = "IDEAS Internship 2026"
