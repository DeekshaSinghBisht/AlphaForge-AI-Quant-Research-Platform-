"""
utils.py
========
Shared helper functions:
  – DataFrame validation & cleaning
  – Returns / risk-metric calculations
  – Caching (pickle to Drive)
  – Formatting helpers
  – Model artefact save / load
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Union, List, Tuple, Optional, Any, Dict, Callable
from datetime import datetime, timedelta
import hashlib
import pickle
import json
from pathlib import Path
from functools import lru_cache
import warnings

warnings.filterwarnings('ignore')

# ============================================================================
# DATA UTILITIES
# ============================================================================

def validate_dataframe(
    df: pd.DataFrame,
    required_columns: Optional[List[str]] = None,
    min_rows: int = 10,
    check_nulls: bool = True,
    max_null_pct: float = 0.1
) -> Tuple[bool, List[str]]:
    """
    Validate a DataFrame meets requirements.

    Args:
        df: DataFrame to validate
        required_columns: List of required column names
        min_rows: Minimum number of rows required
        check_nulls: Whether to check for null values
        max_null_pct: Maximum allowed null percentage

    Returns:
        Tuple of (is_valid, list of error messages)
    """
    errors = []

    if df is None or df.empty:
        return False, ["DataFrame is None or empty"]

    if len(df) < min_rows:
        errors.append(f"DataFrame has {len(df)} rows, minimum required is {min_rows}")

    if required_columns:
        missing = set(required_columns) - set(df.columns)
        if missing:
            errors.append(f"Missing required columns: {missing}")

    if check_nulls:
        null_pct = df.isnull().sum() / len(df)
        high_null_cols = null_pct[null_pct > max_null_pct]
        if not high_null_cols.empty:
            errors.append(f"Columns with high null %: {dict(high_null_cols)}")

    return len(errors) == 0, errors


def clean_dataframe(
    df: pd.DataFrame,
    fill_method: str = 'ffill',
    drop_all_nan: bool = True
) -> pd.DataFrame:
    """
    Clean DataFrame by handling missing values.

    Args:
        df: DataFrame to clean
        fill_method: Method for filling missing values ('ffill', 'bfill', 'interpolate')
        drop_all_nan: Whether to drop rows/columns that are all NaN

    Returns:
        Cleaned DataFrame
    """
    df = df.copy()

    # Drop all-NaN columns
    if drop_all_nan:
        df = df.dropna(axis=1, how='all')

    # Fill missing values
    if fill_method == 'ffill':
        df = df.fillna(method='ffill').fillna(method='bfill')
    elif fill_method == 'bfill':
        df = df.fillna(method='bfill').fillna(method='ffill')
    elif fill_method == 'interpolate':
        df = df.interpolate(method='linear').fillna(method='ffill').fillna(method='bfill')

    return df


def resample_ohlcv(
    df: pd.DataFrame,
    timeframe: str = 'W'
) -> pd.DataFrame:
    """
    Resample OHLCV data to different timeframe.

    Args:
        df: DataFrame with OHLCV columns
        timeframe: Target timeframe ('D', 'W', 'M', 'Q', 'Y')

    Returns:
        Resampled DataFrame
    """
    ohlcv_map = {
        'Open': 'first',
        'High': 'max',
        'Low': 'min',
        'Close': 'last',
        'Adj Close': 'last',
        'Volume': 'sum'
    }

    # Only use columns that exist
    agg_dict = {col: agg for col, agg in ohlcv_map.items() if col in df.columns}

    return df.resample(timeframe).agg(agg_dict).dropna()


# ============================================================================
# MATHEMATICAL UTILITIES
# ============================================================================

def calculate_returns(
    prices: Union[pd.Series, pd.DataFrame],
    method: str = 'simple'
) -> Union[pd.Series, pd.DataFrame]:
    """
    Calculate returns from price series.

    Args:
        prices: Price series or DataFrame
        method: 'simple' or 'log'

    Returns:
        Returns series or DataFrame
    """
    if method == 'simple':
        return prices.pct_change()
    elif method == 'log':
        return np.log(prices / prices.shift(1))
    else:
        raise ValueError(f"Unknown method: {method}")


def annualize_returns(returns: float, periods_per_year: int = 252) -> float:
    """Annualize returns."""
    return (1 + returns) ** periods_per_year - 1


def annualize_volatility(volatility: float, periods_per_year: int = 252) -> float:
    """Annualize volatility."""
    return volatility * np.sqrt(periods_per_year)


def calculate_sharpe_ratio(
    returns: pd.Series,
    risk_free_rate: float = 0.05,
    periods_per_year: int = 252
) -> float:
    """
    Calculate annualized Sharpe ratio.

    Args:
        returns: Returns series
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of periods per year

    Returns:
        Sharpe ratio
    """
    excess_returns = returns - risk_free_rate / periods_per_year
    if returns.std() == 0:
        return 0.0
    return np.sqrt(periods_per_year) * excess_returns.mean() / returns.std()


def calculate_sortino_ratio(
    returns: pd.Series,
    risk_free_rate: float = 0.05,
    periods_per_year: int = 252
) -> float:
    """
    Calculate annualized Sortino ratio.

    Args:
        returns: Returns series
        risk_free_rate: Annual risk-free rate
        periods_per_year: Number of periods per year

    Returns:
        Sortino ratio
    """
    excess_returns = returns - risk_free_rate / periods_per_year
    downside_returns = returns[returns < 0]

    if len(downside_returns) == 0 or downside_returns.std() == 0:
        return np.inf if excess_returns.mean() > 0 else 0.0

    downside_std = downside_returns.std()
    return np.sqrt(periods_per_year) * excess_returns.mean() / downside_std


def calculate_max_drawdown(equity_curve: pd.Series) -> Tuple[float, int, int]:
    """
    Calculate maximum drawdown.

    Args:
        equity_curve: Equity curve series

    Returns:
        Tuple of (max_drawdown, peak_idx, trough_idx)
    """
    rolling_max = equity_curve.expanding().max()
    drawdowns = equity_curve / rolling_max - 1

    max_dd = drawdowns.min()
    trough_idx = drawdowns.idxmin()
    peak_idx = equity_curve[:trough_idx].idxmax()

    return max_dd, peak_idx, trough_idx


def calculate_calmar_ratio(
    returns: pd.Series,
    periods_per_year: int = 252
) -> float:
    """
    Calculate Calmar ratio (CAGR / Max Drawdown).

    Args:
        returns: Returns series
        periods_per_year: Number of periods per year

    Returns:
        Calmar ratio
    """
    equity_curve = (1 + returns).cumprod()
    cagr = (equity_curve.iloc[-1]) ** (periods_per_year / len(returns)) - 1
    max_dd, _, _ = calculate_max_drawdown(equity_curve)

    if max_dd == 0:
        return np.inf if cagr > 0 else 0.0

    return -cagr / max_dd


# ============================================================================
# CACHING UTILITIES
# ============================================================================

def generate_cache_key(*args, **kwargs) -> str:
    """Generate a unique cache key from arguments."""
    key_data = json.dumps({'args': str(args), 'kwargs': str(kwargs)}, sort_keys=True)
    return hashlib.md5(key_data.encode()).hexdigest()


def save_to_cache(
    data: Any,
    cache_name: str,
    cache_path: Path = CACHE_PATH
) -> Path:
    """
    Save data to cache.

    Args:
        data: Data to cache
        cache_name: Name for the cache file
        cache_path: Path to cache directory

    Returns:
        Path to cached file
    """
    filepath = cache_path / f"{cache_name}.pkl"
    with open(filepath, 'wb') as f:
        pickle.dump({
            'data': data,
            'timestamp': datetime.now().isoformat()
        }, f)
    return filepath


def load_from_cache(
    cache_name: str,
    cache_path: Path = CACHE_PATH,
    max_age_hours: int = 24
) -> Optional[Any]:
    """
    Load data from cache if valid.

    Args:
        cache_name: Name of the cache file
        cache_path: Path to cache directory
        max_age_hours: Maximum cache age in hours

    Returns:
        Cached data or None if not found/expired
    """
    filepath = cache_path / f"{cache_name}.pkl"

    if not filepath.exists():
        return None

    try:
        with open(filepath, 'rb') as f:
            cached = pickle.load(f)

        # Check age
        cache_time = datetime.fromisoformat(cached['timestamp'])
        age = datetime.now() - cache_time

        if age.total_seconds() > max_age_hours * 3600:
            return None

        return cached['data']
    except Exception:
        return None


# ============================================================================
# STATISTICAL UTILITIES
# ============================================================================

def bootstrap_statistic(
    data: np.ndarray,
    statistic_func: Callable,
    n_bootstrap: int = 10000,
    confidence_level: float = 0.95
) -> Tuple[float, float, float]:
    """
    Calculate bootstrap confidence interval for a statistic.

    Args:
        data: Data array
        statistic_func: Function to compute statistic
        n_bootstrap: Number of bootstrap samples
        confidence_level: Confidence level

    Returns:
        Tuple of (statistic, lower_ci, upper_ci)
    """
    n = len(data)
    bootstrap_stats = np.zeros(n_bootstrap)

    for i in range(n_bootstrap):
        sample = np.random.choice(data, size=n, replace=True)
        bootstrap_stats[i] = statistic_func(sample)

    stat = statistic_func(data)
    alpha = 1 - confidence_level
    lower = np.percentile(bootstrap_stats, 100 * alpha / 2)
    upper = np.percentile(bootstrap_stats, 100 * (1 - alpha / 2))

    return stat, lower, upper


# ============================================================================
# DISPLAY UTILITIES
# ============================================================================

def format_percentage(value: float, decimals: int = 2) -> str:
    """Format value as percentage string."""
    return f"{value * 100:.{decimals}f}%"


def format_currency(value: float, symbol: str = "$") -> str:
    """Format value as currency string."""
    return f"{symbol}{value:,.2f}"


def print_section(title: str, char: str = "=", width: int = 70) -> None:
    """Print a section header."""
    print(char * width)
    print(f" {title}")
    print(char * width)


# Test utilities
print("Testing utility functions...")

# Test returns calculation
test_prices = pd.Series([100, 102, 101, 105, 103])
test_returns = calculate_returns(test_prices)
print(f"✅ Returns calculation: {test_returns.dropna().values}")

# Test Sharpe ratio
test_sharpe = calculate_sharpe_ratio(test_returns.dropna())
print(f"✅ Sharpe ratio calculation: {test_sharpe:.4f}")

# Test caching
test_data = {"test": "data"}
cache_path = save_to_cache(test_data, "test_cache")
loaded_data = load_from_cache("test_cache")
print(f"✅ Caching works: {loaded_data == test_data}")

print("\n✅ All utility functions ready!")


import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple, Union
from datetime import datetime, timedelta
import pickle
import json
import os


# ============================================================================
# DATA UTILITIES
# ============================================================================

def load_cached_data(cache_key: str, max_age_hours: int = 24) -> Optional[Any]:
    """Load data from cache if valid."""
    return load_from_cache(cache_key, CACHE_PATH, max_age_hours)


def save_cached_data(data: Any, cache_key: str) -> Path:
    """Save data to cache."""
    return save_to_cache(data, cache_key, CACHE_PATH)


def get_trading_calendar(
    start_date: str,
    end_date: str = None
) -> pd.DatetimeIndex:
    """
    Get trading calendar (business days).

    Args:
        start_date: Start date
        end_date: End date (default: today)

    Returns:
        DatetimeIndex of trading days
    """
    end_date = end_date or datetime.today().strftime('%Y-%m-%d')
    return pd.bdate_range(start=start_date, end=end_date)


def align_dataframes(
    dfs: List[pd.DataFrame],
    method: str = 'inner'
) -> List[pd.DataFrame]:
    """
    Align multiple DataFrames by index.

    Args:
        dfs: List of DataFrames
        method: 'inner' or 'outer'

    Returns:
        List of aligned DataFrames
    """
    if not dfs:
        return []

    # Get common index
    if method == 'inner':
        common_idx = dfs[0].index
        for df in dfs[1:]:
            common_idx = common_idx.intersection(df.index)
    else:
        common_idx = dfs[0].index
        for df in dfs[1:]:
            common_idx = common_idx.union(df.index)

    return [df.reindex(common_idx) for df in dfs]


# ============================================================================
# PERFORMANCE UTILITIES
# ============================================================================

def calculate_performance_metrics(
    returns: pd.Series,
    risk_free_rate: float = 0.05
) -> Dict[str, float]:
    """
    Calculate comprehensive performance metrics.

    Args:
        returns: Returns series
        risk_free_rate: Annual risk-free rate

    Returns:
        Dictionary of metrics
    """
    returns = returns.dropna()

    if len(returns) == 0:
        return {k: 0.0 for k in [
            'total_return', 'cagr', 'volatility', 'sharpe_ratio',
            'sortino_ratio', 'calmar_ratio', 'max_drawdown',
            'win_rate', 'profit_factor'
        ]}

    # Calculate equity curve
    equity = (1 + returns).cumprod()

    # Basic metrics
    total_return = equity.iloc[-1] - 1
    years = len(returns) / 252
    cagr = (1 + total_return) ** (1 / max(years, 0.01)) - 1
    volatility = returns.std() * np.sqrt(252)

    # Risk-adjusted metrics
    rf_daily = risk_free_rate / 252
    excess_returns = returns - rf_daily
    sharpe = np.sqrt(252) * excess_returns.mean() / returns.std() if returns.std() > 0 else 0

    downside_returns = returns[returns < 0]
    downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0.001
    sortino = (returns.mean() * 252 - risk_free_rate) / downside_std

    # Drawdown
    running_max = equity.expanding().max()
    drawdown = (equity - running_max) / running_max
    max_drawdown = abs(drawdown.min())

    calmar = cagr / max_drawdown if max_drawdown > 0 else 0

    # Trading metrics
    win_rate = (returns > 0).mean()

    gross_profits = returns[returns > 0].sum()
    gross_losses = abs(returns[returns < 0].sum())
    profit_factor = gross_profits / gross_losses if gross_losses > 0 else 999

    return {
        'total_return': total_return,
        'cagr': cagr,
        'volatility': volatility,
        'sharpe_ratio': sharpe,
        'sortino_ratio': sortino,
        'calmar_ratio': calmar,
        'max_drawdown': max_drawdown,
        'win_rate': win_rate,
        'profit_factor': profit_factor
    }


def compare_strategies(
    strategy_returns: Dict[str, pd.Series],
    benchmark_returns: Optional[pd.Series] = None
) -> pd.DataFrame:
    """
    Compare multiple strategies.

    Args:
        strategy_returns: Dictionary of strategy returns
        benchmark_returns: Benchmark returns (optional)

    Returns:
        DataFrame with comparison metrics
    """
    results = []

    for name, returns in strategy_returns.items():
        metrics = calculate_performance_metrics(returns)
        metrics['strategy'] = name
        results.append(metrics)

    if benchmark_returns is not None:
        benchmark_metrics = calculate_performance_metrics(benchmark_returns)
        benchmark_metrics['strategy'] = 'Benchmark'
        results.append(benchmark_metrics)

    return pd.DataFrame(results).set_index('strategy')


# ============================================================================
# MODEL UTILITIES
# ============================================================================

def save_model_artifact(
    model: Any,
    name: str,
    metadata: Optional[Dict] = None
) -> Path:
    """
    Save model artifact with metadata.

    Args:
        model: Model to save
        name: Model name
        metadata: Optional metadata

    Returns:
        Path to saved model
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{name}_{timestamp}"

    # Save model
    model_path = MODELS_PATH / f"{filename}.pkl"
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)

    # Save metadata
    if metadata:
        meta_path = MODELS_PATH / f"{filename}_meta.json"
        with open(meta_path, 'w') as f:
            json.dump(metadata, f, indent=2, default=str)

    return model_path


def load_model_artifact(
    name: str,
    version: str = 'latest'
) -> Tuple[Any, Optional[Dict]]:
    """
    Load model artifact with metadata.

    Args:
        name: Model name
        version: Version ('latest' or specific)

    Returns:
        Tuple of (model, metadata)
    """
    # Find model files
    model_files = list(MODELS_PATH.glob(f"{name}_*.pkl"))

    if not model_files:
        raise FileNotFoundError(f"No model found with name: {name}")

    if version == 'latest':
        model_path = max(model_files, key=lambda x: x.stat().st_mtime)
    else:
        model_path = MODELS_PATH / f"{name}_{version}.pkl"

    # Load model
    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    # Load metadata
    meta_path = model_path.with_suffix('').with_suffix('_meta.json')
    metadata = None
    if meta_path.exists():
        with open(meta_path, 'r') as f:
            metadata = json.load(f)

    return model, metadata


# ============================================================================
# DISPLAY UTILITIES
# ============================================================================

def display_metrics_table(
    metrics: Dict[str, Any],
    title: str = "Metrics"
) -> None:
    """Display metrics in a formatted table."""
    print(f"\n{'='*50}")
    print(f"  {title}")
    print(f"{'='*50}")

    for key, value in metrics.items():
        if isinstance(value, float):
            if 'pct' in key.lower() or 'rate' in key.lower() or 'return' in key.lower():
                print(f"  {key:.<30} {value*100:.2f}%")
            else:
                print(f"  {key:.<30} {value:.4f}")
        else:
            print(f"  {key:.<30} {value}")

    print(f"{'='*50}\n")


def create_summary_report(
    backtest_results: Dict[str, Any],
    risk_results: Dict[str, Any],
    model_results: Optional[Dict[str, Any]] = None
) -> str:
    """
    Create a text summary report.

    Args:
        backtest_results: Backtest results
        risk_results: Risk analysis results
        model_results: Model metrics (optional)

    Returns:
        Summary report string
    """
    lines = [
        "=" * 60,
        "           QUANTITATIVE RESEARCH SUMMARY REPORT",
        "=" * 60,
        f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "  PERFORMANCE METRICS",
        "  -------------------",
        f"  Total Return:      {backtest_results.get('total_return', 0)*100:>10.2f}%",
        f"  Sharpe Ratio:      {backtest_results.get('sharpe_ratio', 0):>10.3f}",
        f"  Max Drawdown:      {backtest_results.get('max_drawdown', 0)*100:>10.2f}%",
        f"  Total Trades:      {backtest_results.get('total_trades', 0):>10}",
        f"  Win Rate:          {backtest_results.get('win_rate', 0)*100:>10.1f}%",
        "",
        "  RISK METRICS",
        "  ------------",
        f"  VaR (95%):         {risk_results.get('var_95', 0)*100:>10.2f}%",
        f"  CVaR (95%):        {risk_results.get('cvar_95', 0)*100:>10.2f}%",
        f"  Volatility:        {risk_results.get('volatility', 0)*100:>10.2f}%",
    ]

    if model_results:
        lines.extend([
            "",
            "  MODEL METRICS",
            "  -------------",
            f"  Accuracy:          {model_results.get('accuracy', 0):>10.4f}",
            f"  AUC:               {model_results.get('auc', 0):>10.4f}",
        ])

    lines.extend([
        "",
        "=" * 60,
    ])

    return "\n".join(lines)


# Test helper functions
print("=" * 70)
print("🧪 TESTING HELPER FUNCTIONS")
print("=" * 70)

# Test performance metrics
np.random.seed(42)
test_returns = pd.Series(np.random.randn(252) * 0.02 + 0.0005)

metrics = calculate_performance_metrics(test_returns)
display_metrics_table(metrics, "Performance Metrics Test")

# Test trading calendar
calendar = get_trading_calendar('2024-01-01', '2024-03-01')
print(f"✅ Trading days from 2024-01-01 to 2024-03-01: {len(calendar)}")

print("\n✅ Helper Functions ready!")